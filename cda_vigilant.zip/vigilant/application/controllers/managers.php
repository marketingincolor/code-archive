<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Managers extends CI_Controller {

	function Managers()
	{
		parent::__construct();	
	}
	
	function index()
	{
		//$this->load->view('installer_message');
	}
	
	function manager($name)
	{
		$this->load->helper('dom');
		$this->load->model('managers_model', '', TRUE);
		if ($this->input->server('HTTP_REFERER')) {
			$my_url = $this->input->server('HTTP_REFERER');
		} else {
			$my_url ='';
		}
		$my_id = $this->managers_model->resolve_id($name);
		//$html = file_get_html('http://localhost/MPC-2/matrix.php?d='.$my_id.'&p='.$my_url);
		$html = file_get_html('http://myprojectcenter.net/matrix.php?d='.$my_id.'&p='.$my_url);
		echo $html;
	}
	
}

/* End of file managers.php */
/* Location: ./system/application/controllers/managers.php */