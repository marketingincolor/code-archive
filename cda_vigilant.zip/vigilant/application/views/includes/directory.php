<div id="directory">

<a href="http://www.contactvigilant.com/mark-anderson">Mark Anderson</a><br>
Connecticut, Maine, Massachusetts, New Jersey, New Hampshire, New York (Eastern), Pennsylvania (Eastern), Rhode Island, Vermont
<br><br>

<a href="http://www.contactvigilant.com/timothy-ault">Timothy Ault</a><br>
Arizona, Colorado, Idaho, Montana, New Mexico, Texas (Western), Wyoming
<br><br>

<a href="http://www.contactvigilant.com/john-deremer">John Deremer</a><br>
Alabama, Florida, Georgia, Mississippi
<br><br>

<a href="http://www.contactvigilant.com/doug-doster">Doug Doster</a><br>
Arkansas, Illinois (Southern), Kansas, Kentucky (Western), Louisiana, Missouri, Oklahoma, Tennessee (Western), Texas
<br><br>

<a href="http://www.contactvigilant.com/jeffrey-handy">Jeffrey Handy</a><br>
Illinois (Northern), Indiana, Iowa, Kentucky (Northern), Maryland (Western), Michigan, Minnesota, Nebraska, New York (Western), North Dakota, Ohio, Pennsylvania (Western), South Dakota, West Virginia (Northern), Wisconsin
<br><br>

<a href="http://www.contactvigilant.com/michael-matyas">Michael Matyas</a><br>
Alaska, California, Nevada, Oregon, Washington
<br><br>

<a href="http://www.contactvigilant.com/jonathan-mcconnell">Jonathan McConnell</a><br>
Delaware, Kentucky (Southern), Maryland (Eastern), North Carolina, South Carolina, Tennessee (Eastern), West Virginia (Southern)
<br><br>

<!-- <a href="http://www.contactvigilant.com/brent-wilkins">Brent Wilkins</a><br>
Region info here<br><br> -->

</div>