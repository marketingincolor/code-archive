
<div id="adleftcol">

	<div id="advert"  style="margin-left:30px; color:#000;">
		<img src="images/vig_grfx_protect.jpg">
		<br><br>
		<p>These are challenging economic times. So maybe it's time you took a good hard look at where your business
		is going, and where you want it to be.</p>
		<p>If those aren't in the same ballpark, it's probably time to consider getting the Vigilant team behind you.
		To learn more, contact a Vigilant Regional Manager by choosing a name from the directory listing (right).</p>
		<h2>About Vigilant</h2>
		<p>Vigilant VM Series represents the latest generation of life safety control panels for mid to large sized
		applications. With large multi-message displays, intuitive interfaces, and stylish contoured cabinets - these
		systems capture the imagination, and catch the eye. But behind the LCD display is where they really shine.</p>
		<p>Learn more about Vigilant by visiting the <a href="http://www.edwardsutcfs.com/" target="_blank">Edwards Website</a>.</p>
	</div>

	<br clear="all"><br>

	
</div>

<div id="adrightcol">
	<img src="images/vig_grfx_directory_head.jpg">
	<?php $this->load->view('includes/directory'); ?>
</div>

<br clear="all">
