<?php
class Managers_model extends CI_Model {

    var $name = '';

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    
    function resolve_id($name)
    {
    	$query = $this->db->query('SELECT * FROM disks WHERE name = "'.$name.'"');       
		$row = $query->row();
		
		if ($row) {
		$client = $this->db->query('SELECT * FROM clients WHERE id ="' .$row->client_id. '"');
		$row2 = $client->row();
		}
		return $row->id;
    }

}