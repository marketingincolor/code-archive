
<div id="leftcolalt">
	<div id="contentalt">
		<h1>Welcome to the EST LinkBox Support Center</h1>
		<p><span class="bold red">Note:</span> This Support Center is unlisted on the web and can only be found by typing in the web address 
		<b>www.ContactEdwards.com/support</b> ��Please bookmark this page for future reference.</p>

		<p><span class="bold blue">What is LinkBox?</span><br>
		LinkBox is a landing page system that provides prospects an easy way to find and engage with you online.</p>

		<p><span class="bold blue">What is a Landing Page?</span><br>
		A landing page is a web page where a prospect "lands" after clicking through a link. In this case, a directory 
		of District Managers that is provided online.<img src="images/est_grfx_support.png" style="float:right;">
		<br><br>
		Typically, the visitor will find a direct response mechanism on the landing page, such as a form to fill out and submit. This 
		is a significant benefit to you, because too often customers will come to a corporate website and have no way of knowing how 
		to find or make contact with you.</p>

		<p><span class="bold blue">How is EST using LinkBox?</span><br>
		EST is running ads that include web addresses that direct prospects to an online directory, which in turn links visitors to all 
		the District Managers participating in the LinkBox program. When a prospect clicks a link, he/she goes to your landing page, where 
		the prospect can interact with you directly. The forms a visitor can submit through your landing page include:
		<br><br>
		<b>1. Schedule a consultation with you<br>
		2. Ask a simple question<br>
		3. Refer others to your landing page</b><br>
		<br>
		When a visitor submits any of the these forms, you will be notified by email.</p>

		<p><span class="bold blue">An email submission has arrived. What do I do?</span><br>
		<span class="bold">If the person requests a consultation:</span> Respond as soon as possible, via email or phone to schedule a time for a consultation. The 
		goal of the consultation will be to qualify the prospects and, if qualified, assess which Strategic Partner to introduce the 
		prospect to. The SP picks up the process from there and the DM follows up as necessary.
		<br><br>
		<span class="bold">If the person submits a simple question:</span> Be mindful that the person is probably not fully ready to engage yet, and focus on simply 
		answering the question.
		<br><br>
		<span class="bold">Refer others to your landing page:</span> You'll be notified by mail that a referral has been made. This is for your information only. You 
		should not respond to referral emails.</p>

		<p><span class="bold blue">Questions? Comments?</span><br>
		If you have any questions or comments regarding the LinkBox program, please <a href="https://marketingincolor.wufoo.com/forms/q7x0w7/" onclick="window.open(this.href,  null, 'height=456, width=680, toolbar=0, location=0, status=1, scrollbars=1, resizable=1'); return false" title="LinkBox Question/Comment Form">submit this form.</a></p>
	</div>
</div>

<div id="rightcolalt">
For best results, view the following videos full-screen with your audio on.
<br><br>
<b>Logging In, Changing Your Password, Forgotten Password</b><br>
<iframe width="334" height="220" src="http://www.youtube.com/embed/SYf6RNjL2EI?rel=0" frameborder="0" allowfullscreen></iframe>
<br><br>
<b>Viewing The LinkBox<sup>&trade;</sup> Dashboard</b><br>
The dashboard offers you a quick status view of all prospects you are currently engaging with.<br>
<iframe width="334" height="220" src="http://www.youtube.com/embed/GA0LQjdWZHs?rel=0" frameborder="0" allowfullscreen></iframe>
<br><br>
<b>Viewing The LinkBox<sup>&trade;</sup> Reporting Details</b><br>
View activity by date range and historical records of those you've cleared from the dashboard.<br>
<iframe width="334" height="220" src="http://www.youtube.com/embed/xkj3JFkJ1Bg?rel=0" frameborder="0" allowfullscreen></iframe>
</div>

<br clear="all">
