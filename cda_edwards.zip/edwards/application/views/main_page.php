<div id="graybox">
	<h1>Welcome to the EST Contact Directory</h1>
	<p>For a FREE personal consultation with an EST District Manager about EST Life Safety and Communications 
	products, please choose a name from the listing below.</p>
</div>

<div id="leftcol">
	<img src="images/est_grfx_main.png">
	<br><br>
	<div id="content">
		<span>For more information about EST Life Safety and Communications products, visit the <a href="http://www.edwardsutcfs.com/" target="_blank">Edwards Website</a>.</span>
	</div>
</div>

<div id="rightcol">
	<?php $this->load->view('includes/directory'); ?>
</div>

<br clear="all">
