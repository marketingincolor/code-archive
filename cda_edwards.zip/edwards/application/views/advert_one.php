
<div id="adleftcol">
	<img src="images/est_grfx_co_advert.png">
	<br><br>
	<div id="content">
		<span>For more information about EST Life Safety and Communications products, visit the <a href="http://www.edwardsutcfs.com/" target="_blank">Edwards Website</a>.</span>
	</div>
	<div id="advideobox">
	<iframe width="520" height="390" src="http://www.youtube.com/embed/eVwF6mnmR5M?rel=0" frameborder="0" allowfullscreen></iframe>
	</div>
	<br clear="all"><br>
	<div id="databox"><img src="http://myprojectcenter.net/templates/edwards/images/est_grfx_co_prod.jpg">
	<h3>Signature Series Detectors</h3>
	<p>With optional CO sensors, Signature Series detectors pull double-duty�continually monitoring the environment for 
	signs of smoke, as well as its invisible yet deadly companion, carbon monoxide. Meanwhile, continuous self-diagnostics 
	ensure reliability over the long-haul, and innovative field replaceable smoke chambers make detector maintenance 
	literally a snap.</p>
	</div>
	
</div>

<div id="adrightcol">
	<img src="images/est_grfx_directory_head.jpg">
	<?php $this->load->view('includes/directory'); ?>
</div>

<br clear="all">
