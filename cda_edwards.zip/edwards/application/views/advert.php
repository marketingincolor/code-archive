<h1>Advert <?php echo $number; ?></h1>

<p>The page you are looking at is being generated dynamically by CodeIgniter.</p>

<p><br />Page rendered in {elapsed_time} seconds</p>

