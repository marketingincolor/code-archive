<div id="adtwoleftcol">
	<img src="images/est_grfx_puzzle_advert.png" style="right:10px;">
	<br><br>
	<div id="content">
		<span>EST offers complete solutions for risks both known, and unknown. Choose an EST professional in our 
		directory to help connect you with the right Strategic Partner for your next project.</span>

		<p>EST Strategic Partners are highly successful independent contractors, with exclusive access to EST products, 
		customer design innovations, and specialized training. They�re ready to guide you from design-build through 
		final construction, to ensure code-compliant solutions that meet your every need.</p>

		<p>The choice of building owners, architects, and engineers everywhere. EST.</p>
	
	</div>

	<br clear="all"><br>

</div>

<div id="adrightcol">
	<img src="images/est_grfx_directory_head.jpg">
	<?php $this->load->view('includes/directory'); ?>
</div>

<br clear="all">
