<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html>
<head>
<title><?php echo $title ?></title>
<link rel="stylesheet" href="<?php echo base_url();?>css/style.css" type="text/css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-2624271-34']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
</head>
<body>

<div id="base" class="column">
<?php if($mainid == 'mainalt'): ?>
	<div id="header" class="col_full">
		<div id="hnav" class="">
			<a href="http://www.contactedwards.com/">Search all EST District Managers</a>&nbsp;&nbsp;&nbsp;<a href="http://www.edwardsutcfs.com/" target="_blank">Visit The Edwards Website</a>
		</div>
	</div>
	<div id="<?php echo $mainid ?>"><br clear="all">
<?php else: ?>
	<div id="header" class="col_full">
		<div id="hnav" class="">
			<a href="http://www.edwardsutcfs.com/" target="_blank">Visit The Edwards Website</a>
		</div>
	</div>
	<div id="<?php echo $mainid ?>"><br clear="all">
<?php endif; ?>
