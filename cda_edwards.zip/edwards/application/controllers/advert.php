<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Advert extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 */
	public function index()
	{
		$data = array(
			'title' => 'HTML Page Title Goes Here',
			'content' => 'main_page',
			'mainid' => 'main'
			);
		$this->load->view('includes/template', $data);
	}
	
	public function one()
	{
		$data = array(
			'title' => 'EST - Life Safety and Communications',
			'content' => 'advert_one',
			'mainid' => 'main'
			);
		$this->load->view('includes/template', $data);
	}
	
	public function two()
	{
		$data = array(
			'title' => 'EST - Life Safety and Communications',
			'content' => 'advert_two',
			'mainid' => 'main'
			);
		$this->load->view('includes/template', $data);
	}
	
	public function three()
	{
		$data = array(
			'title' => 'EST - Life Safety and Communications',
			'content' => 'advert_three',
			'mainid' => 'main'
			);
		$this->load->view('includes/template', $data);
	}
	
	public function four()
	{
		$data = array(
			'title' => 'EST - Life Safety and Communications',
			'content' => 'advert_four',
			'mainid' => 'main'
			);
		$this->load->view('includes/template', $data);
	}

	public function five()
	{
		$data = array(
			'title' => 'EST - Life Safety and Communications',
			'content' => 'advert_five',
			'mainid' => 'main'
			);
		$this->load->view('includes/template', $data);
	}

	public function six()
	{
		$data = array(
			'title' => 'EST - Life Safety and Communications',
			'content' => 'advert_six',
			'mainid' => 'main'
			);
		$this->load->view('includes/template', $data);
	}
}

/* End of file advert.php */
/* Location: ./application/controllers/advert.php */