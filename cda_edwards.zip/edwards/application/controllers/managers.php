<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Managers extends CI_Controller {

	function Managers()
	{
		parent::__construct();	
	}
	
	function index()
	{
		//$this->load->view('installer_message');
	}
	
	function manager($name)
	{
		$this->load->helper('dom');
		$this->load->model('managers_model', '', TRUE);
		$my_id = $this->managers_model->resolve_id($name);
		//$this->load->database();
		
		/*$query = $this->db->query('SELECT * FROM disks WHERE name = "'.$name.'"');       
		$row = $query->row();
		
		if ($row) {
		$client = $this->db->query('SELECT * FROM clients WHERE id ="' .$row->client_id. '"');
		$row2 = $client->row();
		}
		
		if ($row) {
			if ($row2->affiliate_id != '16') { redirect('.','refresh');}
		$data['diskid'] = $row->id;
		$data['manager_name'] = $name;
		$data['office_name'] = $row2->office_name;
		$data['city'] = $row2->city;
		} else {
		$data['diskid'] = "unavailable";
		$data['installer_name'] = "unavailable";
		}*/
		
		$html = file_get_html('http://localhost/MPC-2/matrix.php?d='.$my_id);
		//$html = file_get_html('http://myprojectcenter.net/matrix.php?d='.$my_id);
		echo $html;
	}
	
}

/* End of file managers.php */
/* Location: ./system/application/controllers/managers.php */