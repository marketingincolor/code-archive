<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">    <meta name="keywords" content="">    <meta name="description" content="">
<title>A J Arango Florida Import Export Brokerage Services</title>    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body><div id="frame"><div id="topnav"><p><?php include("nav.php"); ?></p></div>
<div id="header"><img src="images/logo.gif" alt="AJ ARANGO logo" width="300" height="65"><img src="images/celebrating.gif" alt="Celebrating 60 years" width="420" height="22" style="margin-bottom:20px; margin-left:180px;">
<br>

<img src="images/bottombar.gif" width="899" height="19"></div><div id="contentheader"><div id="section"><a href="import.php"><img src="images/importservices-icon.gif" alt="Import Services" width="108" height="91" border=0></a><p>50 years of full-service experience in all types of products from all countries. this diversification of import. A depth of experience in dealing with all government agencies</p></div><div id="section"><a href="export.php"><img src="images/exportservices-icon.gif" alt="Export Services" width="108" height="91" border=0></a><p>Comprehensive freight forwarding services to and from all points around the globe. For land, air or ocean freight forwarding, we provide highly competitive rates.</p></div><div id="section"><a href="insurance.php"><img src="images/insurance-bonds-icon.gif" alt="Insurance and Bonds" width="128" height="91" border=0></a><p>A.J. Arango offers all forms of Insurance and Bonds to complete your import or export transaction.</p></div><br clear="all"></div>

<div id="contentleft"><img src="images/ship.jpg" alt="shipping services" width="167" height="191" hspace="0" vspace="0" border="0" /><br><img src="images/truck.jpg" alt="trucking" width="166" height="203" hspace="0" vspace="0" border="0" /></div><div id="contentcenter"><img src="images/mainhead.gif" alt="AJ Arango Since 1948, World Class Service Is Our Custom" width="331" height="43" hspace="0" vspace="0" border="0" /><p>
A.J. Arango Inc. a family owned and operated business, started in 1948 by Mr. A.J. Arango.  The main office is located in Tampa�s Historic Latin Quarter, Ybor City, with other offices located at Tampa International Airport and in Orlando.
 </p><img src="images/dad.jpg" width="93" height="97" hspace="6" vspace="3" border="0" align="left" /><p>
Our staff consists of 4 licensed Brokers with a combined experience that exceeds 100 years.  With this wealth of knowledge and experience, our employees have access to consult with the licensed brokers at all times.  This ensures the highest level of Customs Compliance when filing your documentation.
In this age of ever changing automation, A.J. Arango stays current with all new programs available from Customs and Border Protection and Department of Commerce.
 </p><img src="images/service.jpg" width="186" height="125" hspace="6" vspace="3" border="0" align="right" /><p>
A.J. Arango also offers Remote Location Filing of entries and being active in Customs Border Protections� ACE Program we can officer Periodic Monthly Payments of Duties.  This enables importer to pay customs duties on a monthly basis.
 
<p>A.J. Arango is licensed by the FML for Freight Forwarding and C-TPAT Certified by Customs and Border Protection.
 
<p>We are also active in the NCBFAA, National Customs Brokers and Forwarders Association of America�s.  CCS Program. Certified Customs Specialist offering customers the highest level of Security, Import and Export Compliance.
</p><br><br></div><div id="contentright">

<?php include("news.php"); ?>

</div><br clear="all"><br>
<div id="footer">
<?php include("footer.php"); ?>
</div>
</div><br clear="all">
</body>
</html>
