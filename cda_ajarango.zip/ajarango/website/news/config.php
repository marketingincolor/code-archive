<?php
/*
	Configuration settings for NewsScript
*/

// Database Settings //////////////////////////////////////////////////////////

	$db_host =		"localhost";
	$db_name =		"ajarango_news";			//MySQL DB name
	$db_user =		"ajarango_cheapo";			//MySQL User
	$db_password =	"ajarangoweb-2008";			//MySQL password
	
////////////////////////////////////////////////////////////////////////////////

	$lim = 4; // Only show first 20 News Items.

	$template = "templates/DisplayTemplate.php"; // default template
	
////////////////////////////////////////////////////////////////////////////////
?>