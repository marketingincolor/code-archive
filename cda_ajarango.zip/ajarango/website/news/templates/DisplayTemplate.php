<div class="newsDiv">
  <div class="news-headline"><?php echo $author; ?></div>
  <div class="news-date">Posted on: <?php echo $date; ?></div>
  <div class="news-content"><?php echo $content; ?></div>
</div>
<br />
