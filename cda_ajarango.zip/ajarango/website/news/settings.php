<?php
/**
 * settings.php
 * 
 * configuration settings for the Login Script.
 */

// Database Settings //////////////////////////////////////////////////////////

	$this->db_host =		"localhost";
	$this->db_name =		"";				//MySQL DB name
	$this->db_user =		"";				//MySQL User
	$this->db_password =	"";				//MySQL password
	
////////////////////////////////////////////////////////////////////////////////

?>