
<html>
<head>
<link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
<div id="frame"><div id="topnav"><p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="addNewsForm.php">Add News</a>
&nbsp;&nbsp;&nbsp;&nbsp;


<a href="index.php">Manage News</a>
&nbsp;&nbsp;&nbsp;&nbsp;

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

</p></div>
<div id="header"><img src="../images/logo.gif" alt="AJ ARANGO logo" width="300" height="65"></div>
<div id=news>
<br><br>
<br>
<?php
require('config.php');
require('NewsScript.php');

/**
 * Here we have clicked the button to update our edited article
 * We need to update it in the database
 */
if(isset($_POST['Submit']))
{
	$news = new NewsScript();
	if($news->updateNews($_GET['id'], $_POST['txtAuthor'], $_POST['txtContent']))
	{
		echo "Update complete!";
	}
	else echo "Update Error!";
	
	exit();
	
}
else // page loads but form not submitted
{
	if(is_numeric($_GET['id']))
	{
		$connection = mysql_connect($db_host, $db_user, $db_password) 
						or die("Unable to connect to MySQL");
							
		mysql_select_db($db_name, $connection) or die("Unable to select DB!");
		$id = $_GET['id'];
	
		$result = mysql_query("SELECT * FROM newstbl WHERE id = '$id'");
		$row = mysql_fetch_assoc($result);
			
		$author =  $row['author'];
		$content = $row['content'];
	
		mysql_close($connection);
	}
	else echo "";
}

/**
 * output our content
 *
 */
function showContent()
{
	global $content;
	echo $content;
}

/**
 * output the author
 *
 */
function showAuthor()
{
	global $author;
	echo 'value="'. $author . '"';
}
	
?>

<h1>Edit News</h1>
<form method="post" action="<?php $_SERVER['PHP_SELF']?>">
<table width="100%" border="0" cellspacing="2" cellpadding="2">
<tr><td valign=top><table>
  <tr>
    <td>Name</td>
    <td><input type="text" name="txtAuthor" <? showAuthor();?> /></td>
  </tr>
  <tr>
    <td>News</td>
    <td><textarea name="txtContent" cols="60" rows="5"><? showContent();?></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="Submit" value="Update" /></td>
  </tr>
</table>
</form></td></tr></table></div>
</body>
</html>