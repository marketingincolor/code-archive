
<html>
<head>
<link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
<div id="frame"><div id="topnav"><p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="addNewsForm.php">Add News</a>
&nbsp;&nbsp;&nbsp;&nbsp;


<a href="index.php">Manage News</a>
&nbsp;&nbsp;&nbsp;&nbsp;

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

</p></div>
<div id="header"><img src="../images/logo.gif" alt="AJ ARANGO logo" width="300" height="65"></div>
<div id=news>
<br><br>
<br>


<h1>Add News</h1>
<form method="post" action="<?php $_SERVER['PHP_SELF']?>">
<table width="100%" height="100%" border="0" cellspacing="2" cellpadding="2">
<tr><td valign=top><table>
  <tr>
    <td>Name</td>
    <td><input type="text" name="txtAuthor" /></td>
  </tr>
  <tr>
    <td>News</td>
    <td><textarea name="txtContent" cols="60" rows="5"></textarea></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="Submit" value="Submit" /></td>
  </tr>
</table></td></tr></table>
</form>
</body>
</html>
<?php

if($_POST['Submit'])
{
	
	if(!empty($_POST['txtAuthor']) && !empty($_POST['txtContent']))
	{

		include ('../NewsScript.php');

		$news = new NewsScript();
		
		/**
		 * notice we don't deal with bad input here, 
		 * the NewsScript object does this for us using our clean() function
		 */
		$news->addNews($_POST['txtAuthor'], $_POST['txtContent']);
	}
	else 
	{
		echo "Please complete the form.";
	}
}
?>
</div>
</body></html>