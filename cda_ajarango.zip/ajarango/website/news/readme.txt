News System		(PHP/MySQL)	(www.surneo.com)
-----------

A Simple News system Class using PHP4 and MySQL.

Notice there isn't any security on the admin pages, that is they should not be left vewable on your
web server because anyone could add/remove atricles, you should password protect the directory!
maybe in future I will add a secure login section, althought you could easily combine this script
with the simple login script on my site to add a little security :-)



Installation
------------

You need to setup the following MySQL Table.

SQL Table:

CREATE TABLE `newstbl` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`author` VARCHAR( 30 ) NOT NULL ,
`content` TEXT NOT NULL ,
`date` DATE NOT NULL 
) ENGINE = MYISAM ;

You can view the installDatabase.php page to create this database for you.
You must edit config.php first!



Configuration
--------------

config.php:

This file contains all the settings you need to set, such as MySQL settings!

DisplayTemplate:

This can be edited to suit your needs, it's the layout for the news articles.
You can edit this file and the CSS file to make each article display as you wish.

Usage
-----

test.php	: An example showing howto display the items in your database.

Admin
-----

manageNews.php	: This page will show all items with the ability to delete or edit each item

addNewsForm.php	: This page will allow you to add new items to your database