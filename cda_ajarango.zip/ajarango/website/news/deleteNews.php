
<html>
<head>
<link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
<div id="frame"><div id="topnav"><p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="addNewsForm.php">Add News</a>
&nbsp;&nbsp;&nbsp;&nbsp;


<a href="index.php">Manage News</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

</p></div>
<div id="header"><img src="../images/logo.gif" alt="AJ ARANGO logo" width="300" height="65"></div>
<div id=news>
<br><br>
<br>

<?php
require('NewsScript.php');

if(is_numeric($_GET['id']))
{
	$news = new NewsScript();
	
	if($news->deleteNews($_GET['id']))
	{
		echo "Successfully Deleted Item: " . $_GET['id'];
	}
	else echo "Error deleting news item!";
}
?>