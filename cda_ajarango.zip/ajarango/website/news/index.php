
<html>
<head>
<link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
<div id="frame"><div id="topnav"><p>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="addNewsForm.php">Add News</a>
&nbsp;&nbsp;&nbsp;&nbsp;


<a href="index.php">Manage News</a>
&nbsp;&nbsp;&nbsp;&nbsp;

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;


</p></div>
<div id="header"><img src="../images/logo.gif" alt="AJ ARANGO logo" width="300" height="65"></div>
<div id=news>
<br><br>
<br>

<?php
/**
 * manageNews.php
 * 
 * Displays all news items with an option to delete or edit each article
 */
require('config.php');

$connection = mysql_connect($db_host, $db_user, $db_password) 
				or die("Unable to connect to MySQL");
							
mysql_select_db($db_name, $connection) or die("Unable to select DB!");

/**
 * show all atricles with options to edit/delete
 */
// Use the limit in our settings to decide how many to show
$result = mysql_query("SELECT * FROM newstbl ORDER BY date DESC LIMIT 0, $lim");
		
		
		

/* While we have more rows display them */
while($row = mysql_fetch_assoc($result))
{
	// Display the row
	$id = $row['id'];
	$author =  $row['author'];
	$content = $row['content'];
	
	/**
	 * show each article with edit/delete links
	 */
	echo "<div>ID: $id</div>";
	echo "<div>Author: $author</div>";
	echo "<div>Content: $content</div>";
	echo "<div><a href=\"editNewsForm.php?id=$id\">Edit</a> | <a href=\"deleteNews.php?id=$id\">Delete</a></div>";
	echo"<br /><hr />";
			
}


mysql_close($connection);
?>
</div>
</body></html>