<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <meta name="keywords" content="">
    <meta name="description" content="">
	<title>Services: 
A Comprehensive Offering</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div id="frame">

<div id="topnav">
	<p><?php include("nav.php"); ?> &nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php">Home</a></p>
</div>
<!------header nav------>
<div id="header">
<div style="float:right; padding-right:20px;">
<a href="import.php"><img src="images/import-svc-small.gif" alt="Import Services" border="0"></a>&nbsp;&nbsp;
<a href="export.php"><img src="images/export-svc-small.gif" alt="export services" border="0"></a>&nbsp;&nbsp;
<a href="insurance.php"><img src="images/ins-bonds-small.gif" alt="Insurance And Bonds" border="0"></a>&nbsp;&nbsp;</div>
<img src="images/logo.gif" alt="AJ ARANGO logo" width="300" height="65">
<br>
<img src="images/bottombar.gif" width="899" height="19">
</div>
<!------END header nav------>


<div id="subcontentleft">
<img src="images/ship.jpg" alt="shipping services" width="167" height="191" hspace="0" vspace="0" border="0" />
<br>
<img src="images/truck.jpg" alt="trucking" width="166" height="203" hspace="0" vspace="0" border="0" />
</div>


<div id="subcontentcenter">
<img src="images/services.jpg" alt="Services" width="435" height="56" hspace="0" vspace="0" border="0" />
<p>
A.J. Arango has a wealth of knowledge and experience including 4 licensed customs brokers with a combined experience that exceeds 100 years. Because our brokers are in-house, our employees have instant access to a licensed brokers at all times. This ensures the highest level of Customs Compliance when filing your documentation.

<b><p><a href="import.php">Import Services</a></b>
<ul>
<li>Remote Location Filing (RLF)
<li>Bonded Entries, Foreign Trade Zones
<li>Bonded Cargo Movements, Transportation Solution
<li>Import Air and Ocean Services
</ul>
<b><p><a href="export.php">Export Services</a></b>
<ul>
<li>International Freight Forwarding
<li>Automated Export System (AES)
<li>Duty Drawback
<li>Letters of Credit, Export Licenses
</ul>
<b><p><a href="insurance.php">Insurance & Bonds</a></b>
<ul>
<li>Customs Bonds
<li>Marine Cargo Insurance
</ul>
</p>
<br><br>
</div>




<div id="footer">
<img src="images/footerbar.gif" width="899" height="19">
Copyright 2008 AJArango, Inc. All Rights Reserved Worldwide.<BR>
AJArango is a Customs Broker with Customs Brokerage Services including Import Services, Export Services, 
Insurance and Bonding with offices in Tampa and Orlando, Florida.
</div>
</div><br clear="all">
</body>
</html>
