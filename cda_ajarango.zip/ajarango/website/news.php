<img src="images/ajnews.gif" alt="AJ Arango News" width="275" height="25">
<br>
<p><?php
/**
 *	Test NewsScript.php
 *
 */

include ('news/NewsScript.php');

$news = new NewsScript();

$news->displayAll();

?>
</p>

<img src="images/shippingnews.gif" alt="Shipping News" width="275" height="25">
<p>
<script language="javascript" type="text/javascript" src="http://www.newsfeedmaker.com/feed.php?code=0ca19b14"></script>