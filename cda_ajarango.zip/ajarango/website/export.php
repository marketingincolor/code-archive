<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <meta name="keywords" content="">
    <meta name="description" content="">
	<title>Export Services: 
Experience & Unparalleled Support</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div id="frame">

<div id="topnav">
	<p><?php include("nav.php"); ?> &nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php">Home</a></p>
</div>
<!------header nav------>
<div id="header">
<div style="float:right; padding-right:20px;">
<a href="import.php"><img src="images/import-svc-small.gif" alt="Import Services" border="0"></a>&nbsp;&nbsp;
<a href="export.php"><img src="images/export-svc-small.gif" alt="export services" border="0"></a>&nbsp;&nbsp;
<a href="insurance.php"><img src="images/ins-bonds-small.gif" alt="Insurance And Bonds" border="0"></a>&nbsp;&nbsp;</div>
<img src="images/logo.gif" alt="AJ ARANGO logo" width="300" height="65">
<br>
<img src="images/bottombar.gif" width="899" height="19">
</div>
<!------END header nav------>


<div id="subcontentleft">
<img src="images/ship.jpg" alt="shipping services" width="167" height="191" hspace="0" vspace="0" border="0" />
<br>
<img src="images/truck.jpg" alt="trucking" width="166" height="203" hspace="0" vspace="0" border="0" />
</div>


<div id="subcontentcenter">
<img src="images/export.jpg" alt="Export Services" width="435" height="56" hspace="0" vspace="0" border="0" />

<p><b>International Freight Forwarding</b>
<br>A.J. Arango offers comprehensive freight forwarding services to and from all points around the globe.

<p>Whether you needs are for land, air or ocean freight forwarding, we can provide highly competitive rates.  A.J. Arango can provide inland transportation from you or your vendor's facilities to the international air or ocean carrier's terminal.
 
<p><b>Automated Export System (AES) - needs a little more re-writing</b><br>
AJ Arango is compliant with theAutomated Export System (AES) required by the U.S. Government. The system ensures compliance with the Export Regulations imposed by various government agencies.  

<p>The Automated Export System streamlines the process of exporting goods from the United States and improves data quality for the United States government.  Exporters and carriers electronically submit export data required by more than 40 government agencies that regulate and monitor US exports.

<p>AES is a joint program of the U.S. Customs Service and the Bureau of the Census; it is also the only United States automated system for reporting export data, both commodity (Shipper's Export Declaration (SED)), and transportation (booking and manifest). This information is used by Customs to focus on high-risk export shipments and to detect possible fraud in reporting values and commodity information. AES is also used by Census to compile trade statistics that are used to compute such figures as the balance of trade.

<p>AES drastically reduces the amount of inaccurate or incomplete information received by passing all data through an electronic edit process. The trade statistics produced by Census are used by many different federal and local agencies for trade policy decision-making, export control, and port development planning, and by the exporting community and the financial community for foreign market analysis, penetration studies, and investment decisions.
 <p>
 
 
<b>Duty Drawback</b>
 <br>
Customs and Border Protection (CBP) allows for the repayment of up to 99% of the duty originally paid on imported merchandise that is subsequently exported.  If your operations include exportation of imported merchandise you should consult with A.J. Arango to find out if Duty Drawback is a viable option for you.

<p>Subject to time limitation on the imported merchandise, Duty Drawback needs to be applies for prior to exporting your cargo.
 <br><br>
<b>Letters of Credit, Export Licenses</b>
 <BR>
A.J. Arango has a trained staff with many years experience in reviewing Letters of Credit.   We will ensure your Letter of Credit is complete and accurate
(See highlighted Samuel Shapiro Information on Letter of Credit)</p>
<br><br>
</div>




<div id="footer">
<img src="images/footerbar.gif" width="899" height="19">
Copyright 2008 AJArango, Inc. All Rights Reserved Worldwide.<BR>
AJArango is a Customs Broker with Customs Brokerage Services including Import Services, Export Services, 
Insurance and Bonding with offices in Tampa and Orlando, Florida.
</div>
</div><br clear="all">
</body>
</html>
