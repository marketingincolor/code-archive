<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <meta name="keywords" content="">
    <meta name="description" content="">
	<title>Import Services: 
Experience & Proven Results</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div id="frame">

<div id="topnav">
	<p><?php include("nav.php"); ?> &nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php">Home</a></p>
</div>
<!------header nav------>
<div id="header">
<div style="float:right; padding-right:20px;">
<a href="import.php"><img src="images/import-svc-small.gif" alt="Import Services" border="0"></a>&nbsp;&nbsp;
<a href="export.php"><img src="images/export-svc-small.gif" alt="export services" border="0"></a>&nbsp;&nbsp;
<a href="insurance.php"><img src="images/ins-bonds-small.gif" alt="Insurance And Bonds" border="0"></a>&nbsp;&nbsp;</div>
<img src="images/logo.gif" alt="AJ ARANGO logo" width="300" height="65">
<br>
<img src="images/bottombar.gif" width="899" height="19">
</div>
<!------END header nav------>


<div id="subcontentleft">
<img src="images/ship.jpg" alt="shipping services" width="167" height="191" hspace="0" vspace="0" border="0" />
<br>
<img src="images/truck.jpg" alt="trucking" width="166" height="203" hspace="0" vspace="0" border="0" />
</div>


<div id="subcontentcenter">
<img src="images/import.jpg" alt="Import Services." width="435" height="56" hspace="0" vspace="0" border="0" />
<p> Diversified Client base-experienced in all types of products from all countries with this diversification of import A.J. Arango stays current with the ever changing Free Trade Agreements.  It also gives A.J. Arango a depth of experience in dealing with Other Government Agencies, such as  Food & Drug Administration, Fish & Wildlife, EPA, DOT, USDA and the Department of Commerce.
  <br> <br>
Remote Location Filing (RLF)
  <br>
<p>Allows A.J. Arango to clear customs at all parts of entry in the USA for their clients.  This provides Importer a higher level of Customs Compliance simplifies record keeping, reduces communication costs by dealing with one Customs Broker.
  <br> <br>
<b>Bonded Entries, Foreign Trade Zones</b>
  <br>
<p>A.J. Arango deals with all types of Customs Bonded Warehouse and Foreign Trade Zones.  Bonded entries allows importers to take advantage of the  most preferential duty rates or allows for duty free importation and manipulation of goods that will eventually be exported.
  <br> <br>
<b>Bonded Cargo Movements, Transportation Solution</b>
  <br>
<p>A.J. Arango can arrange for delivery of your cargo to all/any destination whether containerized or loose cargo freight whether your transportation needs require Customs Bonded movements, Refrigerated Carrier, Air Ride equipment for sensitive cargo.  A.J. Arango uses an experienced network of transportation Specialists to service your individual needs.
  <br> <br>
<b>Import Air and Ocean Services</b>
 <br>
<p>With a network of specialized agents around the Globe, A.J. Arango can arrange pickup, delivery, and shipping of all types of freight.  Whether you require air freight, full container loads or less than container loads our agents can provide cost effective shipping from most countries.</p>
<br><br>
</div>




<div id="footer">
<img src="images/footerbar.gif" width="899" height="19">
Copyright 2008 AJArango, Inc. All Rights Reserved Worldwide.<BR>
AJArango is a Customs Broker with Customs Brokerage Services including Import Services, Export Services, 
Insurance and Bonding with offices in Tampa and Orlando, Florida.
</div>
</div><br clear="all">
</body>
</html>
