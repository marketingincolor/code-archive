<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <meta name="keywords" content="">
    <meta name="description" content="">
	<title>Contact Us: 
We Will Respond Quickly</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div id="frame">

<div id="topnav">
	<p><?php include("nav.php"); ?> &nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php">Home</a></p>
</div>
<!------header nav------>
<div id="header">
<div style="float:right; padding-right:20px;">
<a href="import.php"><img src="images/import-svc-small.gif" alt="Import Services" border="0"></a>&nbsp;&nbsp;
<a href="export.php"><img src="images/export-svc-small.gif" alt="export services" border="0"></a>&nbsp;&nbsp;
<a href="insurance.php"><img src="images/ins-bonds-small.gif" alt="Insurance And Bonds" border="0"></a>&nbsp;&nbsp;</div>
<img src="images/logo.gif" alt="AJ ARANGO logo" width="300" height="65">
<br>
<img src="images/bottombar.gif" width="899" height="19">
</div>
<!------END header nav------>


<div id="subcontentleft">
<img src="images/ship.jpg" alt="shipping services" width="167" height="191" hspace="0" vspace="0" border="0" />
<br>
<img src="images/truck.jpg" alt="trucking" width="166" height="203" hspace="0" vspace="0" border="0" />
</div>


<div id="subcontentcenter">
<img src="images/contact.jpg" alt="Contact Ajarango" width="435" height="56" hspace="0" vspace="0" border="0" />
<p>Waiting on Contact Form</p>
<br><br>
</div>




<div id="footer">
<img src="images/footerbar.gif" width="899" height="19">
Copyright 2008 AJArango, Inc. All Rights Reserved Worldwide.<BR>
AJArango is a Customs Broker with Customs Brokerage Services including Import Services, Export Services, 
Insurance and Bonding with offices in Tampa and Orlando, Florida.
</div>
</div><br clear="all">
</body>
</html>
