<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <meta name="keywords" content="">
    <meta name="description" content="">
	<title>Insurance & Bonds: 
Use A Firm You Can Trust</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div id="frame">

<div id="topnav">
	<p><?php include("nav.php"); ?> &nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php">Home</a></p>
</div>
<!------header nav------>
<div id="header">
<div style="float:right; padding-right:20px;">
<a href="import.php"><img src="images/import-svc-small.gif" alt="Import Services" border="0"></a>&nbsp;&nbsp;
<a href="export.php"><img src="images/export-svc-small.gif" alt="export services" border="0"></a>&nbsp;&nbsp;
<a href="insurance.php"><img src="images/ins-bonds-small.gif" alt="Insurance And Bonds" border="0"></a>&nbsp;&nbsp;</div>
<img src="images/logo.gif" alt="AJ ARANGO logo" width="300" height="65">
<br>
<img src="images/bottombar.gif" width="899" height="19">
</div>
<!------END header nav------>


<div id="subcontentleft">
<img src="images/ship.jpg" alt="shipping services" width="167" height="191" hspace="0" vspace="0" border="0" />
<br>
<img src="images/truck.jpg" alt="trucking" width="166" height="203" hspace="0" vspace="0" border="0" />
</div>


<div id="subcontentcenter">
<img src="images/insurance.jpg" alt="Insurance" width="435" height="56" hspace="0" vspace="0" border="0" />
<p>Customs Bonds (Surety Bonds) are required to make sure importers guarantee payment for disputed or damaged shipments imported into the country

<p>The U.S. Customs Service requires a Bond to protect the U.S. government in the event the importer does not meet their obligation to pay monies due to US parties.

<p>Without a properly executed bond, your shipment won't clear U.S. Customs.
The writing of a Customs Bond is a very important part of the import transaction. If the Customs Bond is not properly prepared and does not meet certain requirements, you, as the importer of record, may be faced with serious problems. 
<BR><BR>
<b>Types of Customs Bonds:</b>
<BR>
<p>Single Transaction Bond or Single Entry Bond (or SEB), for one transaction at one port of entry. The total bond amount is determined by the type of bond required, and U.S. Customs requirement for limit of liability. 
 
<p>Continuous Bond, for all entries at all U.S. ports. Continuous Bonds start at $50,000.00 and is based on 10% of the estimated yearly duties for the upcoming calendar year.   
 <BR><BR>
<b>Marine Cargo Insurance</b>
<BR>AJ Arango works closely with Roanoke Trade Services to arrange coverage tailored to meet your individual cargo insurance needs.

<p>Whether you require insurance on a shipment by shipment basis or have large enough volumes to warrant an annual policy.  A.J. ARANGO is able to provide the most competitive rates to handle your cargo insurance needs.
 
<p>Cargo Insurance is available for both import and export shipping needs.
</p>
<br><br>
</div>




<div id="footer">
<img src="images/footerbar.gif" width="899" height="19">
Copyright 2008 AJArango, Inc. All Rights Reserved Worldwide.<BR>
AJArango is a Customs Broker with Customs Brokerage Services including Import Services, Export Services, 
Insurance and Bonding with offices in Tampa and Orlando, Florida.
</div>
</div><br clear="all">
</body>
</html>
