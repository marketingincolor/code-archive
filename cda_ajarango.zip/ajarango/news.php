<img src="images/ajnews.gif" alt="AJ Arango News" width="275" height="25">
<br>
<p>August 12, 2008<br>
<b>Headline For News Goes Here</b>
<br>
Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed metus nibh, sodales a, porta at, 
vulputate eget, dui. Pellentesque ut nisl. Maecenas tortor turpis, interdum non, sodales non, 
iaculis ac, lacus. Vestibulum auctor, tortor quis iaculis malesuada, libero lectus bibendum purus, 
sit amet tincidunt quam turpis vel lacus. 
<br><br>
August 12, 2008<br>
<b>Headline For News Goes Here</b>
<br>
Aliquam commodo ullamcorper erat. Nullam vel justo in neque porttitor laoreet. Aenean lacus dui, 
consequat eu, adipiscing eget, nonummy non, nisi. Morbi nunc est, dignissim non, ornare sed, luctus 
eu, massa. Vivamus eget quam. Vivamus tincidunt diam nec urna. Curabitur velit.
</p>

<img src="images/shippingnews.gif" alt="Shipping News" width="275" height="25">
<p>
<b>Headline For News Goes Here</b><br>
Maecenas tortor turpis, interdum non, sodales non, iaculis ac, lacus. Vestibulum auctor, tortor 
quis iaculis malesuada, libero lectus bibendum purus, sit amet tincidunt quam turpis vel lacus. 
<br>
<b>Headline For News Goes Here</b><br>
Vestibulum auctor, tortor quis iaculis malesuada, libero lectus bibendum purus, sit amet tincidunt 
quam turpis vel lacus.
<br>
<b>Headline For News Goes Here</b><br>
Maecenas tortor turpis, interdum non, sodales non, iaculis ac, lacus. Vestibulum auctor, tortor 
quis iaculis malesuada, libero lectus bibendum purus, sit amet tincidunt quam turpis vel lacus. 
<br>
<b>Headline For News Goes Here</b><br>
Vestibulum auctor, tortor quis iaculis malesuada, libero lectus bibendum purus, sit amet tincidunt 
quam turpis vel lacus.
</p>