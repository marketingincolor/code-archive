<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <meta name="keywords" content="">
    <meta name="description" content="">	<title>A J Arango Florida Import Export Brokerage Services</title>
    <link rel="stylesheet" type="text/css" href="style.css"></head><body>
<div id="frame">

<div id="topnav">
	<p><?php include("nav.php"); ?></p>
</div>

<div id="header">
	<img src="images/logo.gif" alt="AJ ARANGO logo" width="300" height="65">
	<img src="images/celebrating.gif" alt="Celebrating 60 years" width="420" height="22" style="margin-bottom:20px; margin-right:40px;">
	<br>
	<img src="images/bottombar.gif" width="899" height="19">
</div>

<div id="contentheader">
	<div id="section">
		<img src="images/importservices-icon.gif" alt="Import Services" width="108" height="91">
			<p>consequat ligula nec tortor. Integer eget seInteger eget sem. Integer eget sem. m. Ut vitae enim eu est vehicula  vi</p>
	</div>
	<div id="section">
		<img src="images/importservices-icon.gif" alt="Import Services" width="108" height="91">
		<p>consequat ligula nec tortor. Integer eget seInteger eget sem. Integer eget sem. m. Ut vitae enim eu est vehicula  vi</p>
	</div>
	<div id="section">
		<img src="images/importservices-icon.gif" alt="Import Services" width="108" height="91">
		<p>consequat ligula nec tortor. Integer eget seInteger eget sem. Integer eget sem. m. Ut vitae enim eu est vehicula  vi</p>
	</div>
<br clear="all">
</div>


<div id="contentleft">
<img src="images/ship.jpg" alt="shipping services" width="167" height="191" hspace="0" vspace="0" border="0" />
<br>
<img src="images/truck.jpg" alt="trucking" width="166" height="203" hspace="0" vspace="0" border="0" />
</div>


<div id="contentcenter">
<img src="images/mainhead.gif" alt="AJ Arango Since 1948, World Class Service Is Our Custom" width="331" height="43" hspace="0" vspace="0" border="0" />
<p>A family owned and operated business, started in 1948 by Mr. A.J. Arango. The main office is located in Tampa's Historic 
Latin Quarter, Ybor City, with other offices located at Tampa International Airport and Orlando, Florida.</p>
<img src="images/dad.jpg" width="93" height="97" hspace="6" vspace="3" border="0" align="left" />
<p>A.J. Arango has a wealth of knowledge and experience including 4 licensed customs brokers with a combined experience that 
exceeds 100 years. Because our brokers are in-house, our employees have instant access to a licensed brokers at all times.
This ensures the highest level of Customs Compliance when filing your documentation.</p>

<img src="images/service.jpg" width="186" height="125" hspace="6" vspace="3" border="0" align="right" />
<p>In addition, we constantly update our software and programs, maintaining the latest, most up-to-date systems to coordinate 
with Customs and Border Protection and Department of Commerce.</p>

<p>We offer Remote Location Filing of Entries and enable importer to pay customs duties on a periodic or monthly basis through 
the Customs Border Protections' ACE Program.</p>
<br><br>
</div>

<div id="contentright">
	<?php include("news.php"); ?>
</div>

<br clear="all">
<br>
<div id="footer">
<img src="images/footerbar.gif" width="899" height="19">
Copyright 2008 AJArango, Inc. All Rights Reserved Worldwide.<BR>
AJArango is a Customs Broker with Customs Brokerage Services including Import Services, Export Services, 
Insurance and Bonding with offices in Tampa and Orlando, Florida.
</div>
</div><br clear="all"></body></html>