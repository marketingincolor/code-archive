<?php
include('../nf/init.php');
$nf = new nfFw('modules', 'attached_files attached');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Module";
$data_desc_plural = "Modules";

switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf->modules->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->modules['name'] = "New $data_desc";
		break;
	}

	case 'delete': {
		$model = $nf->modules;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'save': {
		$id = @$nf->modules['id'];
		$nf->modules->save();
		$nf->modules->clearData();
		// save attachments below
		$nf->attached->saveFromJSON('module', $id);
		nf::flash("Changes have been saved.");
		break;
	}

	case 'save_order': {
		$nf->modules->save();
		$nf->modules->clearData();
		nf::flash("$data_desc order has been saved.");
		break;
	}


	case 'reorder': {
		$nf['section'] = 'reorder';
		break;
	}

	default:
}

$nf->modules->rows_all = $nf->modules->find('all', array(
	'order' => 'row_order ASC, LOWER(name) ASC',
	'array_only' => true,
	'update_model_data' => false
));


$nf->attached->find('all', array(
	'order' => 'file_order ASC',
	'conditions' => array('type' => 'module', 'foreign_id' => $nf->modules['id']),
	'fields' => array('upload_id', 'description', 'long_description', 'u.orig_filename'),
	'join' => array('model' => 'uploads u', 'clause' => 'u.id = attached.upload_id')
));


$nf['subcontent_template'] = 'modules';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

