<?php
include('../nf/init.php');
$nf = new nfFw('news', 'attached_files attached', 'franchisees');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "News Item";
$data_desc_plural = "News";

switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf['outlet'] = $nf->news->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->news['name'] = "New $data_desc";
		break;
	}

	case 'delete': {
		$model = $nf->news;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'save': {
		//$nf->news['franchisee_id'] = (int)@$_SESSION['editing_franchisee']['id'];
		$nf->news->franchiseeSave();
		$nf->attached->saveFromJSON('news', $nf->news['id']);
		$nf->news->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	default:
}

$nf->news->rows_all = $nf->news->franchiseeFind('all', array(
	'order' => 'date DESC',
	//'conditions' => array('franchisee_id' => (int)@$_SESSION['editing_franchisee']['id']),
	'update_model_data' => false
));

if ($nf->news['id']) {
	$nf->attached->find('all', array(
		'order' => 'file_order ASC',
		'conditions' => array('type' => 'news', 'foreign_id' => $nf->news['id']),
		'fields' => array('upload_id', 'description', 'u.orig_filename'),
		'join' => array('model' => 'uploads u', 'clause' => 'u.id = attached.upload_id')
	));
}


$nf['subcontent_template'] = 'news';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

