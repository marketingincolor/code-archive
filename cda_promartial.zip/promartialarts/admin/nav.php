<?php
include('../nf/init.php');
$nf = new nfFw('nav', 'pages pages_all', 'null_table nt', 'news', 'events', 'case_studies', 'franchisees');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$nf->nav->nav_name = nf::coalesce(@$_GET['nav_name'], 'primary');
$nf->nav->franchisee_id = (int)@$_SESSION['editing_franchisee']['id'];

switch (@$_REQUEST['action']) {
	case 'delete_franchisee_data': {
		$nf->db->quickQuery("DELETE FROM nav WHERE name=? AND franchisee_id=?", @$_GET['nav_name'], $nf->nav->franchisee_id);
		nf::flash('Franchisee customized Navigation has been removed, and [TEMPLATE] Navigation is now being used');
		break;
	}

	case 'save': {
		$nf->nav->save();
		nf::flash('Changes have been saved');
		break;
	}

	default:
}

$nf->nav->load();

// If this franchisee doesn't have a nav yet, pull one from the [TEMPLATE] franchisee
if ($nf->nav->franchisee_id) {
	if (!$nf->nav->nav_array) {
		$tpl_franchisee = $nf->franchisees->template_row();
		$nf->nav->franchisee_id = $tpl_franchisee['id'];
		$nf->nav->load();
		$nf->nav->franchisee_id = (int)@$_SESSION['editing_franchisee']['id'];
		$nf->nav->data_source = 'franchisee_template';
	} else {
		$nf->nav->data_source = 'franchisee';
	}
}


$nf->pages_all->find('all', array('order' => 'LOWER(name) ASC'));
$nf->news->find('all', array('order' => 'date DESC, LOWER(name) ASC'));
$nf->events->find('all', array('order' => 'date DESC, LOWER(name) ASC'));
$nf->case_studies->find('all', array('order' => 'row_order ASC, LOWER(name) ASC'));

$nf['subcontent_template'] = 'nav';
$nf['content_template'] = 'admin/admin_page';
$nf->page_css = array('jstree');
$nf->page_scripts = array('nffuncs', 'simplemodal', 'json', 'jstree');
include($nf->base_dir ."templates/admin/main.php");

