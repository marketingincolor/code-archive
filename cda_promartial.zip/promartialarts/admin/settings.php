<?php
include('../nf/init.php');
$nf = new nfFw('users admin', 'settings');

$nf->auth->secure();
$nf->auth->checkAuthorized();

switch (@$_REQUEST['action']) {
	case 'save': {
		$nf->settings->save();

		if (!$nf->admin['password']) {
			unset($nf->admin['password']);
		} else {
			$nf->admin['password'] = md5($nf->admin['password']);
		}
		$nf->admin->save();

		nf::flash('Settings saved.');
		break;
	}

	default:
}

$nf->settings->find('first');

$sounds = glob($nf->base_dir .'sounds/*.mp3');
foreach ($sounds as $index => $sound) {
	$sounds[$index] = basename($sound);
}
$nf['alert_sounds'] = $sounds;

$nf->admin->find('first', array(
	'conditions' => array(
		'username' => 'admin'
	)
));
$nf->admin['password'] = '';


$nf->page_scripts = array('fck', 'nffuncs');

$nf['subcontent_template'] = 'settings';
$nf['content_template'] = 'admin/admin_page';
include($nf->base_dir ."templates/admin/main.php");

