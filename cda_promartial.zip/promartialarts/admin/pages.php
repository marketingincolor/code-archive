<?php
include('../nf/init.php');
$nf = new nfFw(
	'pages',
	'page_tabs',
	'attached_files attached',
	'download_categories cats',
	'generic',
	'franchisees',
	'bonus_box_options box_opts'
);

$data_desc = "Page";
$data_desc_plural = "Pages";

$nf->auth->secure();
$nf->auth->checkAuthorized();

switch (@$_REQUEST['action']) {
	case 'get_bonus_box_options': {
		$nf->box_opts->find('first', array(
			'conditions' => array(
				'page_id' => @$_GET['page_id'],
				'type' => @$_GET['bonus_box_type'],
			)
		));

		$nf->box_opts['page_id'] = @$_GET['page_id'];
		$nf->box_opts['type'] = @$_GET['bonus_box_type'];

		// security
		if (!in_array(@$_GET['bonus_box_type'], array_keys($nf->pages->bonus_box_types))) {
			exit;
		}

		ob_start();
		@include($nf->base_dir ."templates/admin/pieces/bonus_box/". @$_GET['bonus_box_type'] .".php");
		$html = ob_get_clean();

		echo json_encode(array(
			'html' => $html
		));
		exit;
	}

	case 'load_tab': {
		$index = @$_POST['index'];
		$nf->page_tabs->data[$index] = (array)@$_POST['data']['page_tabs'][$index];
		$nf->page_tabs->index = $index;
		include($nf->base_dir ."templates/admin/pieces/page_tab.php");
		exit;
	}

	case 'edit': {
		$nf['page'] = $nf->pages->find('first', array('conditions' => array(
			'or' => array(
				'id' => @$_GET['id'],
				'url' => @$_GET['url']
			)
		)));
		break;
	}

	case 'new': {
		$nf->pages['name'] = 'New page';
		$nf->pages['layout_type'] = 'type1';
		break;
	}

	case 'delete': {
		$model = $nf->pages;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}


	case 'save': {
		$nf->pages['type'] = 'page';
		$nf->pages['franchisee_id'] = (int)@$_SESSION['editing_franchisee']['id'];
		$nf->pages->save();
		$nf->attached->saveFromJSON('page', $nf->pages['id']);

		if ($nf->box_opts->numRows() > 0) {
			$nf->box_opts['page_id'] = $nf->pages['id'];
			$nf->box_opts->delete(array(
				'page_id' => $nf->box_opts['page_id'],
				'type' => $nf->box_opts['type'],
			));
			$nf->box_opts->save();
		}

		$nf->page_tabs->delete(array(
			'page_id' => $nf->pages['id']
		));
		$nf->page_tabs->setColumn('id', null);
		$nf->page_tabs->save();

		/*
		$nf->page_galleries->delete(array('page_id' => $nf->pages['id']));
		$nf->page_galleries->save();
		*/

		/*
		$nf->page_videos->delete(array('page_id' => $nf->pages['id']));
		$nf->page_videos->save();
		*/

		nf::flash("Changes have been saved.");
		break;
	}

	default:
}


$nf->pages->rows_all = $nf->pages->find('all', array(
	'order' => 'LOWER(name) ASC',
	'update_model_data' => false,
	'array_only' => 'true',
	'conditions' => array('franchisee_id' => (int)@$_SESSION['editing_franchisee']['id'])
));

if (@$_SESSION['editing_franchisee']) {
	$nf->pages->franchisee_urls_all = $nf->pages->column('url', $nf->pages->rows_all);

	$nf['template_row'] = $nf->franchisees->template_row();
	$nf->pages->template_rows_all = $nf->pages->find('all', array(
		'order' => 'LOWER(name) ASC',
		'update_model_data' => false,
		'array_only' => 'true',
		'conditions' => array(
			'franchisee_id' => $nf['template_row']['id'],
			($nf->pages->franchisee_urls_all ? array('url NOT IN' => $nf->pages->franchisee_urls_all) : array())
		)
	));
}

if ($nf->pages->numRows() > 0) {
	$nf->attached->find('all', array(
		'order' => 'file_order ASC',
		'conditions' => array('type' => 'page', 'foreign_id' => $nf->pages['id']),
		'fields' => array('upload_id', 'description', 'u.orig_filename'),
		'join' => array('model' => 'uploads u', 'clause' => 'u.id = attached.upload_id')
	));

	$nf->page_tabs->find('all', array(
		'conditions' => array(
			'page_id' => $nf->pages['id']
		),
		'order' => 'row_order ASC'
	));

	$nf->cats->rows_all = $nf->cats->find('all', array(
		'order' => 'LOWER(name) ASC',
		'array_only' => true,
	));

	/*
	$nf->page_galleries->find('all', array(
		'order' => 'row_order ASC, LOWER(name) ASC',
		'conditions' => array(
			'page_galleries.page_id' => $nf->pages['id']
		),
		'fields' => array('page_galleries.*', 'galleries.name'),
		'join' => array(
			'type' => 'left',
			'model' => 'galleries',
			'clause' => 'page_galleries.gallery_id = galleries.id'
		)
	));
	$nf->galleries->find('all', array('order' => 'LOWER(name) ASC'));

	$nf->page_videos->find('all', array(
		'order' => 'row_order ASC, LOWER(description) ASC',
		'conditions' => array(
			'page_videos.page_id' => $nf->pages['id']
		),
		'fields' => array('page_videos.*', 'videos.description'),
		'join' => array(
			'type' => 'left',
			'model' => 'videos',
			'clause' => 'page_videos.video_id = videos.id'
		)
	));

	$nf->videos->find('all', array('order' => 'LOWER(description) ASC'));
	*/
}

$perms = $nf->db->quickQuery("SELECT DISTINCT permissions FROM users");
$perms_array = array_unique(explode(',', implode(',', nf::arrayFlatten($perms))));
$perms_selectable = array();
foreach ($perms_array as $perm) {
	$perms_selectable[$perm] = ucfirst($perm);
}
$nf->pages->perms_all = $perms_selectable;


$nf['subcontent_template'] = 'pages';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs', 'colorpicker', 'scrollto');
$nf->page_css = array('smoothness', 'colorpicker');
include($nf->base_dir ."templates/admin/main.php");

