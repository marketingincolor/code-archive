<?php
include('../nf/init.php');
$nf = new nfFw(
	'classes',
	'classes_times times',
	'calendar'
);

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Class";
$data_desc_plural = "Classes";


switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf->classes->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->classes['name'] = "New $data_desc";
		break;
	}

	case 'delete': {
		$model = $nf->classes;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'save': {
		$nf->classes->franchiseeSave();
		
		$nf->times->setColumn('class_id', $nf->classes['id']);
		foreach ($nf->times as $row) {
			if (!$row['start_time'] && !$row['end_time']) {
				$row->deleteRow();
			}
		}
		$nf->times->delete(array(
			'class_id' => $nf->classes['id']
		));
		$nf->times->save();
		$nf->classes->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	default:
}

$nf->classes->rows_all = $nf->classes->franchiseeFind('all', array(
	'order' => 'LOWER(name) ASC',
	'array_only' => true,
	'update_model_data' => false
));

if ($nf->classes->numRows() > 0) {
	$nf->times->id_field = 'day';
	$nf->times->find('all', array(
		'conditions' => array(
			'class_id' => $nf->classes['id']
		),
		'array_only' => true,
		'by_id' => true
	));
	$nf->times->id_field = 'id';
}



$nf['subcontent_template'] = 'classes';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('currency', 'jqueryui', 'timepicker', 'admin_time_inputs');
$nf->page_css = array('smoothness');
//$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

