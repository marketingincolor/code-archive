<?php
include('../nf/init.php');
$nf = new nfFw('shield');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "SHIELD Plan";
$data_desc_plural = "SHIELD Plans";


switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf->shield->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->shield['name'] = "New $data_desc";
		break;
	}

	case 'delete': {
		$model = $nf->shield;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'save': {
		$nf->shield->save();
		$nf->shield->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	default:
}

$nf->shield->rows_all = $nf->shield->find('all', array(
	'order' => 'row_order ASC',
	'array_only' => true,
	'update_model_data' => false
));



$nf['subcontent_template'] = 'shield';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('currency');
//$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

