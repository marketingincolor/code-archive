<?php
include('../nf/init.php');
$nf = new nfFw('collection_fee_prices prices', 'collection_fees fees');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Collection Fee Price";
$data_desc_plural = "Collection Fee Prices";

$nf->fees->find('id', @$_GET['fee_id']);
if (!$nf->fees->numRows()) {
	nf::redirect('collection_fees.php');
}

switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf->prices->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->prices['name'] = "New $data_desc";
		$nf->prices['fee_id'] = $nf->fees['id'];
		break;
	}

	case 'delete': {
		$model = $nf->prices;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'save': {
		$nf->prices->save();
		$nf->prices->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	default:
}

$nf->prices->rows_all = $nf->prices->find('all', array(
	'conditions' => array(
		'fee_id' => $nf->fees['id']
	),
	'order' => 'quantity_from ASC',
	'array_only' => true,
	'update_model_data' => false
));



$nf['subcontent_template'] = 'collection_fee_prices';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('currency');
//$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

