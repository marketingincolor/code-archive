<?php
include('../nf/init.php');
$nf = new nfFw(
	'videos'
);

$nf->auth->secure();
$nf->auth->checkAuthorized();


$data_desc = "Video";
$data_desc_plural = "Videos";

switch (@$_REQUEST['action']) {
	case 'new_videos': {
		foreach ($nf->videos as $index => $row) {
			if (!$row['description']) {
				$nf->videos[$index]['description'] = $nf->upload->filenameToDescription($row['orig_filename']);
			}
		}
		$nf->videos->save();
		nf::flash("New video(s) have been added");
		$nf['section'] = 'upload';
		break;
	}

	case 'save_descriptions': {
		$nf->videos->save();
		nf::flash("Descriptions have been saved");
		break;
	}

	case 'edit': {
		$id = nf::coalesce(@$_GET['id'], @$_GET['url']);
		break;
	}

	case 'delete': {
		$model = $nf->videos;
		include($nf->base_dir .'admin/pieces/delete.php');
		break;
	}

	case 'save': {
		$id = @$nf->videos['id'];

		foreach ($nf->videos as $index => $row) {
			if (!$row['description']) {
				$nf->videos[$index]['description'] = $nf->upload->filenameToDescription($row['orig_filename']);
			}
		}

		$nf->videos->save();
		nf::flash("Changes have been saved.");
		$nf->videos->clearData();
		unset($id);
		break;
	}

	case 'upload': {
		$nf['section'] = 'upload';
		break;
	}

	default:
}


//*** See if any videos need to be converted
$nf->videos->convert_all();


$nf->videos->rows_all = $nf->videos->find('all', array(
	'order' => 'LOWER(description) ASC',
	'fields' => array('id', 'upload_id', new nfDbExpression('"video" attachment_type'), 'description', 'conversion_error', 'u.orig_filename', 'u.mime_type'),
	'join' => array(
		'model' => 'uploads u',
		'clause' => 'u.id = videos.upload_id'
	),
	'by_id' => true,
));


if (@$id) {
	$nf['video'] = $nf->videos->find('id', $id);
} else {
	$no_desc = array();
	$need_convert = array();

	foreach ($nf->videos->rows_all as $index => $video) {
		if (!$video['description']) {
			$no_desc[] = $index;
			//$nf->videos->rows_all[$index]['description'] = $nf->upload->filenameToDescription($video['orig_filename']);
		}
		if ($video['mime_type'] != 'video/x-flv') { $need_convert[] = $index; }
	}

	$nf['no_description'] = $no_desc;
	$nf['need_convert'] = $need_convert;
}


$nf['subcontent_template'] = 'videos';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs', 'swfobject');
//$nf->page_css = array('start');
include($nf->base_dir ."templates/admin/main.php");

