<?php
include('../nf/init.php');
$nf = new nfFw('service_types stypes', 'services', 'attached_files attached');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Service";
$data_desc_plural = "Services";

$nf->stypes->find('id', @$_GET['type_id']);
if (!$nf->stypes->numRows()) {
	nf::redirect('service_types.php');
}

switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf->services->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->services['name'] = "New $data_desc";
		$nf->services['suffix'] = "each";
		$nf->services['service_type_id'] = $nf->stypes['id'];
		break;
	}

	case 'delete': {
		$model = $nf->services;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'save': {
		$nf->services->save();
		$nf->services->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	case 'save_order': {
		$nf->services->save();
		$nf->services->clearData();
		nf::flash("$data_desc order has been saved.");
		break;
	}


	case 'reorder': {
		$nf['section'] = 'reorder';
		break;
	}

	default:
}

$nf->services->rows_all = $nf->services->find('all', array(
	'order' => 'LOWER(name) ASC',
	'conditions' => array(
		'service_type_id' => $nf->stypes['id']
	),
	//'array_only' => true,
	'update_model_data' => false
));


$services_by_id = $nf->services->find('all', array(
	'order' => 'LOWER(name) ASC',
	'array_only' => true,
	'update_model_data' => false
));
$out = array();
foreach ($services_by_id as $service) {
	$out[$service['id']] = $service;
}
$nf->services->all_by_id = $out;


$nf['subcontent_template'] = 'services';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('currency', 'php_js', 'js1.6');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

