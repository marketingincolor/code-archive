<?php
include('../nf/init.php');
$nf = new nfFw('service_types stypes', 'attached_files attached');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Service Type";
$data_desc_plural = "Service Types";

switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf->stypes->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->stypes['name'] = "New $data_desc";
		break;
	}

	case 'delete': {
		$model = $nf->stypes;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'save': {
		$nf->stypes['franchisee_id'] = (int)@$_SESSION['editing_franchisee']['id'];
		$nf->stypes->save();
		$nf->stypes->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	case 'save_order': {
		$nf->stypes->save();
		$nf->stypes->clearData();
		nf::flash("$data_desc order has been saved.");
		break;
	}


	case 'reorder': {
		$nf['section'] = 'reorder';
		break;
	}

	default:
}

$nf->stypes->rows_all = $nf->stypes->find('all', array(
	'fields' => 'id,name,(SELECT COUNT(*) FROM services s WHERE s.service_type_id=stypes.id) type_count',
	'order' => 'LOWER(stypes.name) ASC',
	'conditions' => array(
		'hidden' => 0
	),
	'array_only' => true,
	'update_model_data' => false,
));



$nf['subcontent_template'] = 'service_types';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

