<?php
include_once(dirname(__FILE__) .'/../nf/init.php');
$nf = new nfFw();

if ($nf->auth['type'] == 'franchisee') {
	nf::redirect('/franchisee_admin');
}

$nf->auth->secure();
$nf->auth->checkAuthorized();

$nf['subcontent_template'] = 'index';
$nf['content_template'] = 'admin/admin_page';
include($nf->base_dir ."templates/admin/main.php");
