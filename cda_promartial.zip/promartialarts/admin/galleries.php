<?php
include('../nf/init.php');
$nf = new nfFw(
	'galleries',
	'attached_files images',
	'franchisees'
);

$nf->auth->secure();
$nf->auth->checkAuthorized();


$data_desc = "Gallery";
$data_desc_plural = "Galleries";

switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf->galleries->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->galleries['name'] = "New $data_desc";
		break;
	}

	case 'delete': {
		$model = $nf->galleries;
		include($nf->base_dir .'admin/pieces/delete.php');
		break;
	}

	case 'save': {
		$nf->galleries->franchiseeSave();
		$nf->images->saveFromJSON('gallery', $nf->galleries['id']);
		$nf->galleries->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	case 'reorder': {
		$nf['section'] = 'reorder';
		break;
	}

	default:
}


if ($nf->galleries->numRows() > 0) {
	$nf->images->find('all', array(
		'order' => 'file_order ASC',
		'conditions' => array('type' => 'gallery', 'foreign_id' => $nf->galleries['id']),
		'fields' => array('upload_id', 'description', 'u.orig_filename'),
		'join' => array('model' => 'uploads u', 'clause' => 'u.id = images.upload_id')
	));
}


$nf->galleries->rows_all = $nf->galleries->franchiseeFind('all', array(
	'fields' => 'g.id,g.url,g.preview_img,g.name, (SELECT COUNT(*) FROM attached_files a WHERE a.type="gallery" AND a.foreign_id=g.id) image_count',
	'alias' => 'g',
	'order' => 'LOWER(name) ASC',
	'array_only' => true,
	'update_model_data' => false
));


$nf['subcontent_template'] = 'galleries';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs', 'swfobject');
//$nf->page_css = array('start');
include($nf->base_dir ."templates/admin/main.php");

