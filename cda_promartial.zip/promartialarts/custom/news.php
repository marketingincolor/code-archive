<?php
/* Label: "News" */

$nf->instantiate('news', 'home_page');

$nf->home_page->find('first');
$nf['nb_title'] = $nf->home_page['smallbox3_title'];
$nf['nb_copy'] = $nf->home_page['smallbox3_content'];

if (@$_GET['arg1']) {
	$view = 'news_item';
} else {
	$view = 'news';
}


$template = $view;
switch ($view) {
	case 'news_item':
		$nf->news->id_field = 'url';
		$nf->news->franchiseeFind('id', @$_GET['arg1'], array(
			'actiontype' => 'viewing'
		));
		break;

	case 'news':
	default:
		$nf->news->page = nf::coalesce(@$_GET['page'], 1);
		$nf->news->franchiseeFind('all', array(
			'order' => 'date DESC, id ASC',
			'actiontype' => 'viewing'
		));
}

// Get generic CMS page data
include($nf->base_dir ."custom/pieces/subpage_setup.php");

$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = $template;
$nf['content_template'] = (($nf->franchisees->numRows() == 0) ? 'subpage' : 'franchisee_subpage');
// Main layout template
include($nf->base_dir ."templates/main.php");

