<?php
/* Label: "Events" */

$nf->instantiate('events', 'home_page');

$nf->home_page->find('first');
$nf['nb_title'] = $nf->home_page['smallbox3_title'];
$nf['nb_copy'] = $nf->home_page['smallbox3_content'];

if (@$_GET['arg1']) {
	$view = 'event';
} else {
	$view = 'events';
}


$template = $view;
switch ($view) {
	case 'event':
		$nf->events->id_field = 'url';
		$nf->events->franchiseeFind('id', @$_GET['arg1'], array(
			'actiontype' => 'viewing'
		));
		
		break;

	case 'events':
	default:
		$nf->events->page = nf::coalesce(@$_GET['page'], 1);
		$nf->events->franchiseeFind('all', array(
			'conditions' => array(
				'date >= DATE(NOW())',
				'is_additional_day' => 'No'
			),
			'order' => 'date ASC',
			'actiontype' => 'viewing'
		));

}


// Hack to allow paging links to work
$last_opts = $nf->events->last_opts;
$page = $nf->events->page;
$nf->events->page = null;

// Slight hack to accommodate multiple days per event
foreach ($nf->events as $event) {
	// Get list of additional days for $event
	$days = $nf->events->find('all', array(
		'fields' => 'date, start_time, end_time',
		'conditions' => array(
			'is_additional_day' => 'Yes',
			'first_day_id' => $event['id']
		),
		'array_only' => true,
		'update_model_data' => false
	));

	// Add $event's day to the list of days
	array_unshift($days, array(
		'date' => $event['date'],
		'start_time' => $event['start_time'],
		'end_time' => $event['end_time'],
	));

	$event['days'] = $days;
}

// Hack to allow paging links to work
$nf->events->last_opts = $last_opts;
$nf->events->page = $page;

// Get generic CMS page data
include($nf->base_dir ."custom/pieces/subpage_setup.php");

$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = $template;
$nf['content_template'] = (($nf->franchisees->numRows() == 0) ? 'subpage' : 'franchisee_subpage');
// Main layout template
include($nf->base_dir ."templates/main.php");

