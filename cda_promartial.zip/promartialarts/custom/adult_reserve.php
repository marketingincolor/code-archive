<?php
/* Label: "Adult Reservation" */

$nf->instantiate('adult_reserve_contacts contacts', 'events');
		
// Get generic CMS page data
include($nf->base_dir ."custom/pieces/subpage_setup.php");

switch (@$_REQUEST['action']) {
	case 'save': {
		/*if ($nf->contacts['is_child'] == 'Child') {
			$nf->contacts->fields = array_merge(
				$nf->contacts->fields,
				$nf->contacts->fields_with_child
			);
			$nf->contacts->buildFields();
		}*/

		if (!$nf->contacts->validates()) {
			nf::flash("Please fill in all fields colored in red, then press the Submit button again", "error");
			break;
		}

		nf::flash("Your info has been saved. Thank you for contacting us.");

		$nf->contacts->save();

		ob_start();
		include($nf->base_dir .'templates/email/free_trial.php');
		$body = ob_get_clean();

		include_once($nf->base_dir .'nf/3rdparty/class.phpmailer.php');
		$mail = new PHPMailer(); // defaults to using php "mail()"
		$mail->LE = "\n";

		$mail->From = $nf->settings['from_email'];
		$mail->FromName = $nf->settings['site_name'];
		$mail->Subject = '['. $nf->settings['site_name'] .'] Adults Armor Program form submission ';
		$mail->Body = $body;
		$mail->IsHTML(false);

		if ($nf->franchisees->current('email', 'viewing')) {
			$mail->AddAddress($nf->franchisees->current('email', 'viewing'));
		} else {
			$mail->AddAddress($nf->settings['contact_email']);
		}

		if (strlen(trim($nf->settings['contact_email_bcc'])) > 0) {
			$mail->AddBcc($nf->settings['contact_email_bcc']);
		}

		$rv = $mail->Send();


		$nf->contacts->clearData();
		break;
	}
	
	case 'count': {

        $id = $_POST['id'];
		$this_class_count = $nf->contacts->get_coursecount($id);
		echo $this_class_count;
		break;
	}

	default:
		break;
}

$this_franchisee = $nf->franchisees->current('id');
$class_dates = $nf->events->find('all', array(
			'fields' => array('id', 'name', 'date', 'title'),
			'where' => array('franchisee_id' => ''.$this_franchisee.'', 'name' =>'Armor Adult Seminar')
		));

$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'adult_reserve';
$nf['content_template'] = (($nf->franchisees->numRows() == 0) ? 'subpage' : 'franchisee_subpage');
$nf->page_css = array('lightness');
$nf->page_scripts = array('jqueryui');
// Main layout template

include($nf->base_dir ."templates/main.php");

