<?php
include_once('nf/init.php');
$nf = new nfFw('faqs');


//$nf->staff->rows_per_page = 4;
//$nf->staff->page = nf::coalesce(@$_GET['page'], 1);
$nf->faqs->find('all', array(
	'order' => 'row_order ASC, LOWER(name) ASC'
));


// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'faqs';
$nf['content_template'] = 'subpage';
// Main layout template
include($nf->base_dir ."templates/main.php");

