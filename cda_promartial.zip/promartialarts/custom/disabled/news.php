<?php
/* Label: "News Listing" */

$nf->instantiate('news');


$nf->news->page = nf::coalesce(@$_GET['page'], 1);
$nf->news->find('all', array(
	'order' => 'date DESC, id ASC'
));


// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'news';
$nf['content_template'] = 'subpage';
// Main layout template
include($nf->base_dir ."templates/main.php");

