<?php
/* Label: "Case Studies" */

$nf->instantiate('pages', 'settings', 'case_studies');


// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

$nf['current_url'] = $nf->pages['url'];

if (@$_GET['arg1']) {
	$nf->case_studies->find('first', array(
		'conditions' => array(
			'url' => @$_GET['arg1']
		)
	));
	$nf['subcontent_template'] = 'case_study';
} else {
	$nf->case_studies->find('all', array(
		'order' => 'row_order ASC, LOWER(header) ASC'
	));
	$nf['subcontent_template'] = 'case_studies';
}



$nf['content_template'] = 'subpage';
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");

