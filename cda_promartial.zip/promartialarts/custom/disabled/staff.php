<?php
/* Label: "Staff Members" */

$nf->instantiate('pages', 'settings', 'staff');


// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

$nf['current_url'] = $nf->pages['url'];

$nf->staff->find('all', array(
	'order' => 'row_order ASC, LOWER(name) ASC'
));


$nf['subcontent_template'] = 'staff';
$nf['content_template'] = 'subpage';
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");

