<?php
/* Label: "News Item (individual)" */
$nf->instantiate('news' , 'attached_files attached');


$nf->news->find('id', @$_GET['arg1']);
$nf['title'] = $nf->news['title'];

// Get generic CMS page data
include($nf->base_dir ."custom/pieces/subpage_setup.php");


/*
$attachments = array();
$attachments['downloads'] = $nf->attached->find('all', array(
		'order' => 'file_order ASC',
		'conditions' => array('type' => 'news', 'foreign_id' => $nf->news['id']),
		'fields' => array('upload_id', 'description', 'u.orig_filename'),
		'join' => array('model' => 'uploads u', 'clause' => 'u.id = attached.upload_id')
	));
	
$nf['attachments'] = $attachments;
*/


$nf->pages['header'] = $nf->news['title'];

$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'news_item';
$nf['content_template'] = 'subpage';
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");

