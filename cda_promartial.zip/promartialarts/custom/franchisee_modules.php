<?php
/* Label: "Franchisee Modules (modules)" */
$nf->instantiate('download_categories cats', 'modules', 'attached_files attached');

// Get generic CMS page data
include($nf->base_dir ."custom/pieces/subpage_setup.php");

$nf->cats->find('all', array(
	'order' => 'LOWER(name) ASC',
));

if (@$_GET['mn']) {
	$view = 'module_view';
	$modulename = $_GET['mn'];
} else {
	$view = 'modules_view';
	$modulename = '';
}
$template = $view;
switch ($view) {
	case 'module_view': {
		$nf->modules->find('all', array(
		'where' => array(
			'name' => $_GET['mn']
		),
			'order' => 'row_order ASC'
		));
		
		$nf->attached->find('all', array(
			'order' => 'file_order ASC',
			'conditions' => array('type' => 'module', 'long_description' => $_GET['mn']),
			'fields' => array('upload_id', 'description', 'u.orig_filename', 'u.filename'),
			'join' => array('model' => 'uploads u', 'clause' => 'u.id = attached.upload_id'),
			'array_only' => true
		));
		
		$has_videos = ($nf->attached['description'] == 'Video') ? 'true' : '';
		$has_photos = $nf->attached->find('all', array(
			'conditions' => array('type' => 'module', 'description' => 'Photo', 'long_description' => $_GET['mn']),
			'fields' => array('upload_id', 'description', 'u.orig_filename', 'u.filename'),
			'join' => array('model' => 'uploads u', 'clause' => 'u.id = attached.upload_id')
		)); 
		//$has_photos = ($nf->attached['description'] == 'Photo') ? 'true' : '';
		
		$has_posters = ($nf->attached['description'] == 'Poster') ? $nf->attached['filename'] : '';
		
		break;
	}

	case 'modules_view': {
		$nf->modules->find('all', array(
			'order' => 'row_order ASC'
		));
		break;
	}
		
	default: {
		$nf->modules->find('all', array(
			'order' => 'row_order ASC'
		));
	}
}

require_once($nf->base_dir ."includes/tcpdf/tcpdf.php");
require_once($nf->base_dir ."includes/tcpdf/config/lang/eng.php");
require_once($nf->base_dir ."includes/fpdi/fpdi.php");

switch (@$_REQUEST['action']) {
	case 'photos': {
		//while($row = mysql_fetch_array($has_photos))
  		//{
  		//	echo $row['filename'];
  		//}
  		echo is_array($has_photos) ? 'Array' : 'not an Array';
		print_r($has_photos);
		//header("Location: http://google.com");
		exit;
	}
	case 'fullpdf': {
		$thisfilename = isset($_GET['mn']) ? strtolower($_GET['mn']) : 'other';

		class PDF extends FPDI {
		    var $_tplIdx;
		    function Header() {
                global $nf;

		        if (is_null($this->_tplIdx)) {
                    $this->setSourceFile($nf->base_dir .'templates/postscript/ce_p1.pdf');
		            $this->_tplIdx = $this->importPage(1);
		        }
		        $this->useTemplate($this->_tplIdx);
		    }
		    function Footer() {}
		}

		$pdf = new PDF();
		$pdf->SetMargins(PDF_MARGIN_LEFT, 60, PDF_MARGIN_RIGHT); 
		$pdf->SetAutoPageBreak(true, 60); 
		$pdf->setFontSubsetting(false);
		
		$pdf->AddPage();
		
		$scriptname = $_GET['mn'];
        $nf->modules->find('first', array('conditions' => array('name' => $scriptname)));
		
        $pdf->SetFont('freesans', 'R', 12);
        $pdf->SetTextColor(0, 0, 0);
		$html = '<h1 color="#D2232B">'.$nf->modules['name'].'</h1>';
		$html .= $nf->modules['intro'].'<br />';
		$html .= $nf->modules['quotes'].'<br />';
		if ($nf->modules['w1_subhead']) {
			$html .= '<h4>'.strtoupper('Highlights of '.$nf->modules['name'].' Module').'</h4>';
			$html .= '<ul>';
			$html .= '<li>'.$nf->modules['w1_title'].' - ';
			$html .= $nf->modules['w1_subhead'].'</li><br />';
			$html .= '<li>'.$nf->modules['w2_title'].' - ';
			$html .= $nf->modules['w2_subhead'].'</li><br />';
			$html .= '<li>'.$nf->modules['w3_title'].' - ';
			$html .= $nf->modules['w3_subhead'].'</li><br />';
			$html .= '<li>'.$nf->modules['w4_title'].' - ';
			$html .= $nf->modules['w4_subhead'].'</li><br />';
			if ($nf->modules['w5_title']) {
				$html .= '<li>'.$nf->modules['w5_title'].' - ';
				$html .= $nf->modules['w5_subhead'].'</li><br />';
			}
			if ($nf->modules['w6_title']) {
				$html .= '<li>'.$nf->modules['w6_title'].' - ';
				$html .= $nf->modules['w6_subhead'].'</li><br />';
			}
			$html .= '</ul>';
		}
		$pdf->writeHTMLCell(160, 8, 31, 56, $html, 0, 1, 0, true, 'L', true);
		$pdf->lastPage();

		$pdf->AddPage();
        $pdf->SetFont('freesans', 'R', 9);
        $pdf->SetTextColor(0, 0, 0);
		$html = '<p color="#176B8D">Week One Script</p>';
		$html .= '<h2 color="#D2232B">'.$nf->modules['w1_title'].'</h2>';
		$html .= $nf->modules['w1_notes'];
		$html .= str_replace('<p>&nbsp;</p>','',$nf->modules['w1_script']);
		$pdf->writeHTMLCell(160, 8, 31, 56, $html, 0, 1, 0, true, 'L', true);
		$pdf->lastPage();

		$pdf->AddPage();
		$html = '<p color="#176B8D">Week Two Script</p>';
		$html .= '<h2 color="#D2232B">'.$nf->modules['w2_title'].'</h2>';
		$html .= $nf->modules['w2_notes'];
		$html .= str_replace('<p>&nbsp;</p>','',$nf->modules['w2_script']);
		$pdf->writeHTMLCell(160, 8, 31, 56, $html, 0, 1, 0, true, 'L', true);
		$pdf->lastPage();

		$pdf->AddPage();
		$html = '<p color="#176B8D">Week Three Script</p>';
		$html .= '<h2 color="#D2232B">'.$nf->modules['w3_title'].'</h2>';
		$html .= $nf->modules['w3_notes'];
		$html .= str_replace('<p>&nbsp;</p>','',$nf->modules['w3_script']);
		$pdf->writeHTMLCell(160, 8, 31, 56, $html, 0, 1, 0, true, 'L', true);
		$pdf->lastPage();

		$pdf->AddPage();
		$html = '<p color="#176B8D">Week Four Script</p>';
		$html .= '<h2 color="#D2232B">'.$nf->modules['w4_title'].'</h2>';
		$html .= $nf->modules['w4_notes'];
		$html .= str_replace('<p>&nbsp;</p>','',$nf->modules['w4_script']);
		$pdf->writeHTMLCell(160, 8, 31, 56, $html, 0, 1, 0, true, 'L', true);
		// writeHTMLCell($w, $h, $x, $y, $html='', $border=0, $ln=0, $fill=0, $reseth=true, $align='', $autopadding=true)
        //$pdf->writeHTMLCell(150, 8, 31, 60, $html, 0, 1, 0, true, 'L', true);

		
		if ($nf->modules['w5_title']) {
				$pdf->lastPage();
				
				$pdf->AddPage();
				$html = '<p color="#176B8D">Week Five Script</p>';
				$html .= '<h2 color="#D2232B">'.$nf->modules['w5_title'].'</h2>';
				$html .= $nf->modules['w5_notes'];
				$html .= str_replace('<p>&nbsp;</p>','',$nf->modules['w5_script']);
				$pdf->writeHTMLCell(160, 8, 31, 56, $html, 0, 1, 0, true, 'L', true);
		}
		
		if ($nf->modules['w6_title']) {
				$pdf->lastPage();
				
				$pdf->AddPage();
				$html = '<p color="#176B8D">Week Six Script</p>';
				$html .= '<h2 color="#D2232B">'.$nf->modules['w6_title'].'</h2>';
				$html .= $nf->modules['w6_notes'];
				$html .= str_replace('<p>&nbsp;</p>','',$nf->modules['w6_script']);
				$pdf->writeHTMLCell(160, 8, 31, 56, $html, 0, 1, 0, true, 'L', true);
		}

		$pdf->Output( $thisfilename .'_module.pdf', 'D');
		break;
	}
	
	case 'posterpdf': {
		$thisfilename = isset($_GET['mn']) ? strtolower($_GET['mn']) : 'other';
		$weeknum = isset($_GET['w']) ? $_GET['w'] : 'other';
		class PDF extends FPDI {
		    var $_tplIdx;
		    function Header() {
                global $nf;

		        if (is_null($this->_tplIdx)) {
                    $this->setSourceFile($nf->base_dir .'templates/postscript/'. strtolower($_GET['mn']) .'/'. strtolower($_GET['mn']) .'-wk'.$_GET['w'].'.pdf');
		            $this->_tplIdx = $this->importPage(1);
		        }
		        $this->useTemplate($this->_tplIdx);
		    }
		    function Footer() {}
		}
		$pdf = new PDF();
		$pdf->SetMargins(PDF_MARGIN_LEFT, 20, PDF_MARGIN_RIGHT); 
		$pdf->SetAutoPageBreak(true, 60); 
		$pdf->setFontSubsetting(false);
		
		$pdf->AddPage();
		//$pdf->Output($has_posters, 'D');
		$pdf->Output($thisfilename.'_wk'.$weeknum.'poster.pdf', 'D');
		
		break;
	}
	
	case 'coverpdf': {
		$thisfilename = isset($_GET['mn']) ? strtolower($_GET['mn']) : 'other';

		class PDF extends FPDI {
		    var $_tplIdx;
		    function Header() {
                global $nf;

		        if (is_null($this->_tplIdx)) {
                    $this->setSourceFile($nf->base_dir .'templates/postscript/ce_cover.pdf');
		            $this->_tplIdx = $this->importPage(1);
		        }
		        $this->useTemplate($this->_tplIdx);
		    }
		    function Footer() {}
		}
		$pdf = new PDF();
		$pdf->SetMargins(PDF_MARGIN_LEFT, 20, PDF_MARGIN_RIGHT); 
		$pdf->SetAutoPageBreak(true, 60); 
		$pdf->setFontSubsetting(false);
		
		$pdf->AddPage();
		$pdf->Output($thisfilename.'_coversheet.pdf', 'D');
		
		break;
	}
	
	case 'lesson': {
		$thisfilename = isset($_GET['w']) ? $_GET['w'] : 'other';
		
		class PDF extends FPDI {
		    var $_tplIdx;
		    function Header() {
                global $nf;

		        if (is_null($this->_tplIdx)) {
                    //$this->setSourceFile($nf->base_dir .'templates/postscript/ce_footer.pdf');
                    $this->setSourceFile($nf->base_dir .'templates/postscript/ce_p1.pdf');
		            $this->_tplIdx = $this->importPage(1);
		        }
		        $this->useTemplate($this->_tplIdx);
		    }
		    function Footer() {}
		}
		
		// initiate PDF
		$pdf = new PDF();
		$pdf->SetMargins(PDF_MARGIN_LEFT, 40, PDF_MARGIN_RIGHT); 
		$pdf->SetAutoPageBreak(true, 60); 
		$pdf->setFontSubsetting(false);
		
		$pdf->AddPage();
		
		$scriptname = $_GET['mn'];
        $nf->modules->find('first', array('conditions' => array('name' => $scriptname)));
        $pdf->SetFont('freesans', 'R', 14);
        $pdf->SetTextColor(255, 0, 0);
        $pdf->WriteHtml('<h3>Lesson Guide for Week '.$thisfilename.'</h3>', true, false );
        //$pdf->Ln(4);
        $pdf->SetTextColor(0, 0, 0);
        $html = $nf->modules['w'.$thisfilename.'_notes'].'<p>&nbsp;</p>';
        $html .= $nf->modules['w'.$thisfilename.'_script'];
		//$html = strip_tags($nf->modules['w'.$thisfilename.'_script']);
		//$cards = explode('<p>&nbsp;</p>',$html);
		//$htmlnew = str_replace('&quot;','"', $html);
		$pdf->SetFont('freesans', 'R', 9);
		// writeHTMLCell($w, $h, $x, $y, $html='', $border=0, $ln=0, $fill=0, $reseth=true, $align='', $autopadding=true)
		$pdf->writeHTMLCell(160, 8, 31, 48, $html, 0, 1, 0, true, 'L', true);
		$pdf->Output('lesson_week_'. $thisfilename .'.pdf', 'D');
		//exit;
		break;
	}
	case 'cards': {
		//$thisfilename = isset($_GET['w']) ? $_GET['w'] : 'other';
		$thisfilename = $_GET['mn'];
		
		class PDF extends FPDI {
		    var $_tplIdx;
		    function Header() {
                global $nf;

		        if (is_null($this->_tplIdx)) {
                    $this->setSourceFile($nf->base_dir .'templates/postscript/lessoncard.pdf');
		            $this->_tplIdx = $this->importPage(1);
		        }
		        $this->useTemplate($this->_tplIdx);
		    }
		    function Footer() {}
		}
		
		// initiate PDF
		$pdf = new PDF();
		$pdf->SetMargins(PDF_MARGIN_LEFT, 20, PDF_MARGIN_RIGHT); 
		$pdf->SetAutoPageBreak(true, 1); 
		//$pdf->setFontSubsetting(false);
		
		$pdf->AddPage('L','A4');
		
		//$html = $nf->modules['quotes'];
		//$quotes = explode('</p>',$html);
		$int = $nf->modules['intro'];
		$def = $nf->modules['definition'];
		
		$pdf->SetXY(0, 0);
		// CARD 1 
		$pdf->SetFont('freesans', 'B,I', 12);
		$pdf->SetTextColor(23, 107, 141);
		$pdf->writeHTMLCell(120, 6, 8, 15, $thisfilename, 0, 0, 0, true, '', true);
		$pdf->SetTextColor(0, 0, 0);
		$pdf->SetFont('freesans', 'R', 8);
		$pdf->writeHTMLCell(120, 8, 8, 21, strip_tags($int), 0, 0, 0, true, '', true);
		$pdf->SetFont('freesans', 'R,I', 9);
		$pdf->SetTextColor(23, 107, 141);
		$pdf->writeHTMLCell(15, 5, 8, 29, 'Lesson:', 0, 0, 0, true, '', true);
		$pdf->SetTextColor(255, 0, 0);
		$pdf->writeHTMLCell(105, 5, 23, 29, $nf->modules['w1_title'], 0, 0, 0, true, '', true);
		$pdf->SetTextColor(0, 0, 0);
		$pdf->SetFont('freesans', 'R', 8);
		$pdf->writeHTMLCell(120, 8, 8, 34, strip_tags($def), 0, 0, 0, true, '', true);
		$pdf->SetFont('freesans', 'B', 9);
		$pdf->SetTextColor(23, 107, 141);
		$pdf->writeHTMLCell(120, 5, 8, 42, $nf->modules['w1_headline'], 0, 0, 0, true, '', true);
		$pdf->SetTextColor(0, 0, 0);
		$pdf->SetFont('freesans', 'R', 8);
		$pdf->writeHTMLCell(72, 46, 8, 47, $nf->modules['w1_cardtext'], 0, 0, 0, true, '', true);
		$pdf->writeHTMLCell(55, 46, 78, 47, $nf->modules['w1_cardbullets'], 0, 0, 0, true, '', true);
		
		// CARD 2
		$pdf->SetFont('freesans', 'B,I', 12);
		$pdf->SetTextColor(23, 107, 141);
		$pdf->writeHTMLCell(120, 6, 147, 15, $thisfilename, 0, 0, 0, true, '', true);
		$pdf->SetTextColor(0, 0, 0);
		$pdf->SetFont('freesans', 'R', 8);
		$pdf->writeHTMLCell(120, 8, 147, 21, strip_tags($int), 0, 0, 0, true, '', true);
		$pdf->SetFont('freesans', 'R,I', 9);
		$pdf->SetTextColor(23, 107, 141);
		$pdf->writeHTMLCell(15, 5, 147, 29, 'Lesson:', 0, 0, 0, true, '', true);
		$pdf->SetTextColor(255, 0, 0);
		$pdf->writeHTMLCell(105, 5, 162, 29, $nf->modules['w2_title'], 0, 0, 0, true, '', true);
		$pdf->SetTextColor(0, 0, 0);
		$pdf->SetFont('freesans', 'R', 8);
		$pdf->writeHTMLCell(120, 8, 147, 34, strip_tags($def), 0, 0, 0, true, '', true);
		$pdf->SetFont('freesans', 'B', 9);
		$pdf->SetTextColor(23, 107, 141);
		$pdf->writeHTMLCell(120, 5, 147, 42, $nf->modules['w2_headline'], 0, 0, 0, true, '', true);
		$pdf->SetTextColor(0, 0, 0);
		$pdf->SetFont('freesans', 'R', 8);
		$pdf->writeHTMLCell(72, 46, 147, 47, $nf->modules['w2_cardtext'], 0, 0, 0, true, '', true);
		$pdf->writeHTMLCell(55, 46, 217, 47, $nf->modules['w2_cardbullets'], 0, 0, 0, true, '', true);
		
		// CARD 3
		$pdf->SetFont('freesans', 'B,I', 12);
		$pdf->SetTextColor(23, 107, 141);
		$pdf->writeHTMLCell(120, 6, 8, 122, $thisfilename, 0, 0, 0, true, '', true);
		$pdf->SetTextColor(0, 0, 0);
		$pdf->SetFont('freesans', 'R', 8);
		$pdf->writeHTMLCell(120, 8, 8, 128, strip_tags($int), 0, 0, 0, true, '', true);
		$pdf->SetFont('freesans', 'R,I', 9);
		$pdf->SetTextColor(23, 107, 141);
		$pdf->writeHTMLCell(15, 5, 8, 136, 'Lesson:', 0, 0, 0, true, '', true);
		$pdf->SetTextColor(255, 0, 0);
		$pdf->writeHTMLCell(105, 5, 23, 136, $nf->modules['w3_title'], 0, 0, 0, true, '', true);
		$pdf->SetTextColor(0, 0, 0);
		$pdf->SetFont('freesans', 'R', 8);
		$pdf->writeHTMLCell(120, 8, 8, 141, strip_tags($def), 0, 0, 0, true, '', true);
		$pdf->SetFont('freesans', 'B', 9);
		$pdf->SetTextColor(23, 107, 141);
		$pdf->writeHTMLCell(120, 5, 8, 149, $nf->modules['w3_headline'], 0, 0, 0, true, '', true);
		$pdf->SetTextColor(0, 0, 0);
		$pdf->SetFont('freesans', 'R', 8);
		$pdf->writeHTMLCell(72, 46, 8, 154, $nf->modules['w3_cardtext'], 0, 0, 0, true, '', true);
		$pdf->writeHTMLCell(55, 46, 78, 154, $nf->modules['w3_cardbullets'], 0, 0, 0, true, '', true);

		// CARD 4
		$pdf->SetFont('freesans', 'B,I', 12);
		$pdf->SetTextColor(23, 107, 141);
		$pdf->writeHTMLCell(120, 6, 147, 122, $thisfilename, 0, 0, 0, true, '', true);
		$pdf->SetTextColor(0, 0, 0);
		$pdf->SetFont('freesans', 'R', 8);
		$pdf->writeHTMLCell(120, 8, 147, 128, strip_tags($int), 0, 0, 0, true, '', true);
		$pdf->SetFont('freesans', 'R,I', 9);
		$pdf->SetTextColor(23, 107, 141);
		$pdf->writeHTMLCell(15, 5, 147, 136, 'Lesson:', 0, 0, 0, true, '', true);
		$pdf->SetTextColor(255, 0, 0);
		$pdf->writeHTMLCell(105, 5, 162, 136, $nf->modules['w4_title'], 0, 0, 0, true, '', true);
		$pdf->SetTextColor(0, 0, 0);
		$pdf->SetFont('freesans', 'R', 8);
		$pdf->writeHTMLCell(120, 8, 147, 141, strip_tags($def), 0, 0, 0, true, '', true);
		$pdf->SetFont('freesans', 'B', 9);
		$pdf->SetTextColor(23, 107, 141);
		$pdf->writeHTMLCell(120, 8, 147, 149, $nf->modules['w4_headline'], 0, 0, 0, true, '', true);
		$pdf->SetTextColor(0, 0, 0);
		$pdf->SetFont('freesans', 'R', 8);
		$pdf->writeHTMLCell(72, 46, 147, 154, $nf->modules['w4_cardtext'], 0, 0, 0, true, '', true);
		$pdf->writeHTMLCell(55, 46, 217, 154, $nf->modules['w4_cardbullets'], 0, 0, 0, true, '', true);
		
		// CARD 3 BACKUP
		//$pdf->SetFont('freesans', 'B,I', 12);
		//$pdf->SetTextColor(23, 107, 141);
		//$pdf->writeHTMLCell(20, 10, 10, 125, 'Lesson:', 0, 0, 0, true, '', true);
		//$pdf->SetTextColor(0, 0, 0);
		//$pdf->writeHTMLCell(105, 10, 30, 125, $nf->modules['w3_title'], 0, 0, 0, true, '', true);
		//$pdf->SetFont('freesans', 'B', 10);
		//$pdf->SetTextColor(23, 107, 141);
		//$pdf->writeHTMLCell(120, 8, 10, 135, $nf->modules['w3_headline'], 0, 0, 0, true, '', true);
		//$pdf->SetTextColor(0, 0, 0);
		//$pdf->SetFont('freesans', 'R', 8);
		//$pdf->writeHTMLCell(65, 57, 10, 143, $nf->modules['w3_cardtext'], 0, 0, 0, true, '', true);
		//$pdf->writeHTMLCell(55, 57, 80, 143, $nf->modules['w3_cardbullets'], 0, 0, 0, true, '', true);
		
		// CARD 4 BACKUP
		//$pdf->SetFont('freesans', 'B,I', 12);
		//$pdf->SetTextColor(23, 107, 141);
		//$pdf->writeHTMLCell(20, 10, 147, 125, 'Lesson:', 0, 0, 0, true, '', true);
		//$pdf->SetTextColor(0, 0, 0);
		//$pdf->writeHTMLCell(105, 10, 167, 125, $nf->modules['w4_title'], 0, 0, 0, true, '', true);
		//$pdf->SetFont('freesans', 'B', 10);
		//$pdf->SetTextColor(23, 107, 141);
		//$pdf->writeHTMLCell(120, 8, 147, 135, $nf->modules['w4_headline'], 0, 0, 0, true, '', true);
		//$pdf->SetTextColor(0, 0, 0);
		//$pdf->SetFont('freesans', 'R', 8);
		//$pdf->writeHTMLCell(65, 57, 147, 143, $nf->modules['w4_cardtext'], 0, 0, 0, true, '', true);
		//$pdf->writeHTMLCell(55, 57, 217, 143, $nf->modules['w4_cardbullets'], 0, 0, 0, true, '', true);
		
		$pdf->Output('lessoncards_'. $thisfilename .'.pdf', 'D');
		//exit;
		break;
	}
	
}

/*$nf->attached->find('all', array(
	'order' => 'file_order ASC',
	'conditions' => array('type' => 'page'),
	'fields' => array('upload_id', 'description', 'u.orig_filename'),
	'join' => array('model' => 'uploads u', 'clause' => 'u.id = attached.upload_id')
));*/


$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = $view;
$nf['content_template'] = (($nf->franchisees->numRows() == 0) ? 'subpage' : 'franchisee_subpage');
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");

