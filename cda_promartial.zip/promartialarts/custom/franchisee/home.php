<?php
$nf->instantiate(
	'settings',
	'franchisees',
	'franchisee_home_pages fhp',
	'events'
);

$nf->settings->find('first');
$nf->fhp->id_field = 'franchisee_id';
$nf->fhp->find('id', $nf->franchisees->current());
$nf->franchisees->find('id', $nf->franchisees->current());
$nf->franchisees->expand_variables($nf->fhp);

$nf->events->franchiseeFind('all', array(
	'alias' => 'e',
	'fields' => 'e.*, IF(e.is_additional_day = "No", e.url, (SELECT e2.url FROM events e2 WHERE e2.id=e.first_day_id)) adjusted_url',
	'conditions' => array(
		'date >= NOW()'
	),
	'limit' => 15,
	'order' => 'date ASC'
));

$nf->pages['bonus_box_type'] = 'location';


$nf['title'] = $nf->settings['site_title'] . $nf->fhp['title'];
$nf['meta_desc'] = $nf->fhp['meta_desc'];
$nf['meta_keywords'] = $nf->fhp['meta_keywords'];

$nf['current_url'] = array('{BASE_URL}', '/');

$nf['show_footer'] = true;

$nf['content_template'] = 'franchisee_home';
$nf['body_class'] = 'franchisee';
// Main layout template
$nf->page_scripts = array('jquery', 'crossSlide', 'jqueryui', 'scrollto');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/main.php");

