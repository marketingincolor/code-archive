<?php
/* Label: "Standard" */

$nf->instantiate('pages', 'settings');


// Get generic CMS page data
include($nf->base_dir ."custom/pieces/subpage_setup.php");

$nf['current_url'] = $nf->pages['url'];


$nf['subcontent_template'] = 'generic_page';
//$nf['content_template'] = 'subpage_'. nf::coalesce($nf->pages['layout_type'], 'type1');
$nf['content_template'] = (($nf->franchisees->numRows() == 0) ? 'subpage' : 'franchisee_subpage');
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");

