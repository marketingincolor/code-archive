<?php
/* Label: "Testimonials" */

$nf->instantiate('pages', 'settings', 'testimonials', 'home_page');

$nf->home_page->find('first');
$nf['nb_title'] = $nf->home_page['smallbox3_title'];
$nf['nb_copy'] = $nf->home_page['smallbox3_content'];

// Get generic CMS page data
include($nf->base_dir ."custom/pieces/subpage_setup.php");

$nf['current_url'] = $nf->pages['url'];


$nf->testimonials->page = nf::coalesce(@$_GET['page'], 1);
$nf->testimonials->find('all', array(
	'order' => 'row_order ASC'
));


$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'testimonials';
$nf['content_template'] = (($nf->franchisees->numRows() == 0) ? 'subpage' : 'franchisee_subpage');
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");
