<?php
/* Label: "Franchisee Dashboard (downloads/links)" */
$nf->instantiate('download_categories cats', 'downloads', 'modules');


//$nf->links->find('all', array('order' => 'row_order ASC'));
//$nf->news->find('all', array('order' => 'date ASC','limit' => 3));

// Get generic CMS page data
include($nf->base_dir ."custom/pieces/subpage_setup.php");


$nf->cats->find('all', array(
	'order' => 'LOWER(name) ASC',
));

foreach ($nf->cats as $cat) {
	$cat->downloads = $nf->downloads->find('all', array(
		'order' => 'row_order ASC, LOWER(name) ASC',
		'conditions' => array(
			'category_id' => $cat['id']
		),
		'array_only' => true,
	));
}

$nf->modules->find('all', array(
	'order' => 'row_order ASC',
));


$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'downloads';
$nf['content_template'] = (($nf->franchisees->numRows() == 0) ? 'subpage' : 'franchisee_subpage');
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");


