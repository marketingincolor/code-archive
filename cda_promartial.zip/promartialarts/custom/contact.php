<?php
/* Label: "Contact Us" */

$nf->instantiate('contacts', 'mailing_list list', 'home_page');

$nf->home_page->find('first');
$nf['nb_title'] = $nf->home_page['smallbox3_title'];
$nf['nb_copy'] = $nf->home_page['smallbox3_content'];

// Get generic CMS page data
include($nf->base_dir ."custom/pieces/subpage_setup.php");

switch (@$_REQUEST['action']) {
	case 'save': {
		if (!$nf->contacts->validates()) {
			nf::flash("Please fill in all fields colored in red, then press the Submit button again", "error");
			break;
		}

		nf::flash("Your info has been saved. Thank you for contacting us.");

		/*
		$nf->list->add(
			$nf->contacts['name'],
			$nf->contacts['email'],
			'contacts',
			$nf->contacts['phone']
		);
		*/
		if (!$nf->contacts['source']) {
			$nf->contacts['source'] = 'Contact Us';
		}

		$nf->contacts->save();

		ob_start();
		include($nf->base_dir .'templates/email/contact.php');
		$body = ob_get_clean();

		include_once($nf->base_dir .'nf/3rdparty/class.phpmailer.php');
		$mail = new PHPMailer(); // defaults to using php "mail()"
		$mail->LE = "\n";

		$mail->From = $nf->settings['from_email'];
		$mail->FromName = $nf->settings['site_name'];
		$mail->Subject = '['. $nf->settings['site_name'] .'] New '. $nf->contacts['source'] .' form submission';
		$mail->Body = $body;
		$mail->IsHTML(false);

		if ($nf->franchisees->current('email', 'viewing')) {
			$mail->AddAddress($nf->franchisees->current('email', 'viewing'));
		} else {
			$mail->AddAddress($nf->settings['contact_email']);
		}

		if (strlen(trim($nf->settings['contact_email_bcc'])) > 0) {
			$mail->AddBcc($nf->settings['contact_email_bcc']);
		}
		$rv = $mail->Send();


		$nf->contacts->clearData();
		break;
	}

	default:
}

if (@$_GET['arg1'] == 'trial') {
	$nf->contacts['source'] = 'Free Trial';
}
if (!$nf->contacts['source']) {
	$nf->contacts['source'] = 'Contact Us';
}

$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'contact';
$nf['content_template'] = (($nf->franchisees->numRows() == 0) ? 'subpage' : 'franchisee_subpage');
$nf->page_css = array('lightness');
$nf->page_scripts = array('jqueryui');
// Main layout template

include($nf->base_dir ."templates/main.php");

