<?php

$nf->instantiate('testimonials _box_testimonials');

$nf->_box_testimonials->find('first', array(
	'order' => 'RAND()'
));

