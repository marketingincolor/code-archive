<?php
/* Label: "Locations" */

$nf->instantiate(
	'franchisees fsearch',
	'franchisees lsearch',
	'home_page',
	'generic'
);

$nf->home_page->find('first');
$nf['nb_title'] = $nf->home_page['smallbox3_title'];
$nf['nb_copy'] = $nf->home_page['smallbox3_content'];

switch (@$_REQUEST['action']) {
	case 'search': {
		if ($nf->generic['zipcode'] && $nf->generic['radius']) {
			$nf->fsearch->search_success = $nf->fsearch->findByZipcode($nf->generic['zipcode'], $nf->generic['radius']);
		}
		break;
	}
	case 'show': {
		$nf->lsearch->search_success = $nf->lsearch->findAllLocations();
		break;	
	}
		
	default:
}


// Get generic CMS page data
include($nf->base_dir ."custom/pieces/subpage_setup.php");

$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'locations';
$nf['content_template'] = (($nf->franchisees->numRows() == 0) ? 'subpage' : 'franchisee_subpage');
// Main layout template
include($nf->base_dir ."templates/main.php");

