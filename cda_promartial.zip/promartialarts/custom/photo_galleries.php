<?php
/* Label: "Photo Galleries" */

$nf->instantiate('galleries', 'attached_files images');

include($nf->base_dir ."custom/pieces/subpage_setup.php");

if (@$_GET['arg1']) {
	$view = 'gallery';
} else {
	$view = 'galleries';
}


$template = $view;
switch ($view) {
	case 'gallery': {
		$nf->galleries->id_field = 'url';
		$nf->galleries->franchiseeFind('id', @$_GET['arg1'], array(
			'actiontype' => 'viewing'
		));

		$nf->images->find('all', array(
			'order' => 'file_order ASC',
			'conditions' => array('type' => 'gallery', 'foreign_id' => $nf->galleries['id']),
			'fields' => array('upload_id', 'description', 'u.orig_filename'),
			'join' => array('model' => 'uploads u', 'clause' => 'u.id = images.upload_id')
		));
		$nf->pages['header'] = $nf->galleries['name'];
		break;
	}

	case 'galleries':
	default: {
		$nf->galleries->franchiseeFind('all', array(
			'fields' => 'g.*, (SELECT COUNT(*) FROM attached_files a WHERE a.type="gallery" AND a.foreign_id=g.id) image_count',
			'alias' => 'g',
			'order' => 'LOWER(g.name) ASC',
			'array_only' => true,
			'actiontype' => 'viewing'
		));
	}
}



$nf['current_url'] = $nf->pages['url'];

$nf['subsubcontent_template'] = $template;
$nf['subcontent_template'] = 'photo_galleries';
$nf['content_template'] = (($nf->franchisees->numRows() == 0) ? 'subpage' : 'franchisee_subpage');
// Main layout template
$nf->page_css = array('prettyphoto');
$nf->page_scripts = array('prettyphoto');
include($nf->base_dir ."templates/main.php");

