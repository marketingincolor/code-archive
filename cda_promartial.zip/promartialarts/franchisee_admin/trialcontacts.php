<?php
include('../nf/init.php');
$nf = new nfFw(
	'free_trial_contacts contacts',
	'franchisees'
);

include(dirname(__FILE__) .'/pieces/secure.php');

$data_desc = "Free Trial Contact";
$data_desc_plural = "Free Trial Contacts";

switch (@$_REQUEST['action']) {
	case 'delete': {
		$model = $nf->contacts;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'view': {
		$nf->contacts->find('id', @$_GET['id']);
		break;
	}

	default:
}

$nf->contacts->rows_all = $nf->contacts->find('all', array(
	'order' => 'date_added DESC, LOWER(last_name) ASC',
	'array_only' => true,
	'update_model_data' => false,
	'conditions' => array('franchisee_id' => $nf->franchisees->current())
));

$nf['subcontent_template'] = 'trialcontacts';
$nf['content_template'] = 'franchisee_admin/admin_page';
$nf->page_scripts = array('currency', 'jqueryui', 'timepicker', 'admin_time_inputs');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/franchisee_admin/main.php");

