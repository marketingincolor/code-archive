<?php
include_once(dirname(__FILE__) .'/../nf/init.php');
$nf = new nfFw();

$nf->auth->secure('franchisee');
$nf->auth->checkAuthorized();

$nf['subcontent_template'] = 'index';
$nf['content_template'] = 'franchisee_admin/admin_page';
include($nf->base_dir ."templates/franchisee_admin/main.php");

