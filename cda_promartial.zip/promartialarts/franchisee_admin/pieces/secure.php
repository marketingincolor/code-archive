<?php

$nf->auth->secure('franchisee');
$nf->auth->checkAuthorized();

if ($nf->auth->hasPerm('admin')) {
	nf::redirect('/admin');
}

$franchisee_id = $nf->auth['foreign_id'];
$_SESSION['editing_franchisee'] = array_pop($nf->db->quickQuery("SELECT * FROM franchisees WHERE id=?", $franchisee_id));

