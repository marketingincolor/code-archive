<?php

if (!@$_GET['id']) { nf::flash("Error: No $data_desc was specified"); return; }
// Get the outlet so we have it's name to display
$model->find('first', array(
	'conditions' => array(
		'id' => @$_GET['id'], 
		'franchisee_id' => $nf->franchisees->current('id')
	)
));
if (!$model->data) { nf::flash("Error: The specified $data_desc couldn't be found"); return; }

// Delete
$model->delete(array(
	'id' => @$_GET['id'],
	'franchisee_id' => $nf->franchisees->current('id')
));

nf::flash("$data_desc \"". nf::coalesce($model['name'], $model['title'], $model['description']) ."\" is deleted");
$model->clearData();

