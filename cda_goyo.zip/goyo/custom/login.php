<?php
/* Label: "Login" */
$nf->instantiate('users', 'generic', 'settings');

$nf->settings->find('first');

// Get generic CMS page data
include($nf->base_dir ."custom/pieces/subpage_setup.php");

switch (@$_REQUEST['action']) {
	case 'logout': {
		$nf->auth->setLogout();
		$_SESSION['editing_franchisee'] = null;
		nf::flash('Logged out.');
		break;
	}

	case 'submit_login': {
		$nf->auth->authorizeLogin($nf->generic['username'], $nf->generic['password']);

		if ($nf->auth->loggedIn()) {
			// If we got here, then there was no redirect in $_SESSION
			$landing_page = nf::coalesce($nf->auth['landing_page'], '/admin');

			nf::redirect($nf->url($landing_page));
		} else {
			nf::flash("Please enter the correct username and password");
		}


		break;
	}

	default:
}


$nf['title'] = 'Log In';
$nf['subcontent_template'] = 'login';
$nf['content_template'] = 'subpage';
// Main layout template
include($nf->base_dir ."templates/main.php");

