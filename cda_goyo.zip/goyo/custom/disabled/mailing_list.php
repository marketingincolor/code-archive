<?php
include_once('nf/init.php');
$nf = new nfFw('mailing_list', 'mailing_list list');

// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");


switch (@$_REQUEST['action']) {
	case 'save': {
		//$nf->contacts->save();

		$rv = $nf->list->add($nf->mailing_list['name'], $nf->mailing_list['email'], 'List Joiner', $nf->mailing_list['phone'], $nf->mailing_list['opted_out']);
		if ($rv) {
			nf::flash("You have been successfully added to the mailing list.");
		} else {
			nf::flash("An error occurred when adding you to the email list - Is your email address typed correctly?");
		}
		break;
	}

	default:
}



$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'mailing_list';
$nf['content_template'] = 'subpage';
$nf->page_css = array('lightness');
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");

