<?php
include_once('nf/init.php');
$nf = new nfFw('case_studies', 'case_studies cs_all', 'settings', 'testimonials', 'announcements', 'pages', 'page_tabs');


$nf->testimonials->find('first', array( 'order' => 'RAND()'));
$nf->announcements->find('first', array( 'order' => 'RAND()'));
$nf->settings->find('first');
$nf->case_studies->find('id', @$_GET['id']);

$nf->cs_all->find('all', array(
	'order' => 'row_order ASC'
));
foreach ($nf->cs_all as $index => $cs) {
	if ($cs['id'] == $nf->case_studies['id']) {
		$next_index = $index+1;
		break;
	}
}
if (!$nf->cs_all[$next_index]) {
	$next_index = 0;
}
$nf->case_studies['next_url'] = $nf->url($nf->cs_all[$next_index]['url']);

$nf['current_url'] = $nf->case_studies['url'];

$nf->pages->clearData();
$nf->pages->push(array(
	'header' => 'Case Studies',
));

$nf['meta_desc'] = $nf->case_studies['meta_desc'];
$nf['meta_keywords'] = $nf->case_studies['meta_keywords'];
$nf['title'] = $nf->case_studies['title'];

$nf['subcontent_template'] = 'case_study';
$nf['content_template'] = 'subpage';
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");

