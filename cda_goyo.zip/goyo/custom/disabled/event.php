<?php
/* Label: "Event" */

$nf->instantiate('events', 'attached_files pr');


$nf->events->find('id', @$_GET['arg1']);
$nf['title'] = $nf->events['title'];

// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

$attachments = array();
$attachments['downloads'] = $nf->pr->find('all', array(
	'conditions' => array(
		'type' => 'events',
		'foreign_id' => $nf->events['id']
	)
));
$nf['attachments'] = $attachments;

$nf->pages['header'] = $nf->events['title'];

$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'event';
$nf['content_template'] = 'subpage';
// Main layout template
include($nf->base_dir ."templates/main.php");

