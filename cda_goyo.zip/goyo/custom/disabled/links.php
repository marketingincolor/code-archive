<?php
/* Label: "Links and Resources" */

$nf->instantiate('pages', 'settings', 'links');


// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

$nf['current_url'] = $nf->pages['url'];

$nf->links->find('all', array(
	'order' => 'row_order ASC, LOWER(name) ASC'
));


$nf['subcontent_template'] = 'links';
$nf['content_template'] = 'subpage';
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");

