<?php
$nf->instantiate(
	'settings',
	'franchisees',
	'franchisee_home_pages fhp',
	'feedback',
	'events'
);

$nf->settings->find('first');
$nf->fhp->id_field = 'franchisee_id';
$nf->fhp->find('id', $nf->franchisees->current());
$nf->franchisees->find('id', $nf->franchisees->current());
$nf->franchisees->expand_variables($nf->fhp);

switch (@$_POST['action']) {
	case 'post_submit': {
		$nf->feedback->push(array(
			'status' => 'Pending',
			'name' => @$_POST['name'],
			'message' => @$_POST['message'],
		));
		$nf->feedback->save();

		die(json_encode(array(
			'success' => true
		)));
		break;
	}

	default;
}


$nf->events->franchiseeFind('all', array(
	'alias' => 'e',
	'fields' => 'e.*, IF(e.is_additional_day = "No", e.url, (SELECT e2.url FROM events e2 WHERE e2.id=e.first_day_id)) adjusted_url',
	'conditions' => array(
		'date >= NOW()'
	),
	'limit' => 15,
	'order' => 'date ASC'
));

$nf->pages['bonus_box_type'] = 'location';
$nf->pages->bonus_box_types['location']['title'] = $nf->franchisees['name'] .'<br />'. nl2br($nf->franchisees['address']);

$nf['title'] = $nf->settings['site_title'] . $nf->fhp['title'];
$nf['meta_desc'] = $nf->fhp['meta_desc'];
$nf['meta_keywords'] = $nf->fhp['meta_keywords'];

$nf['current_url'] = array('{BASE_URL}', '/');

$nf['show_footer'] = true;
$nf['show_franchisee_subnav'] = true;

$showfb = $nf->fhp['smallbox4_page'];

$nf['content_template'] = 'franchisee_home';
$nf['body_class'] = 'franchisee franchisee_home';
// Main layout template
$nf->page_scripts = array('jquery', 'crossSlide', 'jqueryui', 'scrollto');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/main.php");

