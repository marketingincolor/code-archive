<?php
/* Label: "Yogurt Flavors" */

$nf->instantiate(
	'yogurts',
	'franchisee_yogurts fy'
);

// Get generic CMS page data
include($nf->base_dir ."custom/pieces/subpage_setup.php");



$nf->yogurts->find('all', array(
	'order' => 'row_order ASC, LOWER(name) ASC',
));

if ($nf->franchisees->current('id', 'viewing')) {
	$nf->fy->franchiseeFind('all', array(
		'actiontype' => 'viewing'
	));

	$franchisee_yogurt_ids = $nf->fy->column('yogurt_id');

	foreach ($nf->yogurts as $yogurt) {
		if (!in_array($yogurt['id'], $franchisee_yogurt_ids)) {
			$yogurt->deleteRow();
		}
	}
}



$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'yogurts';
$nf['content_template'] = (($nf->franchisees->numRows() == 0) ? 'subpage' : 'franchisee_subpage');
// Main layout template
include($nf->base_dir ."templates/main.php");

