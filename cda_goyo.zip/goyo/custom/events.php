<?php
/* Label: "Events" */

$nf->instantiate('events');

if (@$_GET['arg1']) {
	$view = 'event';
} else {
	$view = 'events';
}


$template = $view;
switch ($view) {
	case 'event':
		$nf->events->id_field = 'url';
		$nf->events->franchiseeFind('id', @$_GET['arg1'], array(
			'actiontype' => 'viewing'
		));
		
		break;

	case 'events':
	default:
		$nf->events->page = nf::coalesce(@$_GET['page'], 1);
		$nf->events->franchiseeFind('all', array(
			'conditions' => array(
				"IF(type='single_day', (date >= DATE(NOW())) , (end_date >= DATE(NOW())) ) ",
			),
			'order' => "IF(type='single_day',date,start_date) DESC, LOWER(name) ASC",
			'actiontype' => 'viewing'
		));

}


// Get generic CMS page data
include($nf->base_dir ."custom/pieces/subpage_setup.php");

$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = $template;
$nf['content_template'] = (($nf->franchisees->numRows() == 0) ? 'subpage' : 'franchisee_subpage');
// Main layout template
include($nf->base_dir ."templates/main.php");

