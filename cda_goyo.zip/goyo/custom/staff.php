<?php
/* Label: "Staff" */

$nf->instantiate('staff', 'attached_files attached');


$nf->staff->rows_per_page = 4;
$nf->staff->page = nf::coalesce(@$_GET['page'], 1);
$nf->staff->franchiseeFind('all', array(
	'order' => 'row_order ASC, LOWER(name) ASC'
));

$nf->attached->find('all', array(
	'conditions' => array('type' => 'home_page'),
	'order' => 'file_order ASC',
));
// Get generic CMS page data
include($nf->base_dir ."custom/pieces/subpage_setup.php");

$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'staff';
$nf['content_template'] = (($nf->franchisees->numRows() == 0) ? 'subpage' : 'franchisee_subpage');
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");

