<?php
/* Label: "Locations" */

$nf->instantiate(
	'franchisees fsearch',
	'generic',
	'settings'
);

switch (@$_REQUEST['action']) {
	case 'search': {
		if ($nf->generic['zipcode'] && $nf->generic['radius']) {
			$nf->fsearch->search_success = $nf->fsearch->findByZipcode($nf->generic['zipcode'], $nf->generic['radius']);
		}
		break;
	}

	default:
}

$nf->settings->find('first');


// Get generic CMS page data
include($nf->base_dir ."custom/pieces/subpage_setup.php");

$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'locations';
$nf['content_template'] = (($nf->franchisees->numRows() == 0) ? 'subpage' : 'franchisee_subpage');
// Main layout template
include($nf->base_dir ."templates/main.php");

