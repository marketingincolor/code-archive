<?php
/* Label: "Toppings" */

$nf->instantiate(
	'toppings',
	'topping_categories cats',
	'franchisee_toppings ft'
);

// Get generic CMS page data
include($nf->base_dir ."custom/pieces/subpage_setup.php");


$nf->cats->by_id = $nf->cats->find('all', array(
	'order' => 'row_order ASC, LOWER(name) ASC',
	'by_id' => true,
	'array_only' => true
));

$nf->toppings->find('all', array(
	'order' => 'row_order ASC, LOWER(name) ASC',
));

if ($nf->franchisees->current('id', 'viewing')) {
	$nf->ft->franchiseeFind('all', array(
		'actiontype' => 'viewing'
	));

	$franchisee_topping_ids = $nf->ft->column('topping_id');

	foreach ($nf->toppings as $topping) {
		if (!in_array($topping['id'], $franchisee_topping_ids)) {
			$topping->deleteRow();
		}
	}
}

$nf->toppings->by_category = array();
foreach ($nf->cats->by_id as $cat) {
	$nf->toppings->by_category[$cat['id']] = $nf->toppings->rowsByColumnValues('category_id', $cat['id']);
}


$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'toppings';
$nf['content_template'] = (($nf->franchisees->numRows() == 0) ? 'subpage' : 'franchisee_subpage');
// Main layout template
include($nf->base_dir ."templates/main.php");

