<?php
/* Label: "Case Studies (listing)" */
$nf->instantiate('case_studies');


$nf->case_studies->find('all', array(
	'order' => 'row_order ASC, LOWER(header) ASC'
));


// Get generic CMS page data
include($nf->base_dir ."custom/pieces/subpage_setup.php");

$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'case_studies';
$nf['content_template'] = (($nf->franchisees->numRows() == 0) ? 'subpage' : 'franchisee_subpage');
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");

