<?php
/* Label: "Site Map" */

$nf->instantiate('pages', 'pages sitemap', 'subdomains', 'settings');


// Get generic CMS page data
include($nf->base_dir ."custom/pieces/subpage_setup.php");

$nf['current_url'] = $nf->pages['url'];


$nf->sitemap->find('all', array(
	'order' => 'LOWER(title) ASC',
	'conditions' => array(
		'sitemap_exclude !=' => '1',
		'franchisee_id' => '0'
	)
));


$nf['subcontent_template'] = 'sitemap';
$nf['content_template'] = (($nf->franchisees->numRows() == 0) ? 'subpage' : 'franchisee_subpage');
// Main layout template
include($nf->base_dir ."templates/main.php");

