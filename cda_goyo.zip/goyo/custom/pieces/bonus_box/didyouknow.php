<?php

$nf->instantiate('didyouknow _box_didyouknow');

$nf->_box_didyouknow->find('first', array(
	'order' => 'RAND()'
));

