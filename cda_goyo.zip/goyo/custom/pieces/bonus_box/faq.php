<?php

$nf->instantiate('faqs _box_faqs');

$nf->_box_faqs->find('first', array(
	'order' => 'RAND()'
));

