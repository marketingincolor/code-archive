<?php
$nf->instantiate('settings');
$nf->settings->find('first');

