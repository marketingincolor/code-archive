<?php

$nf->instantiate('videos _box_videos');

$nf->_box_videos->find('id', $nf->box_opts['data']);


