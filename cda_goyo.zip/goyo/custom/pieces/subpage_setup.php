<?php

$nf->instantiate(
	'pages',
	'page_tabs',
	'settings',
	'attached_files page_downloads',
	'franchisees'
);

// Get generic CMS page data + site settings
$nf->settings->find('first');
if ($nf->pages->numRows() == 0) {
	$nf->pages->find('id', @$_GET['id']);
}

if (($nf->pages->numRows() > 0) && isset($nf->franchisees)) {
	$nf->franchisees->expand_variables($nf->pages);
}

if ($nf->pages['perms']) {
	$nf->auth->options['message_noauth'] = $nf->pages['perm_errmsg'];
	$nf->auth->secure($nf->pages['perms']);
	$nf->auth->checkAuthorized();
}

$nf['title'] = nf::coalesce(@$nf['title'], $nf->settings['site_title'] . $nf->pages['title']);
$nf['meta_desc'] = nf::coalesce(@$nf['meta_desc'], $nf->pages['meta_desc']);
$nf['meta_keywords'] = nf::coalesce(@$nf['meta_keywords'], $nf->pages['meta_keywords']);

if ($nf->pages['header_image']) {
	$nf->pages['header_image_file'] = $nf->uploadFileName($nf->pages['header_image']);
} else {
	$nf->pages['header_image_file'] = $nf->base_url .'images/bannerSub.jpg';
}


// Tabs
if ($nf->pages['layout_type'] == 'tabs') {
	$nf->instantiate('page_tabs');

	$nf->page_tabs->find('all', array(
		'conditions' => array(
			'page_id' => $nf->pages['id']
		),
		'order' => 'row_order ASC'
	));
}

// Get data for sidebar
if (!@$attachments) { $attachments = array(); }
$attachments['downloads'] = $nf->page_downloads->find('all', array(
	'order' => 'file_order ASC',
	'conditions' => array('type' => 'page', 'foreign_id' => @$nf->pages['id']),
	'fields' => array('upload_id', 'description', 'u.orig_filename'),
	'join' => array('model' => 'uploads u', 'clause' => 'u.id = page_downloads.upload_id'),
	'array_only' => true
));

/*
$attachments['galleries'] = $nf->page_galleries->find('all', array(
	'order' => 'row_order ASC',
	'conditions' => array('page_id' => @$nf->pages['id']),
	'fields' => array('gallery_id', 'galleries.title'),
	'join' => array(
		'model' => 'galleries',
		'clause' => 'page_galleries.gallery_id = galleries.id'
	),
	'array_only' => true
));

$attachments['videos'] = $nf->page_videos->find('all', array(
	'order' => 'row_order ASC',
	'conditions' => array('page_id' => @$nf->pages['id']),
	'fields' => array('video_id', 'videos.description'),
	'join' => array(
		'model' => 'videos',
		'clause' => 'page_videos.video_id = videos.id'
	),
	'array_only' => true
));
*/

if ($nf->pages['bonus_box_type'] && in_array($nf->pages['bonus_box_type'], array_keys($nf->pages->bonus_box_types))) {
	$nf->instantiate('bonus_box_options box_opts');
	$nf->box_opts->find('first', array(
		'conditions' => array(
			'page_id' => $nf->pages['id'],
			'type' => $nf->pages['bonus_box_type']
		)
	));
	include($nf->base_dir ."custom/pieces/bonus_box/". $nf->pages['bonus_box_type'] .".php");
}


$nf['num_attachments'] = count(nf::arrayFlatten($attachments));
$nf['attachments'] = $attachments;


