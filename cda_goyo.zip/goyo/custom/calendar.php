<?php
/* Label: "Calendar" */

$nf->instantiate('calendar');

if (@$_GET['date']) {
	$month = substr($_GET['date'], 4, 2);
	$year = substr($_GET['date'], 0, 4);

	// test date input
	$num_days_in_month = date('t',mktime(0,0,0,$month,1,$year));
	if (!$num_days_in_month || !@$nf->calendar->months[$month - 1]) {
		nf::redirect('?');
	}
} else {
	$month = date('n');
	$year = date('Y');
}

switch (@$_REQUEST['action']) {
	case 'download': {
		$nf->calendar->asPDF($year, $month);
		exit;
	}

	default:
}


// Get generic CMS page data
include($nf->base_dir ."custom/pieces/subpage_setup.php");

$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'calendar';
$nf['content_template'] = (($nf->franchisees->numRows() == 0) ? 'subpage' : 'franchisee_subpage');
$nf->page_css = array('calendar');
$nf->page_scripts = array('qtip');
// Main layout template
include($nf->base_dir ."templates/main.php");

