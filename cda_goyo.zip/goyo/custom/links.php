<?php
/* Label: "Links" */
$nf->instantiate('links');


$nf->links->rows_per_page = 6;
$nf->links->page = nf::coalesce(@$_GET['page'], 1);

$nf->links->franchiseeFind('all', array(
	'order' => 'row_order ASC',
	'actiontype' => 'viewing'
));
//$nf->news->find('all', array('order' => 'date ASC','limit' => 3));

// Get generic CMS page data
include($nf->base_dir ."custom/pieces/subpage_setup.php");

$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'links';
$nf['content_template'] = (($nf->franchisees->numRows() == 0) ? 'subpage' : 'franchisee_subpage');
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");


