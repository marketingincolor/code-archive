<?php
/* Label: "Customer Registration" */
$nf->instantiate('customers', 'mailing_list list', 'users');

// Get generic CMS page data
include($nf->base_dir ."custom/pieces/subpage_setup.php");


switch ($_REQUEST['action']) {
	case 'save': {
		$break = false;

		$validates = $nf->customers->validates();
		$nf->customers['captcha_key'] = '';

		if (!$validates) {
			nf::flash("Please fill in all fields colored in red, re-enter CAPTCHA text, then press the Submit button again", "error");
			break;
		}

		$count = $nf->users->findByEmail($nf->customers['email']);
		if ($count > 0) {
			nf::flash("An account already exists with that username. If that is your account you may, <a href='". $nf->base_url ."reset-password'>click here</a> to reset your password", "error");
			break;
		}

		$nf->users['username'] = $nf->customers['email'];
		$nf->users['email'] = $nf->customers['email'];
		$generated_pw = nf::generateHash(6);
		$nf->users['password'] = md5($generated_pw);
		$nf->users['permissions'] = 'customer';
		$nf->users['type'] = 'customer';
		$nf->users['landing_page'] = 'customer-resources';

		ob_start();
		include($nf->base_dir .'templates/email/new_customer.php');
		$body = ob_get_clean();

		$rv = mail($nf->customers['email'], '['. $nf->settings['site_name'] .'] New Customer Confirmation ', $body, 'From: '. $nf->settings['site_name'] .' <'. $nf->settings['contact_email'] .'>');

		if (!$rv) {
			nf::flash("An email error occurred - Your customer account could not be created", "error");
			break;
		}
		
		nf::flash("Thank you for submitting your info. A confirmation email has been sent, and should arrive within a few minutes.");

		$nf->customers->save();
		$nf->users['foreign_id'] = $nf->customers['id'];
		$nf->users->save();

		nf::redirect($nf->this_page_url);
		break;
	}

	default:
}



$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'customer_reg';
$nf['content_template'] = (($nf->franchisees->numRows() == 0) ? 'subpage' : 'franchisee_subpage');
$nf->page_scripts = array('jqueryui');
$nf->page_css = array('lightness');

// Main layout template

include($nf->base_dir ."templates/main.php");
