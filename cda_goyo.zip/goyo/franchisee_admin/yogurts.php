<?php
include('../nf/init.php');
$nf = new nfFw(
	'yogurts',
	'franchisee_yogurts fy',
	'franchisees'
);

include(dirname(__FILE__) .'/pieces/secure.php');


switch (@$_REQUEST['action']) {
	case 'save': {
		$nf->fy->delete(array(
			'franchisee_id' => $nf->franchisees->current('id')
		));

		$rv = $nf->fy->franchiseeAdminSave();
		if (!$rv) {
			nf::flash("Changes could not be saved");
			break;
		}

		nf::flash("Changes have been saved.");
		break;
	}

	default:
}


$nf->yogurts->find('all', array(
	'order' => 'row_order ASC, LOWER(name) ASC',
));

$nf->fy->franchiseeFind('all');


$nf['subcontent_template'] = 'yogurts';
$nf['content_template'] = 'franchisee_admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs', 'timepicker', 'admin_time_inputs');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/franchisee_admin/main.php");

