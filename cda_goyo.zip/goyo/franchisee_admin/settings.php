<?php
include('../nf/init.php');
$nf = new nfFw('franchisees', 'pages', 'attached_files attached', 'prefill', 'users', 'uscities');

include(dirname(__FILE__) .'/pieces/secure.php');


switch (@$_REQUEST['action']) {
	case 'ajax_url_test': {
		$count = (int)$nf->pages->find('count', array(
			'conditions' => array(
				'url' => @$_POST['url'],
				'franchisee_id IS NULL'
			)
		));

		$count += (int)$nf->franchisees->find('count', array(
			'conditions' => array(
				'url' => @$_POST['url'],
				'id !=' => @$_POST['id'],
			)
		));

		echo json_encode($count);
		exit;
	}

	case 'save': {
		// Validation
		if (!$nf->franchisees->validates()) {
			nf::flash("Please fill in all fields colored in red, then press the Submit button again", "error");
			break;
		}


		// Franchisee
		$nf->franchisees['id'] = $nf->franchisees->current('id', 'editing');
		$nf->franchisees['address'] = trim($nf->franchisees['address'], "\n\r");
		$nf->franchisees->save();


		// User
		if (!$nf->users['password']) {
			unset($nf->users['password']);
		} else {
			$nf->users['password'] = md5($nf->users['password']);
		}

		// Get user ID
		$id_row = $nf->users->find('first', array(
			'fields' => 'id',
			'conditions' => array(
				'type' => 'franchisee',
				'foreign_id' => $nf->franchisees['id'],
			),
			'update_model_data' => false
		));
		$nf->users['id'] = $id_row['id'];

		$nf->users['foreign_id'] = $nf->franchisees['id'];
		$nf->users['franchisee_id'] = $nf->franchisees['id'];
		$nf->users['email'] = $nf->franchisees['email'];
		$nf->users['type'] = 'franchisee';
		$nf->users['permissions'] = 'user,franchisee';
		$nf->users['landing_page'] = @$nf->users->user_landing_pages[$nf->users['type']];
		$nf->users->save();

		nf::flash("Changes have been saved.");
		break;
	}

	default:
		$nf->franchisees->find('id', $nf->franchisees->current('id'));
		$nf->users->find('first', array(
			'fields' => 'username,id,foreign_id',
			'conditions' => array(
				'type' => 'franchisee',
				'foreign_id' => $nf->franchisees['id'],
			),
		));
}


$nf['subcontent_template'] = 'settings';
$nf['content_template'] = 'franchisee_admin/admin_page';
$nf->page_scripts = array('fck', 'nffuncs', 'googlemaps', 'pmamap', 'pmamap_geocoder');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/franchisee_admin/main.php");

