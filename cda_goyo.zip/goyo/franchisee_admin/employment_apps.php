<?php
include('../nf/init.php');
$nf = new nfFw('employment_apps apps');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Employment App";
$data_desc_plural = "Employment Apps";

switch (@$_REQUEST['action']) {
	case 'delete': {
		$model = $nf->apps;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'view': {
		$nf->apps->find('id', @$_GET['id']);
		break;
	}


	default:
}


$nf->apps->rows_all = $nf->apps->franchiseeFind('all', array(
	'order' => 'date_added DESC, LOWER(last_name) ASC',
	'array_only' => true,
	'update_model_data' => false,
));



$nf['subcontent_template'] = 'employment_apps';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

