$(document).ready(function() {
	$("input.time").change(function() {
		this.value = this.value.replace(/ /g, '').replace(/^0/, '');
	}).timepicker({
		timeFormat: 'hh:mmtt',
		stepMinute: 5,
		ampm: true
	});

	$("input.submit").click(function() {
		var valid = true;
		$("input.time").each(function() {
			var val = $(this).val();
			if (val && !val.match(/^\d+:\d+(am|pm)$/)) {
				$(this).addClass('validation_error');
				valid = false;
			} else {
				$(this).removeClass('validation_error');
			}
		});

		if (!valid) {
			$("#time_validation").slideDown();
			return(false);
		}
	});
});
