<?php
	include_once('../nf/init.php');
	$nf = new nfFw('attached_files photos');

	$nf->photos->find('all', array(
		'order' => 'file_order ASC',
		'conditions' => array('type' => "gallery_photo", 'foreign_id' => @$_GET['id']),
		'fields' => array('upload_id', 'description', 'u.orig_filename'),
		'join' => array('model' => 'uploads u', 'clause' => 'u.id = photos.upload_id')
	));
	
	echo '<?xml version="1.0" encoding="UTF-8"?>'
?>
<simpleviewergallery
	maxImageWidth="480"
	maxImageHeight="480"
	textColor="0x000000"
	frameColor="0xF0F0F0"
	frameWidth="0"
	stagePadding="0"
	navPadding="40"
	thumbnailColumns="8"
	thumbnailRows="1"
	navPosition="bottom"
	vAlign="center"
	hAlign="center"
	title=""
	enableRightClickOpen="true"
	backgroundImagePath="<?php echo $nf->base_url ?>images/pixel_gray.gif"

	previewScript="<?php echo $nf->base_url ?>nf/tools/preview.php"
	scaleType="fit"
>

<?php foreach ($nf->photos as $photo) { ?>
	<image>
		<filename><?php echo $photo['upload_id'] ?></filename>
		<caption><?php echo $photo['description'] ?></caption>
	</image>
<?php } ?>

</simpleviewergallery>

