<?php
include_once(dirname(__FILE__) .'/nf/init.php');
$nf = new nfFw(
	'pages',
	'home_page',
	'settings',
	'attached_files attached',
	'events',
	'franchisees'
);

$nf->settings->find('first');
$nf->home_page->find('first');


$nf->attached->find('all', array(
	'conditions' => array('type' => 'home_page'),
	'order' => 'file_order ASC',
));


$nf->events->franchiseeFind('all', array(
	'conditions' => array(
		"IF(type='single_day', (date >= DATE(NOW())) , (end_date >= DATE(NOW())) ) ",
	),
	'order' => "IF(type='single_day',date,start_date) DESC, LOWER(name) ASC",
	'actiontype' => 'viewing'
));


$nf['title'] = $nf->settings['site_title'] . $nf->home_page['title'];
$nf['meta_desc'] = $nf->home_page['meta_desc'];
$nf['meta_keywords'] = $nf->home_page['meta_keywords'];

$nf['current_url'] = array('{BASE_URL}', '/');

$nf['show_footer'] = true;

$nf['content_template'] = 'home';
$nf['body_class'] = 'home';
// Main layout template
$nf->page_scripts = array('jquery', 'crossSlide', 'jqueryui', 'scrollto');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/main.php");

