<?php
include('../nf/init.php');
$nf = new nfFw(
	'case_studies'
);

$data_desc = "Case Study";
$data_desc_plural = "Case Studies";

$nf->auth->secure();
$nf->auth->checkAuthorized();

switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf->case_studies->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->case_studies['name'] = 'New page';
		$nf->case_studies['layout_type'] = 'type1';
		break;
	}

	case 'delete': {
		$model = $nf->case_studies;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'save': {
		$nf->case_studies['franchisee_id'] = (int)@$_SESSION['editing_franchisee']['id'];
		$nf->case_studies['type'] = 'page';
		$nf->case_studies->save();

		nf::flash("Changes have been saved.");
		break;
	}

	case 'save_order': {
		$nf->case_studies->save();
		$nf->case_studies->clearData();
		nf::flash("$data_desc order has been saved.");
		break;
	}

	case 'reorder': {
		$nf['section'] = 'reorder';
		break;
	}

	default:
}

$nf->case_studies->rows_all = $nf->case_studies->find('all', array(
	'order' => 'row_order ASC, LOWER(name) ASC',
	'conditions' => array('franchisee_id' => (int)@$_SESSION['editing_franchisee']['id']),
	'update_model_data' => false,
	'array_only' => true
));


$nf['subcontent_template'] = 'case_studies';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

