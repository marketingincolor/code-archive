<?php
include('../nf/init.php');
$nf = new nfFw('services costs', 'attached_files attached');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Additional Cost";
$data_desc_plural = "Additional Costs";


switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf->costs->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->costs['name'] = "New $data_desc";
		$nf->costs['suffix'] = "";
		break;
	}

	case 'delete': {
		$model = $nf->costs;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'save': {
		$nf->costs['service_type_id'] = $nf->costs->COST_CATEGORY;
		$nf->costs->save();
		$nf->costs->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	case 'save_order': {
		$nf->costs->save();
		$nf->costs->clearData();
		nf::flash("$data_desc order has been saved.");
		break;
	}


	case 'reorder': {
		$nf['section'] = 'reorder';
		break;
	}

	default:
}

$nf->costs->rows_all = $nf->costs->find('all', array(
	'order' => 'LOWER(name) ASC',
	'conditions' => array(
		'service_type_id' => $nf->costs->COST_CATEGORY
	),
	'array_only' => true,
	'update_model_data' => false
));



$nf['subcontent_template'] = 'additional_costs';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('currency', 'php_js', 'js1.6');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

