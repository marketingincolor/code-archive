<?php
include('../nf/init.php');
$nf = new nfFw('faqs');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "FAQ";
$data_desc_plural = "FAQs";

switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf->faqs->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->faqs['name'] = "New $data_desc";
		break;
	}

	case 'delete': {
		$model = $nf->faqs;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'save': {
		$nf->faqs->save();
		$nf->faqs->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	case 'save_order': {
		$nf->faqs->save();
		$nf->faqs->clearData();
		nf::flash("$data_desc order has been saved.");
		break;
	}


	case 'reorder': {
		$nf['section'] = 'reorder';
		break;
	}

	default:
}

$nf->faqs->rows_all = $nf->faqs->find('all', array(
	'order' => 'row_order ASC, LOWER(name) ASC',
	'array_only' => true,
	'update_model_data' => false
));



$nf['subcontent_template'] = 'faqs';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

