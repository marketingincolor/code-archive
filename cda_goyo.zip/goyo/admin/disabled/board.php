<?php
include('../nf/init.php');
$nf = new nfFw('board');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Board Member";
$data_desc_plural = "Board Members";

switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf->board->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->board['name'] = "New $data_desc";
		break;
	}

	case 'delete': {
		$model = $nf->board;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'save': {
		$id = @$nf->board['id'];
		$nf->board->save();
		$nf->board->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	case 'save_order': {
		$nf->board->save();
		$nf->board->clearData();
		nf::flash("$data_desc order has been saved.");
		break;
	}


	case 'reorder': {
		$nf['section'] = 'reorder';
		break;
	}

	default:
}

$nf->board->rows_all = $nf->board->find('all', array(
	'order' => 'row_order ASC, LOWER(name) ASC',
	'array_only' => true,
	'update_model_data' => false
));



$nf['subcontent_template'] = 'board';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

