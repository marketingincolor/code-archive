<?php
include('../nf/init.php');
$nf = new nfFw('franchisees', 'pages', 'attached_files attached', 'prefill', 'users', 'uscities');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Franchisee";
$data_desc_plural = "Franchisees";


switch (@$_REQUEST['action']) {
	case 'ajax_username_test': {
		$count = $nf->users->find('count', array(
			'conditions' => array(
				'type' => 'franchisee',
				'foreign_id !=' => @$_POST['franchisee_id'],
				'username' => @$_POST['username']
			)
		));

		if (in_array(@$_POST['username'], $nf->users->hidden_users)) {
			$count = 1;
		}

		echo json_encode($count);
		exit;
	}

	case 'select': {
		if (@$_GET['id'] == 'main') {
			unset($_SESSION['editing_franchisee']);
			nf::redirect($nf->base_url .'admin/');
			exit;
		}

		$_SESSION['editing_franchisee'] = $nf->franchisees->find('id', @$_GET['id'], array(
			'array_only' => true
		));

		if ($nf->franchisees->numRows() == 0) {
			nf::flash('The specified Franchisee could not be found', 'error');
			break;
		}

		nf::redirect($nf->base_url .'admin/');
		exit;
	}

	case 'ajax_url_test': {
		$count = (int)$nf->pages->find('count', array(
			'conditions' => array(
				'url' => @$_POST['url'],
				'franchisee_id IS NULL'
			)
		));

		$count += (int)$nf->franchisees->find('count', array(
			'conditions' => array(
				'url' => @$_POST['url'],
				'id !=' => @$_POST['id'],
			)
		));

		echo json_encode($count);
		exit;
	}

	case 'edit': {
		$nf->franchisees->find('id', @$_GET['id']);
		$nf->users->find('first', array(
			'fields' => 'username,id,foreign_id',
			'conditions' => array(
				'type' => 'franchisee',
				'foreign_id' => $nf->franchisees['id'],
			),
		));
		break;
	}

	case 'new': {
		$nf->franchisees['name'] = "New $data_desc";
		break;
	}

	case 'delete': {
		$model = $nf->franchisees;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}


	case 'save': {
		// Validation
		if (!$nf->users->validates() || !$nf->franchisees->validates()) {
			nf::flash("Please fill in all fields colored in red, then press the Submit button again", "error");
			break;
		}


		// Franchisee
		$orig_id = $nf->franchisees['id'];
		$nf->franchisees['address'] = trim($nf->franchisees['address'], "\n\r");
		$nf->franchisees->save();

		if (!$orig_id) {
			$template_franchisee = $nf->franchisees->template_row();
			$from_id = $template_franchisee['id'];
			$to_id = $nf->franchisees['id'];

			$nf->instantiate('nav _nav', 'franchisee_home_pages _franchisee_home_pages');
			$nf->_nav->copyFranchiseeData($from_id, $to_id, 'subnav');
			$nf->_franchisee_home_pages->copyFranchiseeData($from_id, $to_id);
		}


		// Security checks
		$num_pre_existing_users = $nf->users->find('count', array(
			'conditions' => array(
				'type' => 'franchisee',
				'foreign_id !=' => $nf->franchisees['id'],
				'username' => $nf->users['username']
			)
		));
		if (($num_pre_existing_users > 1) || in_array($nf->users['username'], $nf->users->hidden_users)) {
			$nf->users->clearData();
			nf::flash("Invalid Username - Changes could not be saved.", 'error');
			break;
		}

		// User
		if (!$nf->users['password']) {
			unset($nf->users['password']);
		} else {
			$nf->users['password'] = md5($nf->users['password']);
		}

		// Get user ID
		$id_row = $nf->users->find('first', array(
			'fields' => 'id',
			'conditions' => array(
				'type' => 'franchisee',
				'foreign_id' => $nf->franchisees['id'],
			),
			'update_model_data' => false
		));
		$nf->users['id'] = $id_row['id'];

		$nf->users['foreign_id'] = $nf->franchisees['id'];
		$nf->users['franchisee_id'] = $nf->franchisees['id'];
		$nf->users['email'] = $nf->franchisees['email'];
		$nf->users['type'] = 'franchisee';
		$nf->users['permissions'] = 'user,franchisee';
		$nf->users['landing_page'] = @$nf->users->user_landing_pages[$nf->users['type']];
		$nf->users->save();

		$nf->users->clearData();
		$nf->franchisees->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	default:
}

$nf->franchisees->rows_all = $nf->franchisees->find('all', array(
	'order' => 'name DESC',
	'update_model_data' => false,
	'array_only' => true,
));


$nf['subcontent_template'] = 'franchisees';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('fck', 'nffuncs', 'googlemaps', 'pmamap', 'pmamap_geocoder');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

