<?php
include('../nf/init.php');
$nf = new nfFw(
	'yogurts'
);

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Yogurt Flavor";
$data_desc_plural = "Yogurt Flavors";

switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf->yogurts->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->yogurts['name'] = "New $data_desc";
		break;
	}

	case 'delete': {
		$model = $nf->yogurts;
		include(dirname(__FILE__) .'/pieces/delete.php');
		$nf->db->quickQuery("DELETE FROM franchisee_yogurts WHERE yogurt_id=?", @$_GET['id']);
		break;
	}

	case 'save': {
		$nf->yogurts->save();
		$nf->yogurts->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	case 'save_order': {
		$nf->yogurts->save();
		$nf->yogurts->clearData();
		nf::flash("$data_desc order has been saved.");
		break;
	}


	case 'reorder': {
		$nf['section'] = 'reorder';
		break;
	}

	default:
}

$nf->yogurts->rows_all = $nf->yogurts->find('all', array(
	'order' => 'row_order ASC, LOWER(name) ASC',
	'array_only' => true,
	'update_model_data' => false
));



$nf['subcontent_template'] = 'yogurts';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

