<?php
include('../nf/init.php');
$nf = new nfFw('contacts_franchise_info contacts');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Contact - Franchise Info";
$data_desc_plural = "Contacts - Franchise Info";

switch (@$_REQUEST['action']) {
	case 'delete': {
		$model = $nf->contacts;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'view': {
		$nf->contacts->find('id', @$_GET['id']);
		break;
	}


	default:
}


$nf->contacts->rows_all = $nf->contacts->find('all', array(
	'order' => 'date_added DESC, LOWER(last_name) ASC',
	'array_only' => true,
	'update_model_data' => false,
	'conditions' => array('franchisee_id' => (int)@$_SESSION['editing_franchisee']['id'])
));



$nf['subcontent_template'] = 'contacts_franchise_info';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

