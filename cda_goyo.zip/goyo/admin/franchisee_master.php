<?php
include('../nf/init.php');
$nf = new nfFw();

$nf->auth->secure();
$nf->auth->checkAuthorized();

$nf['subcontent_template'] = 'franchisee_master';
$nf['content_template'] = 'admin/admin_page';
include($nf->base_dir ."templates/admin/main.php");

