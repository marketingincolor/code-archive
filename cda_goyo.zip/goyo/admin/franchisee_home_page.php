<?php
include('../nf/init.php');
$nf = new nfFw(
	'pages pages_all',
	'franchisees',
	'franchisee_home_pages fhp'
);

$nf->auth->secure();
$nf->auth->checkAuthorized();

if (!@$_SESSION['editing_franchisee']) {
	nf::redirect('home_page.php');
}


switch (@$_REQUEST['action']) {
	case 'save': {
		$nf->fhp['franchisee_id'] = (int)@$_SESSION['editing_franchisee']['id'];
		$nf->fhp->save();

		$nf->franchisees['id'] = (int)@$_SESSION['editing_franchisee']['id'];
		$nf->franchisees->save();

		//$nf->attached->saveFromJSON('home_page');
		nf::flash("Changes have been saved.");

		if (count((array)@$_POST['applyall']) > 0) {
			$applyall_data = array();
			foreach ((array)@$_POST['applyall'] as $field => $bool) {
				$applyall_data[$field] = $nf->fhp[$field];
			}

			$nf->fhp->apply_to_all($applyall_data);
		}

		break;
	}

	default:
}

$nf->fhp->id_field = 'franchisee_id';
$nf->fhp->find('id', @$_SESSION['editing_franchisee']['id']);
$nf->fhp->id_field = 'id';

/*
$nf->attached->find('all', array(
	'order' => 'file_order ASC',
	'conditions' => array('type' => 'home_page'),
	'fields' => array('upload_id', 'description', 'u.orig_filename'),
	'join' => array('model' => 'uploads u', 'clause' => 'u.id = attached.upload_id')
));
*/

$nf->pages_all->find('all', array('order' => 'LOWER(name) ASC'));
$nf['template_row'] = $nf->franchisees->template_row();

$nf['subcontent_template'] = 'franchisee_home_page';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'uploadify', 'nffuncs', 'fck', 'json', 'colorpicker');
$nf->page_css = array('colorpicker');
include($nf->base_dir ."templates/admin/main.php");

