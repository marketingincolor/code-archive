<?php
include('../nf/init.php');
$nf = new nfFw('pages', 'pages pages_all', 'home_page', 'attached_files attached');

$nf->auth->secure();
$nf->auth->checkAuthorized();

if (@$_SESSION['editing_franchisee']) {
	nf::redirect('franchisee_home_page.php');
}


switch (@$_REQUEST['action']) {
	case 'save': {
		$nf->home_page->save();
		$nf->attached->saveFromJSON('home_page');
		nf::flash("Changes have been saved.");
		break;
	}

	default:
}

$nf->home_page->find('first');
$nf->attached->find('all', array(
	'order' => 'file_order ASC',
	'conditions' => array('type' => 'home_page'),
	'fields' => array('upload_id', 'description', 'u.orig_filename'),
	'join' => array('model' => 'uploads u', 'clause' => 'u.id = attached.upload_id')
));

$nf->pages_all->find('all', array('order' => 'LOWER(name) ASC'));

$nf['subcontent_template'] = 'home_page';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'uploadify', 'nffuncs', 'fck', 'json', 'colorpicker');
$nf->page_css = array('colorpicker');
include($nf->base_dir ."templates/admin/main.php");

