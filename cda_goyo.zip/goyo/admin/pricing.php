<?php
include('../nf/init.php');
$nf = new nfFw();

$nf->auth->secure();
$nf->auth->checkAuthorized();

$nf['subcontent_template'] = 'pricing';
$nf['content_template'] = 'admin/admin_page';
include($nf->base_dir ."templates/admin/main.php");

