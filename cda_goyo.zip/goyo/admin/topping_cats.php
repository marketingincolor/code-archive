<?php
include('../nf/init.php');
$nf = new nfFw('topping_categories cats');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Topping Category";
$data_desc_plural = "Topping Categories";

switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf->cats->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->cats['name'] = "New $data_desc";
		break;
	}

	case 'delete': {
		$model = $nf->cats;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'save': {
		$nf->cats->save();
		$nf->cats->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	case 'save_order': {
		$nf->cats->save();
		$nf->cats->clearData();
		nf::flash("$data_desc order has been saved.");
		break;
	}

	case 'reorder': {
		$nf['section'] = 'reorder';
		break;
	}

	default:
}

$nf->cats->rows_all = $nf->cats->find('all', array(
	'order' => 'row_order ASC, LOWER(name) ASC',
	'array_only' => true,
	'update_model_data' => false
));



$nf['subcontent_template'] = 'topping_cats';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs', 'currency');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

