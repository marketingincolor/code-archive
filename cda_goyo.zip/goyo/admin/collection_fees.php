<?php
include('../nf/init.php');
$nf = new nfFw('collection_fees fees');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Collection Fee";
$data_desc_plural = "Collection Fees";


switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf->fees->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->fees['name'] = "New $data_desc";
		break;
	}

	case 'delete': {
		$model = $nf->fees;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'save': {
		$nf->fees->save();
		$nf->fees->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	default:
}

$nf->fees->rows_all = $nf->fees->find('all', array(
	'order' => 'LOWER(name) ASC',
	'array_only' => true,
	'update_model_data' => false
));



$nf['subcontent_template'] = 'collection_fees';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('currency');
//$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

