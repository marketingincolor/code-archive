<?php
include('../nf/init.php');
$nf = new nfFw('events', 'attached_files attached', 'franchisees');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Event";
$data_desc_plural = "Events";

switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf->events->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->events['name'] = "New $data_desc";
		$nf->events['type'] = "single_day";
		break;
	}

	case 'delete': {
		$model = $nf->events;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'save': {
		//$nf->events['franchisee_id'] = $nf->franchisees->current();
		$nf->events->franchiseeSave();
		$nf->attached->saveFromJSON('events', $nf->events['id']);
		$nf->events->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	case 'save_order': {
		$nf->events->save();
		$nf->events->clearData();
		nf::flash("$data_desc order has been saved.");
		break;
	}


	case 'reorder': {
		$nf['section'] = 'reorder';
		break;
	}

	default:
}

$nf->events->rows_all = $nf->events->franchiseeFind('all', array(
	'order' => "IF(type='single_day',date,start_date) DESC, LOWER(name) ASC",
//	'conditions' => array('franchisee_id' => $nf->franchisees->current()),
	'array_only' => true,
	'update_model_data' => false
));

if ($nf->events['id']) {
	$nf->attached->find('all', array(
		'order' => 'file_order ASC',
		'conditions' => array('type' => 'events', 'foreign_id' => $nf->events['id']),
		'fields' => array('upload_id', 'description', 'u.orig_filename'),
		'join' => array('model' => 'uploads u', 'clause' => 'u.id = attached.upload_id')
	));
}


$nf['subcontent_template'] = 'events';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs', 'timepicker', 'admin_time_inputs');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

