<?php  defined('C5_EXECUTE') or die(_("Access Denied.")); ?>
<div id="ccm-sitemap-throbber"><img src="<?php echo ASSETS_URL_IMAGES?>/throbber_white_32.gif" width="32" height="32" /></div>
<div id="ccm-search-results">
	<div id="ccm-search-results-total"></div>
	<ul id="ccm-search-results-list"></ul>
</div>