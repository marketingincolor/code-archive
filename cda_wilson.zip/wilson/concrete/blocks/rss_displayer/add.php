<?php 
defined('C5_EXECUTE') or die(_("Access Denied."));
$rssObj=$controller;
?>

<?php  include($this->getBlockPath().'/form_setup_html.php'); ?> 