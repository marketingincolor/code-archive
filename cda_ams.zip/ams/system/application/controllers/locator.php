<?php

class Locator extends Controller {

	function Locator()
	{
		parent::Controller();
		$this->load->helper(array('form', 'url'));
	}
	
	function index()
	{
		$data = array(
			'title' => 'Window Film, Window Tint, Car Tint - SUN-GARD Solar Window Film by Solamatrix',
			'main_content' => 'directory_message',
			'submitted' => $this->load->view('search_form_country.php','',true),
			'thiscountry' => '',
			'thisregion' => ''
			);
		$this->load->view('includes/template_3', $data);
	}

	function us()
	{
		$country = 'us';
		$rdata = array('country'=>$country,);
		$data = array(
			'title' => 'Window Film, Window Tint, Car Tint - SUN-GARD Solar Window Film by Solamatrix',
			'main_content' => 'directory_message',
			'submitted' => $this->load->view('search_form_region.php', $rdata, true),
			'thiscountry' => $country,
			'thisregion' => ''
			);
		$this->load->view('includes/template_3', $data);
	}
	
	function region_us($region)
	{
		$country = 'us';
		$rdata = array('country'=>$country,'region'=>$region);
		$data = array(
			'title' => 'Window Film, Window Tint, Car Tint - SUN-GARD Solar Window Film by Solamatrix',
			'main_content' => 'directory_results',
			'submitted' => $this->load->view('search_form_region.php', $rdata, true),
			'results' => $this->load->view('locator_region_results.php', $rdata, true),
			'thiscountry' => $country,
			'thisregion' => $region
			);
		$this->load->view('includes/template_3', $data);
	}
	
	function city_us($region,$city)
	{
		$country = 'us';
		$rdata = array('country'=>$country,'region'=>$region,'city'=>$city);
		$data = array(
			'title' => 'Window Film, Window Tint, Car Tint - SUN-GARD Solar Window Film by Solamatrix',
			'main_content' => 'directory_grp_results',
			'submitted' => $this->load->view('search_form_region.php', $rdata, true),
			'results' => $this->load->view('locator_city_results.php', $rdata, true),
			'thiscountry' => $country,
			'thisregion' => $region,
			'thiscity' => $city
			);
		$this->load->view('includes/template_3', $data);
	}
	
	function lookupr()
	{
		$thisregion = $_POST['state'];
		$thiscountry = 'United States';
			if ($thiscountry == 'United States') 
		{ 
			$newthiscountry = 'us'; 
		}
		redirect( $newthiscountry.'/'.strtolower($thisregion), 'location');
	}


}

/* End of file directory.php */
/* Location: ./system/application/controllers/directory.php */