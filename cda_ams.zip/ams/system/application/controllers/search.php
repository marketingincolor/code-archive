<?php

class Search extends Controller {

	function Search()
	{
		parent::Controller();
		$this->load->helper(array('form', 'url'));
	}
	
	function index()
	{
		$data = array(
			'main_content' => 'search_message',
			'submitted' => $this->load->view('search_form.php','',true)
			);
		$this->load->view('includes/template_2', $data);
	}

	function about()
	{
		$data = array(
			'main_content' => 'about_message',
			'submitted' => $this->load->view('search_form.php','',true)
			);
		$this->load->view('includes/template_2', $data);
	}
	
	function aboutdir()
	{
		$data = array(
			'main_content' => 'aboutdir_message',
			'submitted' => $this->load->view('search_form.php','',true)
			);
		$this->load->view('includes/template_2', $data);
	}
	
	//function faq()
	//{
	//	$data = array(
	//		'main_content' => 'faq_message',
	//		'submitted' => $this->load->view('search_form.php','',true)
	//		);
	//	$this->load->view('includes/template_2', $data);
	//}
	
	function directory()
	{
		$data['main_content'] = 'directory_message';
		$this->load->view('includes/template_2', $data);
	}
	
	
	function findstate($input)
	{
		$DB = $this->load->database('default', TRUE);        
		//$query = $DB->query('SELECT state FROM clients WHERE affiliate_id = "12" AND country = "'.$input.'"');
		$query = $DB->query('SELECT DISTINCT state FROM clients WHERE affiliate_id = "15" AND type_id != "0" AND country = "'.$input.'" ORDER BY state');
		$result = $query->result_array();

		if ($query->num_rows() > 0)
		{
   			//$row = $query->row_array();
   			//$row = $query->array();
			/*foreach ($query->result_array() as $row)
				{
					print_r ($query) ;
				}*/
		$showlist;
		foreach ($result as $query)
			$showlist[$query['state']] = $query['state'];
			
		//print_r($showlist);
		//return $showlist;
		
		
			echo "<select name='state' class='formbox' id='state' onChange='findclient()'><option value=''>Choose State/Region</option>";
			foreach ($showlist as $key => $value)
			{
			echo "<option value='".$value."'>".$value."</option>";
			}
			echo "</select>";
		} else {
			echo "<select name='state' class='formbox'><option value=''>None Available</option></select>";
		}

		/*$returned = $query->num_rows();
		//$testid = $row->client_id;
		//echo ''.$row['id'].'';
		//print_r ($query);
		if ($returned != '0') {
			print_r($showlist);
		    //$this->data['show_states'] = $this->get_state->get_dropdown_array('id', 'state','clients');
			echo "<span class='small'> AVAILABLE</span>$returned";
			
			//$row = $showlist;
			echo "<select name='state'>";
			foreach ($showlist as $key => $value)
			{
			echo "<option value=".$value."> ".$value. " ";
			}
			echo "</select>";
			
		} else {
			echo "<span class='small'>NOT AVAILABLE<span>$returned";
		}*/
	}
	function findclient($input)
	{
		$DB = $this->load->database('default', TRUE);        
		//$query = $DB->query('SELECT state FROM clients WHERE affiliate_id = "12" AND country = "'.$input.'"');
		//$query = $DB->query('SELECT * FROM clients WHERE affiliate_id = "12" AND type_id != "0" AND state = "'.$input.'"');
		$query = $DB->query('SELECT clients.id, clients.office_name, clients.address, clients.address2, clients.city, clients.state, clients.country, clients.zip, clients.phone, disks.id, disks.name, campaigns.id, campaigns.type FROM clients INNER JOIN disks ON (disks.client_id = clients.id) INNER JOIN campaigns ON ( campaigns.disk_id = disks.id) WHERE affiliate_id = "15" AND type_id != "0" AND state = "'.$input.'"');
		
		$result = $query->result_array();
		
		if ($query->num_rows() > 0)
		{
   			$row = $query->row_array();
   			//$row = $query->array();
   			echo "<h2>".$row['state']."</h2>";
			foreach ($query->result_array() as $row)
				{
					if ($row['type'] == 'matrix') {
						$instype = 'Auto and Flat Glass';
					} elseif ($row['type'] == 'matrix2') {
						$instype = 'Flat Glass';
					} elseif ($row['type'] == 'matrix3') {
					$instype = 'Automotive Glass';
					}
					if ($row['name']) {
						$clienturl = "<a href='http://www.affordable-medicare-supplement.com/".$row['name']."' target='_new'>".$row['office_name']."</a>";
					} else {
						$clienturl = $row['office_name'];
					}
					if (strlen($row['phone']) == 10) 
					{
						$clientphone = substr($row['phone'],0,3)."-".substr($row['phone'],3,3)."-".substr($row['phone'],6,4);
					} else {
						$clientphone = $row['phone'];
					}
					echo "<span style='font-size:18px; font-weight:bold;'>".$clienturl."</span><br>".$row['address']." ".$row['address2']."<br>".$row['city']."<br>".$row['zip']."<br><b>".$clientphone."</b><br><br>";
				}
		} else {
			//print_r ($query) ;
			echo "<h2>THIS IS NOT A RESULT!!!</h2>";
		}
		
		//$data['main_content'] = 'directory_message';
		//$this->load->view('includes/template_2', $data);
		
	}
	
}

/* End of file welcome.php */
/* Location: ./system/application/controllers/welcome.php */