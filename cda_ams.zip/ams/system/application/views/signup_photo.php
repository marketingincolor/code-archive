<html>
<head>
<title>LinkBox&trade; Capture Pages</title>
<style type="text/css">
	body { font-family:Tahoma,Verdana,Sans-serif; font-size:14px; color:#000; margin:0; background-color:#FFF; min-width:0; }
	#page { text-align:left;  padding:0px 10px; }
	.right { float:right; }
	.left { float:left; }
	.bold { font-weight:bold; }
	.white { color:#FFF; }
	.col { width:310px;}
	.mark { font-size:14px; font-weight:bold; }
	.orange { color:#F47921; }
	.grey { color:#7F7F7F; }
	.red { color:#FF0000; }
	.green { color:#42A320; }
	.small { font-size:12px; }
	.vsmall { font-size:10px; }
</style>
</head>
<body>
<div id="page">
	<div style="text-align:center;"><br><img src="<?php echo base_url();?>images/ams_logo.jpg" border="0"></div>
	<div class="col left">
		<p><span class="small grey"><i>Note: If you're not ready to upload a photo yet, you can skip this step and upload your 
		photo at a later time.</i></span></p>
		<h2 class="orange">About Uploading Your Photo</h2>
		<p>Your LinkBox&trade; comes with a placeholder image
		you are welcome to leave as-is or replace with an image 
		of yourself. For best results, size and crop your image 
		yourself to the following specs prior to uploading:
		<br><br>
		<span class="bold">
		<ul><li>150 pixels wide by 150 pixels high</li>
		<li>Saved as JPG or PNG format only</li></ul></span>
		<br><br>
		If you need to resize and crop your photo prior to uploaing, try an online resource
		such as <a href="http://www.picnik.com" target="_blanknew">Picnik.</a>
		<br><br>
		If you upload without resizing and cripping, the system will
		automatically resize your image so that it's no larger
		than 150 pixels wide or 150 pixels high, whichever
		is greater.</p>
		<p><span class="bold red">Tip:</span> If you upload a photo that requires resizing, be sure your face
		is as close ot the center of the photo as possible <b><i(>horizontally AND vertically)</i></b> for auto-cropping
		purposes.
		<br><br>
		If you find you're not happy with how your photo displays in your published LinkBox&trade;, try uploading
		a re-cropped picture (or a different picture) in the Edit Content area of your account dashboard.</p>
	</div>
	
	<div class="col right">
		<br><br><br><br>
		<img src="<?php echo base_url();?>images/ams_helpphoto.jpg" border="0"><br>
		<img src="<?php echo base_url();?>images/ams_autocropping.jpg">
	</div>
	<br clear="all">

</div>
<br><br><br><br>
</body>
</html>