
<div class="sc_col_one left" style="text-align:center;">
	<div id="select">
		<?php echo $submitted;?>
	</div>
	<div class="rounded right" style='width:376px; text-align:left; background-color:#f1f1f1; padding:5px;'>
		<p style="margin:5px 35px;">Learn more about<br>
		<a href="http://www.medicare.gov/find-a-plan/questions/medigap-home.aspx" target="_blank">Medicare Supplement (MediGap) Insurance</a></p>
	</div><br clear="all">
	<p class="vsmall grey" style="padding-left:80px; text-align:left;">The above link is provided as a courtesy only and its website owner in solely responsible for its content.</p>
	<br>
</div>

<div class="sc_col_two right" style="text-align:left;">
	<div id="ajaxDiv2">
		<h1 class="dkgrey" style="margin-bottom:0px;">About Medicare Supplement (MediGap) Insurance</h1>
		<p>A Medicare Supplement (or MediGap) policy fills the gap that Medicare alone doesn't pay.
		<br><br><img src="images/ams_grfx_apple.jpg"><br><br>
		With so many Medicare options out there, it's smart to have a professional, licensed agent guid you through
		the process of choosing the right MediGap policy to support your Medicare plan.
		<br><br><img src="images/ams_grfx_people.jpg"><br><br>
		</p>
		<br><br>

	</div>
</div>
<br clear="all">
