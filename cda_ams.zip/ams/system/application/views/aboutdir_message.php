
<div class="sc_col_one left" style="text-align:center;">
	<div id="select">
		<?php echo $submitted;?>
	</div>
	<div class="rounded right" style='width:376px; text-align:left; background-color:#f1f1f1; padding:5px;'>
		<p style="margin:5px 35px;">Learn more about<br>
		<a href="http://www.medicare.gov/find-a-plan/questions/medigap-home.aspx" target="_blank">Medicare Supplement (MediGap) Insurance</a></p>
	</div><br clear="all">
	<p class="vsmall grey" style="padding-left:80px; text-align:left;">The above link is provided as a courtesy only and its website owner in solely responsible for its content.</p>
	<br>
</div>

<div class="sc_col_two right" style="text-align:left;">
	<div id="ajaxDiv2">
		<h1 class="dkgrey" style="margin-bottom:0px;">About This Directory</h1>
		<p>The Affordable Medicare Supplement Directory is provided as a service to help Americans connect directly with
		licensed insurance agents, for guidance on choosing a MediGap option to supplement ordinary Medicare.
		<br><br>
		To find an insurance agent in your area, just click the pulldown menu at left and choose your state.
		<br><br>
		Please note that all agents participating in this directory are (NEED TO DISCLAIM OUR RELATIONSHIP WITH THE
		PARTICIPANTS).
		<br><br>
		If you are a licensed insurance agent that offers MediGap insurance and would like to particpate in this directory,
		<a href="#" onClick="window.open('http://www.affordable-medicare-supplement.com/joinform.html','_new','height=600,width=600,scrollbars=yes,location=no');">click here.</a>
		<br><br>
		</p>
		<br><br>

	</div>
</div>
<br clear="all">
