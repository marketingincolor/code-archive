<div id="page_nav" class="">
    <ul>
    <li><a href="./support">Home</a></li>
    <li><a href="./promotions">Promotions</a></li>
    <li><a href="./management">Management</a></li>
    <li id="active"><a href="./feedback">Feedback</a></li>
    </ul><br clear="all" />
</div>
<div class="sc_col_one left">
<h1 class="orange" style="margin-bottom:0px;">We Welcome Your Thoughts</h1>
<br>
<span style="font-size:18px;">Worldwide Widget Company<br>
LinkBox<sup>&trade;</sup> Feedback</span>
<hr style="border:1px solid #ccc;">
Have praise, an issue, a suggestion, or an experience to share about your LinkBox<sup>&trade;</sup> experience? Let us know!
<br><br>
<form>
<label for="name" class="bold">Name</label><br>
<input id="name" name="name"><br>
<br>
<label for="email" class="bold">Email</label><br>
<input id="email" name="email"><br>
<br>
<label for="comments" class="bold">Comments</label><br>
<textarea id="comments" name="comments" style="width:260px; height:80px;"></textarea><br>
<br>
<input type="reset" value="Submit" id="submit">
</form>
<br /><br />
</div>

<div class="sc_col_two right" style="text-align:center;">
<br />
<img src="<?php echo base_url();?>images/widget_fb.jpg" border="0">
<br />
<br />
<img src="<?php echo base_url();?>images/wwwc_photo_feed.jpg" border="0">
<br /><br />
</div>
<br clear="all">