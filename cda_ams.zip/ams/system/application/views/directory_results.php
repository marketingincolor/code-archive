
<div class="sc_col_one left" style="text-align:center;">
	<div id="select">
		<?php echo $submitted;?>
	</div>
	<div class="rounded right" style='width:376px; text-align:left; background-color:#f1f1f1; padding:5px;'>
		<p style="margin:5px 35px;">Learn more about<br>
		<a href="http://www.medicare.gov/find-a-plan/questions/medigap-home.aspx" target="_blank">Medicare Supplement (MediGap) Insurance</a></p>
	</div><br clear="all">
	<p class="vsmall grey" style="padding-left:80px; text-align:left;">The above link is provided as a courtesy only and its website owner in solely responsible for its content.</p>
	<br>
</div>

<div class="sc_col_two right" style="text-align:left;">
	<br><br>
	<div id="ajaxDiv2">

		<div id="resultbox" class="sc_col_one left"><!-- <?php echo $thiscountry;?> - <?php echo $thisregion;?> -->
			<h1 style="margin-bottom:0px;"><?php echo ucfirst($thisregion);?></h1>
			<h4>A B C D E F G H I J K L M N O P Q R S T U V W X Y Z</h4>
			<p><?php echo $results;?></p>
		</div>

	</div>
</div>
<br clear="all">

