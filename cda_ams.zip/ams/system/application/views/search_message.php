
<div class="sc_col_one left" style="text-align:center;">
	<div id="select">
		<?php echo $submitted;?>
	</div>
	<div class="rounded right" style='width:376px; text-align:left; background-color:#f1f1f1; padding:5px;'>
		<p style="margin:5px 35px;">Learn more about<br>
		<a href="http://www.medicare.gov/find-a-plan/questions/medigap-home.aspx" target="_blank">Medicare Supplement (MediGap) Insurance</a></p>
	</div><br clear="all">
	<p class="vsmall grey" style="padding-left:80px; text-align:left;">The above link is provided as a courtesy only and its website owner in solely responsible for its content.</p>
	<br>
</div>

<div class="sc_col_two right" style="text-align:left;">
	<br><br>
	<div id="ajaxDiv2">
		<div class="rounded border" style="padding:10px; width:370px">
		<p style="text-align:center; margin-top:0px;"><img src="images/ams_grfx_recent.jpg"></p>
		<p style="margin-left:60px;">
		<b>Test Name</b> | <a href="">Contact</a><br>
		City, State<br>
		<br>
		<b>Test Name</b> | <a href="">Contact</a><br>
		City, State<br>
		<br>
		<b>Test Name</b> | <a href="">Contact</a><br>
		City, State<br>
		<br>
		<b>Test Name</b> | <a href="">Contact</a><br>
		City, State<br>
		<br>
		<b>Test Name</b> | <a href="">Contact</a><br>
		City, State<br>
		<br>
		</p>
		</div>
		<br><br>
<!--		<h1 class="orange" style="margin-bottom:0px;">Why Solar Window Film?</h1>-->
<!--		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. -->
<!--		Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure -->
<!--		dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non -->
<!--		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>-->
<!--		<h1 class="orange" style="margin-bottom:0px;">Why SUN-GARD<sup>&reg;</sup>?</h1>-->
<!--		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. -->
<!--		Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure -->
<!--		dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non -->
<!--		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>-->
	</div>
</div>
<br clear="all">
