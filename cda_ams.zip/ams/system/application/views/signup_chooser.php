<div class="col_one left" style="text-align:center;"><img src="<?php echo base_url();?>images/ams_promo_left.jpg" border="0"></div>

<div class="col_two right">
<h2>Get a new online system to capture leads in as little as 5 minutes!</h2>

<h4 style="margin-bottom:4px;"><a href="#enter">Enter your promo code below.</a></h4>
<span style='font-size:12px;'>Don't have a promo code yet? <a href="#" onClick="window.open('http://www.affordable-medicare-supplement.com/joinform.html','_new','height=600,width=600,scrollbars=yes,location=no');">Click here.</a></span><br><br>
<ul id="benefits">
<li>Get a personalized LinkBox<sup>&trade;</sup> capture page that you can customize with your photo or logo and contact information. <a href="http://www.affordable-medicare-supplement.com/jim-smith" target="_blank">Click here to see a sample.</a></li>
<li>Takes as little as 5 minutes to sign up and be online!</li>
<li>Market your services 24/7.</li>
<li>Includes social sharing tools Facebook and Twitter, plus an online refer-a-friend system.</li>
<li>Visitors can request appointments for free quotes and ask questions right from your LinkBox capture page.</li>
<li>Online reporting helps you track leads and close opportunities.</li>
<li>Includes access to an online Support Center that helps you make the most of your LinkBox capture page.</li>
<li>Super simple to use. No training necessary.</li>
</ul>

<h4>This program is currently available to insurance agents licensed to sell Medicare Supplement Policies in North America. 
If you have not yet qualified for a promo code to signup for this system, please <a href="#" onClick="window.open('http://www.affordable-medicare-supplement.com/joinform.html','_new','height=600,width=600,scrollbars=yes,location=no');">click here first.</a></h4>
<br /><br />
<?php echo $submitted;?>

<br /><a name="enter"></a>
</div>
<br clear="all"><br>