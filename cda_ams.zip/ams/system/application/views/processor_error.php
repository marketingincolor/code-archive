<div class="col_one left" style="text-align:center;"><img src="<?php echo base_url();?>images/sungard_promo_left.jpg" border="0"></div>

<div class="col_two right">
<h1 class="headline" style="margin-bottom:0px;">Oops...</h1>
<br>
There was an error in processing your payment. Please try again by clicking the Payment button.
<!-- x<br><br>
<b>Please click the Subscribe button to begin your order:</b> -->
<br /><br />
<a href="../processing/success">fake good</a> &nbsp; <a href="../processing/error">fake bad</a>
<br />
<span class="vsmall">Major credit cards accepted, or you may use a PayPal Account.</span>
<br><br>
<b>Note:</b> After you've made your payment, you wil be sent to the content submission page - where you'll need just a 
few minutes to supply the content needed to launch your WebNet site.
<br />

</div>
<br clear="all">