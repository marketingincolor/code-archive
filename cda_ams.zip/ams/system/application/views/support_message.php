<div id="page_nav" class="">
    <ul>
    <li id="active"><a href="./support">Home</a></li>
    <li><a href="./promotions">Promotions</a></li>
    <li><a href="./management">Management</a></li>
    <li><a href="./feedback">Feedback</a></li>
    </ul><br clear="all" />
</div>
<div class="sc_col_one left">
<h1 class="orange" style="margin-bottom:0px;">Welcome to the LinkBox<sup>&trade;</sup> Support Center!</h1>
<h3>LinkBox Makes It Easy To Generate And Manage Leads For Your Business.</h3>

<p>Worldwide Widget Company provides its Sales Team a fast and affordable way to market
your business online through an easy-to-use set of lead generation, referral and tracking tools in one dynamic package. Your LinkBox<sup>&trade;</sup> Microsite!</p>

<p class="bold">To get started, please view the slideshow below.</p>
<img src="<?php echo base_url();?>images/wwwc_ss_qs.gif" border="0">
<!-- <object width="425" height="355" style="margin: 0px;"><param value="http://static.slidesharecdn.com/swf/ssplayer2.swf?doc=sun-gardquickstart2-100217112834-phpapp02&amp;rel=0&amp;stripped_title=sun-gard-quick-start2" name="movie"><param value="true" name="allowFullScreen"><param value="always" name="allowScriptAccess"><embed width="425" height="355" type="application/x-shockwave-flash" allowscriptaccess="always" src="http://static.slidesharecdn.com/swf/ssplayer2.swf?doc=sun-gardquickstart2-100217112834-phpapp02&amp;rel=0&amp;stripped_title=sun-gard-quick-start2" allowfullscreen="true"></object> -->
<br /><br />
</div>

<div class="sc_col_two right" style="text-align:center;">
<h2 class="white dkgreen" style="padding:10px;">Please BOOKMARK this page for future reference.</h2>
<br />
<img src="<?php echo base_url();?>images/widget_fb.jpg" border="0">
<br />
<br />
<img src="<?php echo base_url();?>images/wwwc_photo_home.jpg" border="0">
<br />
</div>
<br clear="all">
