<div id="page_nav" class="">
    <ul>
    <li><a href="./support">Home</a></li>
    <li><a href="./promotions">Promotions</a></li>
    <li id="active"><a href="./management">Management</a></li>
    <li><a href="./feedback">Feedback</a></li>
    </ul><br clear="all" />
</div>
<div class="sc_col_one left">
<h1 class="orange" style="margin-bottom:0px;">Managing Your LinkBox<sup>&trade;</sup> Site.</h1>
<br>
<img src="<?php echo base_url();?>images/wwwc_ss_m1.gif" border="0">
<br /><br />
<img src="<?php echo base_url();?>images/wwwc_ss_m2.gif" border="0">
<br /><br />
</div>

<div class="sc_col_two right" style="text-align:center;">
<br />
<img src="<?php echo base_url();?>images/widget_fb.jpg" border="0">
<br />
<br />
<img src="<?php echo base_url();?>images/wwwc_photo_mgmt.jpg" border="0">
<br /><br />
</div>
<br clear="all">