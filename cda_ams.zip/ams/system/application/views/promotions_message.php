<div id="page_nav" class="">
    <ul>
    <li><a href="./support">Home</a></li>
    <li id="active"><a href="./promotions">Promotions</a></li>
    <li><a href="./management">Management</a></li>
    <li><a href="./feedback">Feedback</a></li>
    </ul><br clear="all" />
</div>
<div class="sc_col_one left">
<h1 class="orange" style="margin-bottom:0px;">Promoting Your LinkBox<sup>&trade;</sup> Site Is Your Key To Success.</h1>
<br>
<!-- <img src="<?php echo base_url();?>images/wwwc_ss_pr.gif" border="0"> -->
<object width="425" height="355"><param name="movie" value="http://static.slidesharecdn.com/swf/ssplayer2.swf?doc=worldwidewidgetpromotions-100420142151-phpapp01&rel=0&stripped_title=worldwide-widget-promotions" /><param name="allowFullScreen" value="true"/><param name="allowScriptAccess" value="always"/><embed src="http://static.slidesharecdn.com/swf/ssplayer2.swf?doc=worldwidewidgetpromotions-100420142151-phpapp01&rel=0&stripped_title=worldwide-widget-promotions" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="425" height="355"></embed></object>
<br /><br />
</div>

<div class="sc_col_two right" style="text-align:center;">
<br />
<img src="<?php echo base_url();?>images/widget_fb.jpg" border="0">
<br />
<br />
<img src="<?php echo base_url();?>images/wwwc_photo_prom.jpg" border="0">
<br /><br />
</div>
<br clear="all">