<!-- <div id="page_nav" class="">
    <ul>
    <li id="active"><a href=".">Home</a></li>
    <li><a href="./promotions">Promotions</a></li>
    <li><a href="./management">Management</a></li>
    <li><a href="./feedback">Feedback</a></li>
    </ul><br clear="all" />
</div>
<div class="sc_col_one left">
<h1 class="orange" style="margin-bottom:0px;">Welcome to the WebNet Support Center!</h1>
<h3>WebNet Makes It Easy To Generate And Manage Leads For Your Business.</h3>

<p>The WebNet mission is simple. Solamatrix provides authorized SUN-GARD dealers a fast and affordable way to market
your business online through an easy-to-use set of lead generation, referral and tracking tools in one dynamic package.</p>

<p>To get started, please view the slideshow below.</p>

<object width="425" height="355" style="margin: 0px;"><param value="http://static.slidesharecdn.com/swf/ssplayer2.swf?doc=sun-gardquickstart2-100217112834-phpapp02&amp;rel=0&amp;stripped_title=sun-gard-quick-start2" name="movie"><param value="true" name="allowFullScreen"><param value="always" name="allowScriptAccess"><embed width="425" height="355" type="application/x-shockwave-flash" allowscriptaccess="always" src="http://static.slidesharecdn.com/swf/ssplayer2.swf?doc=sun-gardquickstart2-100217112834-phpapp02&amp;rel=0&amp;stripped_title=sun-gard-quick-start2" allowfullscreen="true"></object>
<br /><br />
</div>

<div class="sc_col_two right" style="text-align:center;">
<h2 class="white dkgreen" style="padding:10px;">Please BOOKMARK this page for future reference.</h2>
<br />
<script type="text/javascript" src="http://static.ak.connect.facebook.com/js/api_lib/v0.4/FeatureLoader.js.php/en_US"></script>
<script type="text/javascript">FB.init("14758cbb2716d8f443420ad77354f6f1");</script><fb:fan profile_id="36542010101" stream="0" connections="14" logobar="0" width="406"></fb:fan>
\
<br />
<img src="<?php echo base_url();?>images/sgd_sc_h_pic.jpg" border="0">
<br />
</div> -->
SUNGARDDEALER.COM
<br clear="all">
