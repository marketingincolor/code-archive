<div class="col_one left" style="text-align:center;"> </div>

<div class="col_two right">
<h1 class="headline" style="margin-bottom:0px;">Thank You!</h1>

<p>Please check your email now for further information about how to start using your LinkBox capture page right away! It has been sent to the email address you submitted with this form.</p>

<?php echo $error;?>


<br /><br />

</div>
<br clear="all">