<div class="sc_col_one left">
<h1 class="orange" style="margin-bottom:0px;">Welcome to the WebNet Support Center!</h1>
<h3>Directory Page Goes Here - Listing created by results of previous Search page.</h3>

<p>Directory Page Goes Here - Listing created by results of previous Search page.</p>

<p>Insert Results Here.</p>
<p>Insert Results Here.</p>
<p>Insert Results Here.</p>
<p>Insert Results Here.</p>
<p>Insert Results Here.</p>
<p>Insert Results Here.</p>
<p>Insert Results Here.</p>
<p>Insert Results Here.</p>
<p>Insert Results Here.</p>

</div>

<div class="sc_col_two right" style="text-align:center;">
<h2 class="white dkgreen" style="padding:10px;">Please BOOKMARK this page for future reference.</h2>
<br />

<br />
</div>

<br clear="all">
