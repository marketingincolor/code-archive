<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<meta name="description" content="Looking for widgets in <?php echo $city;?>? Worldwide Widget Company offers the widgetiest selection of quality doohickeys at prices so low, they're ... well, insane!">
<link rel="image_src" href="http://www.myprojectcenter.net/templates/wwwc/images/wwc_logo.jpg" / >
<head>
<title><?php echo $office_name;?> - Great Widgets in <?php echo $city;?></title>
</head>
<frameset>
<frame frameborder="0" src="http://localhost/MPC-2/matrix.php?d=<?php echo $diskid;?>" marginheight="0" marginwidth="0"
 noresize="noresize" scrolling="auto" />
<!-- <frame frameborder="0" src="http://www.myprojectcenter.net/matrix.php?d=<?php echo $diskid;?>" marginheight="0" marginwidth="0"
 noresize="noresize" scrolling="auto" /> -->
</frameset>
</html>


