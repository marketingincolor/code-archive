<?php $this->load->view('includes/header_2'); ?>

<?php $this->load->view($main_content); ?>

<?php $this->load->view('includes/footer'); ?>