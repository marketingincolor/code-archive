<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html>
<head>
<title>Affordable Medicare Supplement - A division of LinkBox Demo Corporation</title>
<link rel="stylesheet" href="<?php echo base_url();?>css/grid.css" type="text/css">
<link rel="stylesheet" href="<?php echo base_url();?>css/style.css" type="text/css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js" type="text/javascript" charset="utf-8"></script>
</head>
<body>
<div id="header" class="container_16">&nbsp;<!--<img src="<?php echo base_url();?>images/ams_header.jpg" border="0">--></div>
<div class="container container_16">
