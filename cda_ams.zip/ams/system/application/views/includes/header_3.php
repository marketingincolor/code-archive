<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html>
<head>
<title>Affordable Medicare Supplement - A division of LinkBox Demo Corporation</title>
<link rel="stylesheet" href="<?php echo base_url();?>css/grid.css" type="text/css">
<link rel="stylesheet" href="<?php echo base_url();?>css/style.css" type="text/css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js" type="text/javascript" charset="utf-8"></script>
</head>
<body>
<div id="header2" class="container_16">
	<div id="header_r1" class="grid_7 prefix_8 suffix_1">
		<span id="headspan" class="right"><a href="#" class="white small" onClick="window.open('http://www.affordable-medicare-supplement.com/joinform.html','_new','height=600,width=600,scrollbars=yes,location=no');">Are you an insurance agent? Get listed with LinkBox&trade;</a></span>
	</div>
	<div class='clear'>&nbsp;</div>
	<div id="header_r2" class="grid_8 prefix_7 suffix_1">
		<span id="headspan" class="right">
		<a href="<?php echo base_url();?>" class="black">Home</a> | <a href="<?php echo base_url();?>about" class="black">About Medicare Supplement Insurance</a> | <a href="<?php echo base_url();?>about-directory" class="black">About This Directory</a>
		</span>
	</div>
	<div id="header_r3" class="grid_7 prefix_8 suffix_1">
		<span id="headspan" class="right">
			<script type="text/javascript">
				tweetmeme_style = 'compact';
				tweetmeme_url = 'http://affordable-medicare-supplement.com';
			</script>
			<script type="text/javascript" src="http://tweetmeme.com/i/scripts/button.js"></script>
			<iframe src="http://www.facebook.com/plugins/like.php?href=http://affordable-medicare-supplement.com&layout=standard&show_faces=false&width=450&action=like&colorscheme=light&height=80" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:260px; height:23px;" allowTransparency="true"></iframe>
		</span>
	</div>
</div>

<div class="container container_16">
<div class="grid_16" style="text-align:center;"><span style="font-size:24px; color:#698130;">Need Affordable <b>Medicare Supplement Insurance</b>?</span></div>