<?php  defined('C5_EXECUTE') or die(_("Access Denied.")); ?>

<h1><?php echo $titleContent?></h1>

<div class="ccm-error"><?php  print $innerContent ?></div>