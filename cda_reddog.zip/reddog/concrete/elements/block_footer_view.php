<?php 
defined('C5_EXECUTE') or die(_("Access Denied."));

if($blockStyles && $blockStyles->getID() ){ ?></div><?php  } ?>