<?php 
defined('C5_EXECUTE') or die(_("Access Denied."));
$rssObj=$controller;
?>

<?php   $bt->inc('form_setup_html.php',array('rssObj'=>$rssObj)); ?>