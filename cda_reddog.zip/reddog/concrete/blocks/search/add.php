<?php 
defined('C5_EXECUTE') or die(_("Access Denied."));
$searchObj=$controller;
?>

<?php  $this->inc('form_setup_html.php', array('c' => $c)); ?> 