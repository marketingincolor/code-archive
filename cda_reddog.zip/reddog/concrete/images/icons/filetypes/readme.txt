Jm Art Studio / Jrdn88
www.Jm-ArtStudio.com  or  jrdn88.deviantart.com


Thank you for downloading my project(s).  If you need help installing or appling anything please visit my help desk at http://www.jm-artstudio.com/help




User Agreement
_______________

By downloading, you acknowledge and agree that the software/project is provided on an "AS IS" basis without warranty of any kind. In no event shall Jm Art Studio be liable for claims or damages of any nature, whether direct or indirect, arising from or related to any software downloaded through the Service.

The content contained within my site is for personal use only. All text, graphics and selection and arrangement
thereof and all materials on this website are copyrighted. Unauthorized use of the content may violate copyright, 
trademark, and other laws. None of the content may be resold or redistributed without the prior written consent 
of Jm Art Studio. 

Please contact me before using any of my projects anywhere. I would require that a link be made back to my home page and also one picture ad be placed anywhere on your site. See http://www.jm-artstudio.com/link



(c) Jm Art Studio and Jrdn88