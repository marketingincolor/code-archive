<?php 

defined('C5_EXECUTE') or die(_("Access Denied."));
class ReportsDashboardModuleController extends Controller {


}