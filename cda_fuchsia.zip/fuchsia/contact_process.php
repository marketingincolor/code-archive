<?php
/* PHP Form Mailer - phpFormMailer v2.2, last updated 23rd Jan 2008 - check back often for updates!
   (easy to use and more secure than many cgi form mailers) FREE from:
                  www.TheDemoSite.co.uk
      Should work fine on most Unix/Linux platforms
      for a Windows version see: asp.thedemosite.co.uk
*/

// ------- three variables you MUST change below  -------------------------------------------------------
$replyemail="traci@fuchsiafocus.com,etwilbeck@cds-2-go.com";//change to your email address
$valid_ref1="http://fuchsiafocus.com/contact.html";// chamge "Your--domain" to your domain
$valid_ref2="http://www.fuchsiafocus.com/contact.html";// chamge "Your--domain" to your domain

// -------- No changes required below here -------------------------------------------------------------
// email variable not set - load $valid_ref1 page
if (!isset($_POST['email']))
{
 echo "<script language=\"JavaScript\"><!--\n ";
 echo "top.location.href = \"$valid_ref1\"; \n// --></script>";
 exit;
}

$ref_page=$_SERVER["HTTP_REFERER"];
$valid_referrer=0;
if($ref_page==$valid_ref1) $valid_referrer=1;
elseif($ref_page==$valid_ref2) $valid_referrer=1;
if(!$valid_referrer)
{
 echo "<script language=\"JavaScript\"><!--\n alert(\"ERROR - not sent.\\n\\nCheck your 'valid_ref1' and 'valid_ref2' are correct within contact_process.php.\");\n";
 echo "top.location.href = \"contact.html\"; \n// --></script>";
 exit;
}

//check user input for possible header injection attempts!
function is_forbidden($str,$check_all_patterns = true)
{
 $patterns[0] = 'content-type:';
 $patterns[1] = 'mime-version';
 $patterns[2] = 'multipart/mixed';
 $patterns[3] = 'Content-Transfer-Encoding';
 $patterns[4] = 'to:';
 $patterns[5] = 'cc:';
 $patterns[6] = 'bcc:';
 $forbidden = 0;
 for ($i=0; $i<count($patterns); $i++)
  {
   $forbidden = eregi($patterns[$i], strtolower($str));
   if ($forbidden) break;
  }
 //check for line breaks if checking all patterns
 if ($check_all_patterns AND !$forbidden) $forbidden = preg_match("/(%0a|%0d|\\n+|\\r+)/i", $str);
 if ($forbidden)
 {
  echo "<font color=red><center><h3>STOP! Message not sent.</font></h3><br><b>
        The text you entered is forbidden, it includes one or more of the following:
        <br><textarea rows=9 cols=25>";
  foreach ($patterns as $key => $value) echo $value."\n";
  echo "\\n\n\\r</textarea><br>Click back on your browser, remove the above characters and try again.
        </b><br><br><br><br>Thankfully protected by phpFormMailer freely available from:
        <a href=\"http://thedemosite.co.uk/phpformmailer/\">http://thedemosite.co.uk/phpformmailer/</a>";
  exit();
 }
 else return $str;
}
$name1 = is_forbidden($_POST["name1"]);
$name2 = is_forbidden($_POST["name2"]);
$name = $name1 . " " . $name2;
$title = $_POST["title"];
$organization = $_POST["organization"];
$address1 = $_POST["address1"];
$address2 = $_POST["address2"];
$city = $_POST["city"];
$state = $_POST["state"];
$zip = $_POST["zip"];
$email = is_forbidden($_POST["email"]);
$phone = is_forbidden($_POST["phone"]);
$contact = $_POST["contact"];
$comments = is_forbidden($_POST["comments"], false);

$success_sent_msg='<p align="center"><strong>&nbsp;</strong></p>
                   <p align="center"><strong>Your message has been successfully sent to us<br>
                   </strong> and we will reply as soon as possible.</p>
                   <p align="center">A copy of your query has been sent to you.</p>
                   <p align="center">Thank you for contacting us.</p>
                   ' . $name1 . $name2 . $email . $phone . $comments;

$replymessage = "Hi $name
Thank you for your email.
We will endeavour to reply to you shortly.
Please DO NOT reply to this email.
Below is a copy of the message you submitted:
--------------------------------------------------
Subject: $thesubject
Query:
$themessage
--------------------------------------------------
Thank you";

$themessage = "name: $name \n
              title: $title \n
              organization: $organization \n
              address1: $address1 \n
              address2: $address2 \n
              city: $city \n
              state: $state \n
              zip: $zip \n
              phone: $phone \n
              email: $email \n
              contact method: $contact \n
              comments: $comments";

mail("$replyemail",
     "Contact Form",
     "$themessage",
     "From: $email\nReply-To: $email");
/*mail("$email",//commented by ET to stop the system from sending email to the person using the form
     "Receipt: $thesubject",
     "$replymessage",
     "From: $replyemail\nReply-To: $replyemail");*/

//commented out to remove the echo of the sucessful send - page should now stay on contact.html
//echo $success_sent_msg;
header("Location: http://www.fuchsiafocus.com/contact.html");

/*
  PHP Form Mailer - phpFormMailer (easy to use and more secure than many cgi form mailers)
   FREE from:

    www.TheDemoSite.co.uk       */
?>

