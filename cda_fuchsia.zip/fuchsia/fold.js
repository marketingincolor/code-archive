// javascript layer expander
// 1-9-2009
// liberated by edd

function expandCollapse() {
for (var i=0; i<expandCollapse.arguments.length; i++) {
var element = document.getElementById (expandCollapse.arguments[i]);
element.style.display = (element.style.display == "none") ? "block" : "none";
}
}