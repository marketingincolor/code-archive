<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Edd
 * Date: 3/18/13
 * Time: 8:50 AM
 * To change this template use File | Settings | File Templates.
 */
//phpinfo();
$to = "etwilbeck@marketingincolor.com";
$subject = "Testing overall mail function";
$message = "Hello! This is a simple email message.";
$from = "admin@vifurniture.com";
$headers = "From:" . $from;
//mail($to,$subject,$message,$headers);
mail("etwilbeck@marketingincolor.com","email subject line","email message line","From:noreply@vifurniture.com");
echo "Mail Sent.";
//echo system('host -t mx promartialarts.com 2>&1')

?>