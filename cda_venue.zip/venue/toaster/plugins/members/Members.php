<?php 
class Members implements RCMS_Core_PluginInterface {
 
	public function  __construct($options, $seotoasterData) {
		$this->_view   = new Zend_View(array(
    	'scriptPath' => dirname(__FILE__) . '/views'
    	));
    	$this->_view->websiteUrl = $seotoasterData['websiteUrl'];
	}
	
	public function run($params = array()) {
	//return "Members Plugin Testing";
	$this->_view->pluginTitle = 'Members';   
	return $this->_view->render('members.phtml');

	}
	public function addmembers() {
	echo "Members Plugin Testing";
	}
}
