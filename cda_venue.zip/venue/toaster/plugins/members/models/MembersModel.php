<?php

/**
 * MembersModel model for Members plugin
 *
 * @author eddt
 */
class MembersModel extends RCMS_Core_BaseModel {
	
	protected $_name = 'user';
	
    public function insertUser(RCMS_Object_User_User $user)
    {
        $data = array (
            'role_id'			=> $user->getRoleId(),
            'id_user_seosamba'	=> $user->getIdSeosambaUser(),
            'login'             => $user->getLogin(),
            'password'          => $user->getPassword(),
            'email'             => $user->getEmail(),
            'status'            => $user->getStatus(),
            'nickname'          => $user->getNickName(),
            'last_login'        => $user->getLastLogin(),
            'ipaddress'         => $user->getIpAddress(),
            'reg_date'          => $user->getRegDate()
		);
		$this->_adapter->insert('user', $data);
		return $this->_adapter->lastInsertId('user');
    }
}