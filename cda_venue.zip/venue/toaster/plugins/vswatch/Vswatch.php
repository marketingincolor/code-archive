<?php 
class Vswatch implements RCMS_Core_PluginInterface {
 
	public function  __construct($options, $seotoasterData) {
		$this->_view   = new Zend_View(array(
    	'scriptPath' => dirname(__FILE__) . '/views'
    	));
    	$this->_view->websiteUrl = $seotoasterData['websiteUrl'];
	}
	
	public function run($params = array()) {
	$this->_view->pluginTitle = 'Click a chip to select';   
	return $this->_view->render('vswatch.phtml');

	}
}