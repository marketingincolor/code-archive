<?php
date_default_timezone_set('UTC');

if (is_dir(realpath(dirname(__FILE__).'/install/'))) {
    header('Location: install/index.html'); exit;
}
if (is_file(realpath(dirname(__FILE__).'/config.php'))) {
    require_once realpath(dirname(__FILE__).'/config.php');
} else {
    define('SITE_NAME', '');
}

// Define path to application directory
defined('APPLICATION_PATH')
    || define('APPLICATION_PATH', realpath(dirname(__FILE__) . '/seotoaster_core/application'));

// Define application environment
defined('APPLICATION_ENV')
    || define('APPLICATION_ENV', (getenv('APPLICATION_ENV') ? getenv('APPLICATION_ENV') : 'production'));

// Ensure library/ is on include_path
set_include_path(implode(PATH_SEPARATOR, array(
    realpath(APPLICATION_PATH . '/../library'),
    get_include_path(),
)));


/** Zend_Application */
require_once 'Zend/Application.php';  

// Create application, bootstrap, and run
$application = new Zend_Application(
    APPLICATION_ENV, 
    APPLICATION_PATH . '/configs/' . SITE_NAME . 'application.ini'
);

$application->bootstrap()->run();