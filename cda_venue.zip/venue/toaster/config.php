<?php 
define ('APPLICATION_PATH', 'D:\server\www\myserver.dev\public_html\venue\toaster\seotoaster_core/application'); 
define ('SITE_NAME', 'Venue/'); 


