

<html><head><title>MySQL Table Viewer</title></head><body>
<?php

$time_elapsed=time();

$db_host = 'sql5c40d.carrierzone.com';
$db_user = '2k5erssxfs305745';
$db_pwd = 'candace';

$database = 'vifurniture_2k5erssxf_site_aplus_net';
$table = 'page';

if (!mysql_connect($db_host, $db_user, $db_pwd))
    die("Can't connect to database");

if (!mysql_select_db($database))
    die("Can't select database");

// sending query
$result = mysql_query("SELECT * FROM {$table}");
if (!$result) {
    die("Query to show fields from table failed");
}

$fields_num = mysql_num_fields($result);

echo "<h1>Table: {$table}</h1>";
echo "<table border='1'><tr>";
// printing table headers
for($i=0; $i<$fields_num; $i++)
{
    $field = mysql_fetch_field($result);
    echo "<td>{$field->name}</td>";
}
echo "</tr>\n";
// printing table rows
while($row = mysql_fetch_row($result))
{
    echo "<tr>";

    // $row is array... foreach( .. ) puts every element
    // of $row to $cell variable
    foreach($row as $cell)
        echo "<td>$cell</td>";

    echo "</tr>\n";
}
mysql_free_result($result);

echo "</table>";

echo "\n";
echo "\n";
echo "\n";
echo "\n";
echo "\n";
echo "\n";
echo "\n";

function calcElapsedTime($time)
{ // calculate elapsed time (in seconds!)
$diff = time()-$time;
$daysDiff = floor($diff/60/60/24);
$diff -= $daysDiff*60*60*24;
$hrsDiff = floor($diff/60/60);
$diff -= $hrsDiff*60*60;
$minsDiff = floor($diff/60);
$diff -= $minsDiff*60;
$secsDiff = $diff;
return ('(elapsed time '.$daysDiff.'d '.$hrsDiff.'h '.$minsDiff.'m
'.$secsDiff.'s)');


}
echo calcElapsedTime($time_elapsed);
?>
</body></html>

