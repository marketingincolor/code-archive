<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class ToolsHelper extends Zend_View_Helper_Abstract {

    static public function cropType($fileName)
    {
        $fileName = (string) trim($fileName);
        $array = explode('.', $fileName);
        unset($array[count($array)-1]);
        return implode('', $array);
    }
}
?>
