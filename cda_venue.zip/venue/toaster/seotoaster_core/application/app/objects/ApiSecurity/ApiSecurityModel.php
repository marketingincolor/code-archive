<?php
class RCMS_Object_ApiSecurity_ApiSecurityModel extends RCMS_Core_BaseModel {

	/**
	 * Check user using login and password
	 *
	 * @param string $login
	 * @param string $password
	 * @return integer id or false on failure
	 */
	public function checkUserByLoginAndPass($login, $password) {
		$select = $this->getAdapter()->select()
			->from(
				array('u' => 'user'),
				'id'
			)
			->where('login=?', $login)
			->where('password=?', $password);
		$result = $this->_adapter->fetchRow($select, null, Zend_Db::FETCH_ASSOC);
		if(!empty($result)) {
			return $result['id'];
		}
		return false;
	}

	public function saveAuthDescriptor($userId, $descriptor) {
		//@will be implemented in future
	}
}