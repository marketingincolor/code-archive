<?php

/**
 * Description of QuoteModel
 *
 * @author NE
 */
class RCMS_Object_Quote_QuoteModel extends RCMS_Core_BaseModel {


	public function selectQuteById($quoteId) {
		$select = $this->getAdapter()->select()
			->from(
				array('sq' => 'shopping_quote'),
				array(
					'name',
					'content',
					'status',
					'disclaimer',
					'int_msg',
					'sc_id',
					'date',
                    'last_edited_by',
                    'valid_until',
                    'discount'
				)
			)
			->where('id=?', $quoteId);
		return $this->getAdapter()->fetchRow($select);
	}

	public function insertQuote(RCMS_Object_Quote_Quote $quote) {
		$quoteData = array(
			'name'       => $quote->getName(),
			'content'    => $quote->getContent(),
			'status'     => $quote->getStatus(),
			'disclaimer' => $quote->getDisclaimer(),
			'int_msg'    => $quote->getInternalMessage(),
			'sc_id'      => $quote->getShoppingCartId(),
            'last_edited_by'   => $quote->getLastEditedBy(),
            'valid_until' => $quote->getValidUntilDate(),
            'discount'   => $quote->getDiscount()
		);
		$this->getAdapter()->insert('shopping_quote', $quoteData);
		return $this->getAdapter()->lastInsertId('shopping_quote');
	}

	public function updateQuote(RCMS_Object_Quote_Quote $quote) {
		$quoteData = array(
			'name'       => $quote->getName(),
			'content'    => $quote->getContent(),
			'status'     => $quote->getStatus(),
			'disclaimer' => $quote->getDisclaimer(),
			'date'       => $quote->getDate(),
			'int_msg'    => $quote->getInternalMessage(),
            'last_edited_by'   => $quote->getLastEditedBy(),
            'valid_until' => $quote->getValidUntilDate(),
            'discount'   => $quote->getDiscount()
		);
		return $this->getAdapter()->update('shopping_quote', $quoteData, 'shopping_quote.id = ' . $quote->getId());
	}

	public function deleteQuote($quoteId) {
		return $this->getAdapter()->delete('shopping_quote', 'id = '. $quoteId);
	}

}

