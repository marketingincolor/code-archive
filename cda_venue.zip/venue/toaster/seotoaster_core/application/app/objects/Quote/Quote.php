<?php

/**
 * Description of Quote
 *
 * @author NE
 */
class RCMS_Object_Quote_Quote extends RCMS_Core_BaseObject {

	const Q_NAME_PREFIX = 'quote_';

	const Q_STATUS_NEW  = 'new';

	const Q_STATUS_SENT = 'sent';

	const Q_STATUS_SOLD = 'sold';

	const Q_STATUS_LOST = 'lost';

	protected $_scId         = 0;

	protected $_name         = '';

	protected $_content      = '';

	protected $_status       = '';

	protected $_intMessage   = '';

	protected $_date         = '';

	protected $_disclaimer   = '';

    protected $_lastEditedBy = '';
    
    protected $_owner = '';

    protected $_validUntilDate = '';

    protected $_discount = 0;

	public function  __construct($id = 0) {
		$this->_model = new RCMS_Object_Quote_QuoteModel();
		if($id) {
			$quoteData = $this->_model->selectQuteById($id);
			if(!empty($quoteData)) {
				$this->_id              = $id;
                $this->_name            = $quoteData['name'];
				$this->_content         = $quoteData['content'];
				$this->_status          = $quoteData['status'];
				$this->_intMessage      = $quoteData['int_msg'];
				$this->_scId            = $quoteData['sc_id'];
				$this->_date            = $quoteData['date'];
				$this->_disclaimer      = $quoteData['disclaimer'];
                $this->_lastEditedBy    = $quoteData['last_edited_by'];
                $this->_owner 		    = $quoteData['owner'];
                $this->_validUntilDate  = $quoteData['valid_until'];
                $this->_discount        = $quoteData['discount'];
			}
		}
	}

	public function getShoppingCartId() {
		return $this->_scId;
	}

	public function setShoppingCartId($scId) {
		$this->_scId = $scId;
	}

	public function getName() {
		return $this->_name;
	}

	public function setName($name) {
		$this->_name = $name; //substr(md5($name), 3, 15);
	}

	public function getContent() {
		return $this->_content;
	}

	public function setContent($content) {
		$this->_content = $content;
	}

	public function getStatus() {
		return $this->_status;
	}

	public function setStatus($status) {
		$this->_status = $status;
	}

	public function getInternalMessage() {
		return $this->_intMessage;
	}

	public function setInternalMessage($intMessage) {
		$this->_intMessage = $intMessage;
	}

	public function getDate() {
		return $this->_date;
	}

	public function setDate($date) {
		$this->_date = $date;
	}

	public function getDisclaimer() {
		return $this->_disclaimer;
	}

	public function setDisclaimer($disclaimer) {
		$this->_disclaimer = $disclaimer;
	}

	protected function _insert() {
		return $this->_model->insertQuote($this);
	}

	protected function _update() {
		return $this->_model->updateQuote($this);
	}

	public function delete() {
		return $this->_model->deleteQuote($this->_id);
	}

    public function getLastEditedBy() {
        return $this->_lastEditedBy;
    }

    public function setLastEditedBy($user) {
        $this->_lastEditedBy = $user;
    }
    
    public function getOwner() {
        return $this->_owner;
    }
    
    public function setOwner($user) {
        $this->_owner = $user;
    }

    public function getValidUntilDate() {
        return $this->_validUntilDate;
    }

    public function setValidUntilDate($timestamp) {
        $this->_validUntilDate = $timestamp;
    }

    public function setDiscount($value) {
        $this->_discount = $value;
    }

    public function getDiscount() {
        return $this->_discount;
    }
}