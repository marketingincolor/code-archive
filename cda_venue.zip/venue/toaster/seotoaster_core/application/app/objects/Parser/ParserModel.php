<?php

/**
 * Description of ParserModel
 *
 * @author Eugene I. Nezhuta
 */
class RCMS_Object_Parser_ParserModel extends RCMS_Core_BaseModel {

	protected $_configTableName = 'config';

	protected $_pluginTableName = 'plugin';

    protected $_shoppingProductsTableName = 'shopping_products';
	   /**
     * @method Select all data from config table
     * @return array
     */
    public function selectAllConfigData() {
        $select = $this->getAdapter()->select()->from($this->_configTableName);
        return $this->_adapter->fetchPairs($select);
    }

	public function selectPluginCache($pluginName)
	{
		$select = $this->getAdapter()->select()->from($this->_pluginTableName, array('cache'=>'cache'))->where('name = ?',$pluginName);
        return $this->getAdapter()->fetchOne($select);
	}

    public function selectProductIdByPageId($pageId)
    {
        $select = $this->getAdapter()->select()->from($this->_shoppingProductsTableName)->where('page_id = ?', $pageId)->limit(1);
        return $this->getAdapter()->fetchOne($select);
    }
}
