<?php

/**
 * Description of PluginManagerObjModel
 *
 * @author iamne
 */
class RCMS_Object_PluginManager_PluginManagerObjModel extends RCMS_Core_BaseModel {
	
	protected $_tableName = 'plugin';

	public function selectEnabledPlugins() {
		$select = $this->getAdapter()->select()
			->from(
				$this->_tableName,
				array(
					'name'
				)
			)
			->where('status=?', RCMS_Object_Plugin_Plugin::STAT_ENABLED);
		return $this->getAdapter()->fetchAll($select);
	}
}

