<?php

/**
 * Description of PluginManager
 *
 * @author iamne
 */
class RCMS_Object_PluginManager_PluginManager {

	private $_model = null;

	private $_config = null;

	public function  __construct($config) {
		$this->_model = new RCMS_Object_PluginManager_PluginManagerObjModel();
		$this->_config = $config;
	}

	public function fetchPluginsMenu() {
		$additionalMenu = array();
		$enabledPlugins = $this->_getEnabledPlugins();
		if(!empty($enabledPlugins)) {
			foreach ($enabledPlugins as $enPluginData) {
				$pluginConfig = $enPluginData['path'] . 'config/config.ini';
				if(file_exists($pluginConfig)) {
					try {
						$configIni = new Zend_Config_Ini($enPluginData['path'] . 'config/config.ini');
					}
					catch (Zend_Config_Exception $zce) {
						return $zce->getMessage();
					}
					if(isset($configIni->cpanel)) {
						$additionalMenu[$enPluginData['name']]['title'] = isset($configIni->cpanel->title) ? $configIni->cpanel->title : $enPluginData['name'];
						if(isset($configIni->cpanel->items)) {
							$additionalMenu[$enPluginData['name']]['items'] = $configIni->cpanel->items->toArray();
							foreach ($additionalMenu[$enPluginData['name']]['items'] as $key => $item) {
								$additionalMenu[$enPluginData['name']]['items'][$key] = str_replace('{$site_url}', $this->_config->website->website->url, $item);
							}
						}
					}
				}
			}
		}
		return $additionalMenu;
	}

	public function fetchPluginsRoutes() {
		$enabledPlugins = $this->_getEnabledPlugins();
		if(!empty($enabledPlugins)) {
			foreach ($enabledPlugins as  $enPluginData) {
				$pluginConfig = $enPluginData['path'] . 'config/config.ini';
				if(file_exists($pluginConfig)) {
					$configIni = new Zend_Config_Ini($enPluginData['path'] . 'config/config.ini');
					if(!isset($configIni->route)) {
						return;
					}
					$additionalRoute = $this->_getPluginRouteContent($configIni->route->toArray(), $enPluginData['name']);
					$routesPath = APPLICATION_PATH . '/configs/' . SITE_NAME . 'routesext.xml';
					if(file_exists($routesPath)) {
						$routes = new Zend_Config_Xml($routesPath);
						$routesArray = $routes->toArray();
						unset ($routes);
						if(!array_key_exists($additionalRoute['name'], $routesArray['routes'])) {
							$routesArray['routes'][$additionalRoute['name']] = $additionalRoute['data'];
							$writer = new Zend_Config_Writer_Xml();
							$writer->setConfig(new Zend_Config($routesArray));
							$writer->write($routesPath);
						}
					}
				}
			}
		}
	}

	public function removePluginRoute($pluginName) {
		$this->_removePluginRoute($pluginName);
	}

	public function removePluginsRoutes($pluginName) {
		$enPlugins = $this->_getEnabledPlugins();
		if(!empty($enPlugins)) {
			foreach ($enPlugins as $plugin) {
				$this->_removePluginRoute($plugin['name']);
			}
		}
	}

	private function _removePluginRoute($pluginName) {
		$pluginConfigPath = RCMS_Object_QuickConfig_QuickConfig::$pluginsDir . $pluginName . '/config/config.ini';
		if(!file_exists($pluginConfigPath)) {
			return;
		}
		$pluginConfig = new Zend_Config_Ini($pluginConfigPath);
		if(!isset($pluginConfig->route)) {
			return;
		}
		$pluginRoute = $this->_getPluginRouteContent($pluginConfig->route->toArray(), $pluginName);
		$routesPath = APPLICATION_PATH . '/configs/' . SITE_NAME . 'routesext.xml';
		if(!file_exists($routesPath)) {
			return;
		}
		$routes = new Zend_Config_Xml($routesPath);
		$routesArray = $routes->toArray();
		unset ($routes);
		if(array_key_exists($pluginRoute['name'], $routesArray['routes'])) {
			unset($routesArray['routes'][$pluginRoute['name']]);
			$writer = new Zend_Config_Writer_Xml();
			$writer->setConfig(new Zend_Config($routesArray));
			$writer->write($routesPath);
		}
	}

	public function pluginStatus($pluginName) {
		$enPlugins = $this->_getEnabledPlugins();
		if(!empty($enPlugins)) {
			foreach ($enPlugins as $pluginsData) {
				if($pluginName == $pluginsData['name']) {
					return RCMS_Object_Plugin_Plugin::STAT_ENABLED;
				}
			}
		}
		return RCMS_Object_Plugin_Plugin::STAT_DISABLED;
	}

	public function getEnabledPlugins() {
		return $this->_getEnabledPlugins();
	}

	private function _getEnabledPlugins() {
		$plugins = $this->_model->selectEnabledPlugins();
		foreach($plugins as $key => $pluginData) {
			$plugins[$key]['path'] = $this->_config->website->website->path . RCMS_Object_QuickConfig_QuickConfig::$pluginsDir .$pluginData['name'] . '/';
		}
		return $plugins;
	}

	private function _getPluginRouteContent($routeData, $pluginName) {
		$name   = $routeData['name'];
		$method = $routeData['method'];
		unset ($routeData['name']);
		unset ($routeData['method']);
		$route = array(
			'name' => $name,
			'data' => $routeData
		);
		$route['data']['defaults'] = array(
			'controller' => 'backend_plugin',
			'action'     => 'fireaction',
			'name'       => $pluginName,
			'run'        => $method
		);
		return $route;
	}

}

