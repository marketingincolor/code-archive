<?php
/**
 * Description of ShippingModel
 *
 * @author Pavel Kovalyov
 */
class RCMS_Object_Shipping_ShippingModel extends RCMS_Core_BaseModel {

    public function selectShippingDataByCartId($cartId) {
        $select = $this->getAdapter()->select()
                ->from('shopping_shipping',
                        array(
                            'shipping_cost',
                            'shipping_type',
                            'shipping_address'
                        ))
                ->where('cart_id=?',$cartId);
        return $this->getAdapter()->fetchRow($select);
    }

    public function insertShippingData(RCMS_Object_Shipping_Shipping $shippingData) {
        $data = array(
            'cart_id'           => $shippingData->getCartId(),
            'shipping_cost'     => $shippingData->getShippingCost(),
            'shipping_type'     => $shippingData->getShippingType(),
            'shipping_address'  => serialize($shippingData->getShippingAddress())
        );
                    
        return $this->getAdapter()->insert('shopping_shipping', $data);
    }

    public function updateShippingData(RCMS_Object_Shipping_Shipping $shippingData) {
        $data = array(
            'shipping_cost'     => $shippingData->getShippingCost(),
            'shipping_type'     => $shippingData->getShippingType(),
            'shipping_address'  => serialize($shippingData->getShippingAddress())
        );
        $where = $this->getAdapter()->quoteInto('cart_id = ?', $shippingData->getCartId());
        return $this->getAdapter()->update('shopping_shipping', $data, $where);
    }

    public function deleteShippingData($cartId) {
        return $this->getAdapter()->delete('shopping_shipping', 'cart_id = '. $cartId);
    }
}
