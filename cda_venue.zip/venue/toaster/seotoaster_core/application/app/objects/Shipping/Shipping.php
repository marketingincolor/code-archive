<?php
/**
 * Shipping object stores data related to shopping user cart
 *
 * @author Pavel Kovalyov
 */
class RCMS_Object_Shipping_Shipping {

    private $_model;
    private $_session = null;

    private $_cartId;
    private $_shippingCost;
    private $_shippingType;
    private $_shippingAddress;

    public function  __construct($cartId = 0) {
        $this->_model = new RCMS_Object_Shipping_ShippingModel();

        if ($cartId) {
            $data = $this->_model->selectShippingDataByCartId($cartId);
            if (!empty($data)) {
                $this->setCartId($cartId);
                $this->_setShippingType($data['shipping_type']);
                $this->setShippingCost($data['shipping_cost']);
                $this->setShippingAddress(unserialize($data['shipping_address']));
                $this->_clear();
            } else {
                $this->setCartId($cartId);
            }
        } else {
            if (null === $this->_session) {
                $this->_session = new Zend_Session_Namespace('Shipping');
            }
            $this->_load();
        }
    }
    /**
     * Setting and saving shipping type and price
     * @param array $serviceData
     * @param string $serviceData['type'] - string with type of shipping (e.g. 'internal national')
     * @param string $serviceData['price'] - string with value of shipping price (w/o currency sign)
     */
    public function setShippingService(array $serviceData) {
        $this->_shippingType = $serviceData['type'];
        $this->_shippingCost = $serviceData['price'];
        $this->_save();
    }
    public function setCartId($id) {
        $this->_cartId = $id;
    }
    public function getCartId() {
        return $this->_cartId;
    }
    public function getShippingCost() {
        return $this->_shippingCost;
    }
    public function setShippingCost($shippingCost) {
        $this->_shippingCost = $shippingCost;
    }
    public function getShippingType() {
        return $this->_shippingType;
    }
    private function _setShippingType($shippingType) {
        $this->_shippingType = $shippingType;
    }
    public function setShippingAddress(array $address) {
        $this->_shippingAddress = $address;
        $this->_save();
    }
    public function getShippingAddress() {
        return $this->_shippingAddress;
    }
   
    private function _insert() {
        return $this->_model->insertShippingData($this);
    }
    private function _update() {
        return $this->_model->updateShippingData($this);
    }

    private function _load() {
        $this->_shippingAddress = unserialize($this->_session->shippingData);
        $this->_shippingType = $this->_session->shippingType;
        $this->_shippingCost = $this->_session->shippingCost;
    }
    private function _save() {
        $this->_session->shippingData  = serialize($this->getShippingAddress());
        $this->_session->shippingType = $this->getShippingType();
        $this->_session->shippingCost = $this->getShippingCost();
    }
    private function _clear() {
        unset($this->_session);
    }

    /**
     *  Delete shipping data
     */
    public function delete() {
        return $this->_model->deleteShippingData($this->_cartId);
    }

    /**
     * Save shipping in database
     */
    public function saveShipping() {
        if ($this->_model->selectShippingDataByCartId($this->_cartId)) {
            $this->_update();
        } else {
            $this->_insert();
        }
        $this->_clear();
    }
}
