<?php
/**
 * SEPositionModel class
 *
 * @author Pavel Kovalyov
 */
class RCMS_Object_SEPosition_SEPositionModel extends RCMS_Core_BaseModel {

    private $_tableName = "se_position";

    /**
     * Store position in DB
     * 
     */
    public function insertPosition($pageUrl, $h1Key, $googlePos, $yahooPos)
    {
        $data = array (
            'page_url'  => $pageUrl,
            'key'       => $h1Key,
            'google_pos'=> $googlePos,
            'yahoo_pos' => $yahooPos,
            'date'      => date('Y-m-d H:i:s'),
        );
        $this->_adapter->insert($this->_tableName,$data);
        return $this->_adapter->lastInsertId($this->_tableName);
    }

    /**
     * Update record in DB
     *
     */
    public function updatePosition($pageUrl, $h1Key, $googlePos, $yahooPos)
    {
        $data = array (
            'page_url'  => $pageUrl,
            'key'       => $h1Key,
            'google_pos'=> $googlePos,
            'yahoo_pos' => $yahooPos,
            'date'      => date('Y-m-d H:i:s'),
            );
        
        $where = $this->_adapter->quoteInto('page_url = ?',$pageUrl);
        return $this->_adapter->update($this->_tableName, $data, $where);
    }

    /**
     * Get stored data about page positions
     *
     * @param int $pageId
     * @return array
     */
    public function getPositions($pageUrl)
    {
        $select = $this->_adapter->select()->from($this->_tableName)
                ->where('page_url = ?', $pageUrl)
                ->order('date ASC');
        return $this->_adapter->fetchAll($select, null, Zend_Db::FETCH_ASSOC);
    }

}