<?php

/**
 * Description of ShoppingUserCartModel
 *
 * @author NE
 */
class RCMS_Object_Shopping_ShoppingUserCartModel extends RCMS_Core_BaseModel {

	public function selectShoppingUserCartById($id) {
		$select = $this->getAdapter()->select()
			->from(
				array('suc' => 'shopping_usercart'),
				array(
					'name',
					'email',
                    'company',
					'address1',
					'address2',
					'country',
					'state',
					'city',
					'zip',
					'phone',
					'comments',
					'data',
					'date'
				)
			)
			->where('id=?', $id);
		return $this->getAdapter()->fetchRow($select);
	}

	public function insertUserCart(RCMS_Object_Shopping_ShoppingUserCart $userCart) {
		$cartData = array(
			'name'     => $userCart->getName(),
			'email'    => $userCart->getEmail(),
            'company'  => $userCart->getCompany(),
			'address1' => $userCart->getAddress1(),
			'address2' => $userCart->getAddress2(),
			'country'  => $userCart->getCountry(),
			'state'    => $userCart->getState(),
			'city'     => $userCart->getCity(),
			'zip'      => $userCart->getZip(),
			'phone'    => $userCart->getPhone(),
			'comments' => $userCart->getComments(),
			'data'     => $userCart->getCartData(false)
		);
		$this->getAdapter()->insert('shopping_usercart', $cartData);
		return $this->getAdapter()->lastInsertId('shopping_usercart');
	}

	public function updateUserCart(RCMS_Object_Shopping_ShoppingUserCart $userCart) {
		$cartData = array(
			'name'  => $userCart->getName(),
			'email' => $userCart->getEmail(),
            'company' => $userCart->getCompany(),
			'address1' => $userCart->getAddress1(),
			'address2' => $userCart->getAddress2(),
			'country'  => $userCart->getCountry(),
			'state'    => $userCart->getState(),
			'city'     => $userCart->getCity(),
			'zip'      => $userCart->getZip(),
			'phone'    => $userCart->getPhone(),
			'data'  => $userCart->getCartData(false)
		);
		return $this->getAdapter()->update('shopping_usercart', $cartData, 'shopping_usercart.id = ' . $userCart->getId());
	}

	public function deleteUserCart($cartId) {
		return $this->getAdapter()->delete('shopping_usercart', 'id = ' . $cartId);
	}

}
