<?php

/**
 * Description of ShoppingUserCart
 *
 * @author NE
 */
class RCMS_Object_Shopping_ShoppingUserCart extends RCMS_Core_BaseObject {

	protected $_name     = '';

	protected $_email    = '';

    protected $_company = '';

	protected $_address1 = '';

	protected $_address2 = '';

	protected $_country  = '';

	protected $_state    = '';

	protected $_city     = '';

	protected $_zip      = '';

	protected $_phone    = '';

	protected $_comments = '';

	protected $_cartData = '';

	protected $_date     = '';

	public function  __construct($id = 0) {
		$this->_model = new RCMS_Object_Shopping_ShoppingUserCartModel();
		if($id) {
			$shoppingUserCartData = $this->_model->selectShoppingUserCartById($id);
			if(!empty ($shoppingUserCartData)) {
				$this->_id       = $id;
				$this->_name     = $shoppingUserCartData['name'];
				$this->_email    = $shoppingUserCartData['email'];
                $this->_company  = $shoppingUserCartData['company'];
				$this->_address1 = $shoppingUserCartData['address1'];
				$this->_address2 = $shoppingUserCartData['address2'];
				$this->_country  = $shoppingUserCartData['country'];
				$this->_state    = $shoppingUserCartData['state'];
				$this->_city     = $shoppingUserCartData['city'];
				$this->_zip      = $shoppingUserCartData['zip'];
				$this->_phone    = $shoppingUserCartData['phone'];
				$this->_comments = $shoppingUserCartData['comments'];
				$this->_cartData = $shoppingUserCartData['data'];
				$this->_date     = $shoppingUserCartData['date'];
			}
		}
	}

	public function getName() {
		return $this->_name;
	}

	public function setName($name) {
		$this->_name = $name;
	}

	public function getEmail() {
		return $this->_email;
	}

	public function setEmail($email) {
		$this->_email = $email;
	}

    public function getCompany() {
        return $this->_company;
    }

    public function setCompany($company) {
        $this->_company = $company;
    }

	public function getAddress1() {
		return $this->_address1;
	}

	public function setAddress1($address1) {
		$this->_address1 = $address1;
	}

	public function getAddress2() {
		return $this->_address2;
	}

	public function setAddress2($address2) {
		$this->_address2 = $address2;
	}

	public function getCountry() {
		return $this->_country;
	}

	public function setCountry($country) {
		$this->_country = $country;
	}

	public function getState() {
		return $this->_state;
	}

	public function setState($state) {
		$this->_state = $state;
	}

	public function getCity() {
		return $this->_city;
	}

	public function setCity($city) {
		$this->_city = $city;
	}

	public function getZip() {
		return $this->_zip;
	}

	public function setZip($zip) {
		$this->_zip = $zip;
	}

	public function getPhone() {
		return $this->_phone;
	}

	public function setPhone($phone) {
		$this->_phone = $phone;
	}

	public function getComments() {
		return $this->_comments;
	}

	public function setComments($comments) {
		$this->_comments = $comments;
	}

	public function getDate() {
		return $this->_date;
	}

	public function setDate($date) {
		$this->_date = $date;
	}

	public function getCartData($unserialize = true) {
		if(!$unserialize) {
			return $this->_cartData;
		}
		return unserialize($this->_cartData);
	}
	
	public function setCartData($cartData, $freebies = null) {
        $newCart = array();
		foreach ($cartData as $key => $value) {
			if(!array_key_exists('note', $value)) {
				//$cartData[$key]['note'] = '';
                $value['note'] = '';
			}
            $newCart[] = $value;
            if (!empty ( $freebies ) && isset( $freebies[$value['id']] ) ) {
                foreach ($freebies[$value['id']] as $freebie) {
                    $newCart[] = $freebie;
                }
            }
		}
		$this->_cartData = serialize($newCart);
	}

	protected function _insert() {
		return $this->_model->insertUserCart($this);
	}

	protected function _update() {
		return $this->_model->updateUserCart($this);
	}

	public function delete() {
		return $this->_model->deleteUserCart($this->_id);
	}
}
