<?php

class RCMS_Object_PayPal_PayPalModel extends RCMS_Core_BaseModel {

    private $_tableShoppingConfig = 'shopping_config';

    public function selectSettingsPayPal()
    {
        $sql = $this->getAdapter()->select()->from($this->_tableShoppingConfig, array('value'))->where("name = 'paypal'");
        return $this->getAdapter()->fetchOne($sql);
    }
}