<?php

class RCMS_Object_Product_Product  extends RCMS_Core_BaseObject {

    private $_name = '';

    private $_itemId = '';

    private $_price = 0;

    private $_weight = 0;

    private $_photo = '';

    private $_brand = '';

    private $_desc = '';

    private $_pageId = 0;

    private $_options = '';

    private $_related = '';

    private $_freebies = '';

    private $_tax = '';

	private $_saleDue = null;

	private $_oldPrice = '';

    private $_rating = 0;

    private $_totalVotes = 0;

    public function  __construct($id = null)
    {
        $this->_model = new RCMS_Object_Product_ProductModel();
        if ($id !== null) {
            $this->_init(intval($id));
        }
    }

    private function _init($id)
    {
        $data = $this->_model->selectProductById($id);
        if (is_array($data) && count($data) > 0) {
            $this->setId($id);
            $this->setName($data['name']);
            $this->setItemId($data['item_id']);
            $this->setPrice($data['price']);
            $this->setWeight($data['weight']);
            $this->setPhoto($data['photo']);
            $this->setBrand($data['brand']);
            $this->setDescription($data['desc']);
            $this->setOptions($data['options']);
            $this->setRelated($data['related']);
            $this->setFreebies($data['freebies']);
            $this->setPageId($data['page_id']);
            $this->setTax($data['tax']);
            if ($data['rating']){
                $rating = explode('|', $data['rating']);
                $this->_setRating($rating[0]);
                $this->_setTotalVotes($rating[1]);
            }
			//this is the write way to init properties inside the object!
			$this->_saleDue = $data['sale_due'];
			$this->_oldPrice = $data['old_price'];
			if($this->_oldPrice) {
				$this->_onSaleFinished();
			}
        }
    }

	/**
	 * Check if on sale period is finished then put back an old price
	 *
	 */
	private function _onSaleFinished() {
		if(!$this->_oldPrice || !$this->_saleDue) {
			return;
		}
		date_default_timezone_set('UTC');
		$currTime = mktime(0, 0, 0, date('m'), date('d'), date('Y'));
		$explodedSaleDue = explode('-', $this->_saleDue);
		$saleDue = mktime(0, 0, 0, $explodedSaleDue[1], $explodedSaleDue[2], $explodedSaleDue[0]);
		if(($saleDue - $currTime) < 0) {
			$this->_price = $this->_oldPrice;
			$this->_oldPrice = null;
			$this->_saleDue = null;
			$this->save();
		}
		
	}

	public function getSaleDue() {
		return $this->_saleDue;
	}

	public function setSaleDue($saleDue) {
		$this->_saleDue = ($saleDue) ? $saleDue : null;
	}

	public function getOldPrice() {
		return $this->_oldPrice;
	}

	public function setOldPrice($oldPrice) {
		$this->_oldPrice = $oldPrice;
	}


    public function setName($name)
    {
        $this->_name = $name;
    }

    public function getName()
    {
        return  $this->_name;
    }

    public function setItemId($itemId)
    {
        $this->_itemId = $itemId;
    }

    public function getItemId()
    {
        return $this->_itemId;
    }

    public function setPrice($price)
    {
        $this->_price = $price;
    }

    public function getPrice()
    {
        return $this->_price;
    }

    public function setWeight($weight)
    {
        $this->_weight = $weight;
    }

    public function getWeight()
    {
        return $this->_weight;
    }

    public function setPhoto($photo)
    {
        $this->_photo = $photo;
    }

    public function getPhoto()
    {
        return $this->_photo;
    }

    public function getBrand()
    {
        return $this->_brand;
    }

    public function setBrand($brand)
    {
        $this->_brand = $brand;
    }

    public function setRelated($related)
    {
        $this->_related = $related;
    }

    public function getRelated()
    {
        return $this->_related;
    }

    public function getPageId()
    {
        return $this->_pageId;
    }

    public function setPageId($pageId)
    {
        $this->_pageId = (int) $pageId;
    }

    public function getOptions()
    {
        return $this->_options;
    }

    public function setOptions($options)
    {
        $this->_options = $options;
    }

    public function getDescription()
    {
        return $this->_desc;
    }

    public function setDescription($desc)
    {
        $this->_desc = $desc;
    }

    public function getTax()
    {
        return $this->_tax;
    }

    public function setTax($tax)
    {
        $this->_tax = $tax;
    }

    public function getGroups()
    {
        if ($this->_id) {
            return $this->_model->selectGroupsForProduct($this->_id);
        }
    }

    public function setGroups($groups)
    {
        if ($this->_id && is_array($groups) && count($groups) > 0) {
            $this->_model->deleteGroupForProduct($this->_id);
            foreach ($groups as $idGroup) {
                $this->_model->insertGroupForProduct($this->_id, $idGroup);
            }
        }
    }

    private function _setRating($rating){
        $this->_rating = $rating;
    }

    public function getRating(){
        return $this->_rating;
    }

    public function getRatingFormatted(){
        if ($this->_rating && $this->_totalVotes) {
            return round($this->_rating / $this->_totalVotes, 1);
        }
        return 0;
    }

    public function getTotalVotes(){
        return $this->_totalVotes;
    }

    private function _setTotalVotes($votes){
        $this->_totalVotes = $votes;
    }

    public function saveRating($rating){
        $this->_rating += $rating;
        $this->_totalVotes++;
        return $this->_model->updateRating($this);
    }

    public function setFreebies($value) {
        $this->_freebies = $value;
    }

    public function getFreebies() {
        return $this->_freebies;
    }

    protected function _insert()
    {
        return $this->_model->insertProduct($this);
    }

    protected function _update()
    {
        return $this->_model->updateProduct($this);
    }

    public function delete()
    {
        $flagDelete = $this->_model->deleteProduct($this->_id);
        if ($flagDelete) {
            $this->_model->deleteGroupForProduct($this->_id);
        }
        return $flagDelete;
    }
}
