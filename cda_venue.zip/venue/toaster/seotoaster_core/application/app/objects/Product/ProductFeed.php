<?php
/**
 * Description of ProductFeed
 * Generates XML file with all products according to Google Product Feed specification
 *
 * @author Pavel Kovalyov
 */
class RCMS_Object_Product_ProductFeed
{
    /**
     * Path to view with xml template
     */
    const VIEW_PATH = '/views/scripts/backend/shopping';

    private $_model;
    private $_sitePath;
    private $_siteUrl;
    private $_view;

    public function  __construct() {
        $this->_model       = new RCMS_Object_Product_ProductModel();
        $this->_sitePath    = unserialize(Zend_Registry::get('config'))->website->website->path;
        $this->_siteUrl     = unserialize(Zend_Registry::get('config'))->website->website->url;
        $this->_view        = new Zend_View();
        //$this->_view->setScriptPath($this->_sitePath . self::VIEW_PATH);
        $this->_view->setScriptPath(APPLICATION_PATH . self::VIEW_PATH);
        $this->_view->websiteUrl = $this->_siteUrl;

    }

    /**
     * Method generates product.xml file with all products you have
     * @return nothing
     */
    public function generateFullProductXML()
    {
        $products = $this->_model->selectAllProducts();
        foreach ($products as $product) {
            $link = '';
            $page = new RCMS_Object_Page_Page($product['page_id']);
            if ($page->getId() > 0 && $page->getUrl() != '') {
                $link = $this->_siteUrl.trim($page->getUrl()).'.html';
            }
            unset ($page);
            
            $data[] = array(
            'title'         => $product['name'],
            'link'          => $link,
            'description'   => htmlspecialchars($product['desc']),
            'id'            => $product['id'],
            'price'         => $product['price'],
            'condition'     => 'new',
            'brand'         => $product['brand'],
            'image_link'    => $this->_siteUrl . $product['photo'],
            );
        }

        
        $this->_view->products = $data;
        
        $indexPage = new RCMS_Object_Page_PageModel();
        $select = $indexPage->getAdapter()->select()
                    ->from('page',array ('meta_description','header_title'))
                    ->where("url = 'index'");
        $header = $indexPage->getAdapter()->fetchRow($select);
        unset ($indexPage);
        
        $this->_view->description = htmlspecialchars($header['meta_description']);
        $this->_view->title       = htmlspecialchars($header['header_title']);

        $file = $this->_view->render('productsxml.phtml');
        RCMS_Tools_FilesystemTools::saveFile('products.xml', $file);    
    }
}