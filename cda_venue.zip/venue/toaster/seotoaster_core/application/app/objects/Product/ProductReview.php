<?php
/**
 * Review system for product
 *
 * @author Pavel Kovalyov
 */
class RCMS_Object_Product_ProductReview extends RCMS_Core_BaseObject {

    private $_content;
    private $_productId;
	private $_date;
	private $_userId;
	private $_userEmail;
	private $_abuse;
	private $_userName;
	private $_userWebsite;
	private $_publish;
	private $_rank;
    private $_topic;
	private $_notify;

    public function  __construct($id = null) {
        $this->_model = new RCMS_Object_Product_ProductReviewModel();
        if (intval($id)){
            $review = $this->_model->selectReviewById($id);
            if ($review){
                $this->setId($review->id);
                $this->setContent($review->content);
                $this->setProductId($review->product_id);
                $this->setDate($review->date);
                $this->setUserId($review->user_id);
                $this->setUserName($review->user_name);
                $this->setUserEmail($review->user_email);
                $this->setUserWebsite($review->user_website);
                $this->setAbuse($review->abuse);
                $this->setPublish($review->publish);
                $this->setRank($review->rank);
                $this->setTopic($review->topic);
                $this->setNotify($review->notify);
            }
        }
    }

    public function setContent($value) {
        $this->_content = $value;
    }
    public function getContent() {
        return $this->_content;
    }

    public function setProductId($value) {
        $this->_productId = $value;
    }
    public function getProductId() {
        return $this->_productId;
    }

    public function setDate($value) {
        $this->_date = $value;
    }
    public function getDate() {
        return $this->_date;
    }

    public function setUserId($value) {
        $this->_userId = $value;
    }
    public function getUserId() {
        return $this->_userId;
    }

    public function setUserEmail($value) {
        $this->_userEmail = $value;
    }
    public function getUserEmail() {
        return $this->_userEmail;
    }

    public function setUserName($value) {
        $this->_userName = $value;
    }
    public function getUserName() {
        return $this->_userName;
    }

    public function setUserWebsite($value) {
        $this->_userWebsite = $value;
    }
    public function getUserWebsite() {
        return $this->_userWebsite;
    }

    public function setPublish($value) {
        $this->_publish = $value;
    }
    public function getPublish() {
        return $this->_publish;
    }

    public function setRank($value) {
        $this->_rank = $value;
    }
    public function getRank() {
        return $this->_rank;
    }

    public function setAbuse($value) {
        $this->_abuse = $value;
    }
    public function getAbuse() {
        return $this->_abuse;
    }

    public function setTopic($value) {
        $this->_topic = $value;
    }
    public function getTopic() {
        return $this->_topic;
    }

    public function setNotify($value) {
        $this->_notify = $value;
    }
    public function getNotify() {
        return $this->_notify;
    }

    public function  delete() {
        return $this->_model->deleteReview($this->getId());
    }

    protected function  _insert() {
        $id = (int)$this->_model->insertReview($this);
        if ($id) {
            $this->setId($id);
            return $id;
        }
    }
    
    protected function  _update() {
        return $this->_model->updateReview($this);
    }
}
