<?php
/**
 * Model for RCMS_Object_Product_ProductReview
 * @author Pavel Kovalyov
 */
class RCMS_Object_Product_ProductReviewModel extends RCMS_Core_BaseModel{
    private $_tableName = 'shopping_products_review';

    public function selectReviewById($id){
        $where  = $this->_adapter->quoteInto('id = ?', $id);
        $select = $this->_adapter->select()->from($this->_tableName)->where($where);
        return $this->_adapter->fetchRow($select, null, Zend_Db::FETCH_OBJ);
    }

    public function insertReview(RCMS_Object_Product_ProductReview $review){
        $data = array(
            'content'  => $review->getContent(),
            'product_id'   => $review->getProductId(),
            'date'  => $review->getDate(),
            'user_id'   => $review->getUserId(),
            'user_email' => $review->getUserEmail(),
            'abuse'   => $review->getAbuse(),
            'user_name' => $review->getUserName(),
            'user_website' => $review->getUserWebsite(),
            'publish' => $review->getPublish(),
            'rank' => $review->getRank(),
            'topic' => $review->getTopic(),
            'notify' => $review->getNotify()
        );

        $flag = $this->_adapter->insert($this->_tableName, $data);
        if($flag > 0)
        {
            return $this->_adapter->lastInsertId($this->_tableName);
        }
    }

    public function updateReview(RCMS_Object_Product_ProductReview $review){
        $data = array(
            'content' => $review->getContent(),
            'product_id' => $review->getProductId(),
            'date'  => $review->getDate(),
            'user_id'   => $review->getUserId(),
            'user_email' => $review->getUserEmail(),
            'abuse'   => $review->getAbuse(),
            'user_name' => $review->getUserName(),
            'user_website' => $review->getUserWebsite(),
            'publish' => $review->getPublish(),
            'rank' => $review->getRank(),
            'topic' => $review->getTopic(),
            'notify' => $review->getNotify()
        );

        $where = $this->_adapter->quoteInto(' id = ? ', $review->getId());
        return $this->_adapter->update($this->_tableName, $data, $where);
    }

    public function deleteReview($id){
        $where = $this->_adapter->quoteInto('id = ?', $id);
        return $this->_adapter->delete($this->_tableName, $where);
    }
}