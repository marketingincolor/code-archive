<?php

/**
 * Description of Mailer
 *
 * @author NE
 */
class RCMS_Object_Mailer_Mailer {

	const MAIL_TYPE_SMTP = 'smtp';

	const MAIL_TYPE_MAIL = 'mail';

	private $_body = '';

	private $_fromMail = '';

	private $_toMail = '';

	private $_from = '';

	private $_to = '';

	private $_subject = '';

	private $_encoding = 'utf-8';

	private $_transport = null;

	private $_smtpConfig = array(
		'auth'		=> 'login',
		'username'  => '',
		'password'  => '',
		'host'      => ''
	);

	private $_useSmpt = false;

    private $_attachment = null;
    
	public function  __construct() {
		
	}

	public function send() {
		/*if(!$this->_useSmpt) {
			ini_set('sendmail_from', $this->_fromMail);
		}*/
		if(null === $this->_transport) {
			$this->_transport = new Zend_Mail_Transport_Sendmail();
		}
		Zend_Mail::setDefaultTransport($this->_transport);
		$mailer = new Zend_Mail($this->_encoding);
		$mailer->addTo($this->_toMail, $this->_to);
		$mailer->setFrom($this->_fromMail, $this->_from);
		$mailer->setSubject($this->_subject);
		$mailer->setBodyHtml($this->_body);
        if(null !== $this->_attachment){
            $mailer->createAttachment($this->_attachment);
        }
		//$mailer->setBodyText($this->_body);
		try {
			$mailer->send();
			return true;
		} catch (Zend_Mail_Transport_Exception $e) {
			//return	$e->getMessage();
			return false;
		}
	}

	public function setSmtpConfig($userName, $password, $host) {
		$this->_smtpConfig = array(
			'auth'     => 'login',
			'username' => $userName,
			'password' => $password,
			'host'     => $host
		);
	}

	public function setSubject($subject) {
		$this->_subject = $subject;
	}

	public function setTransport($transportType) {
		switch ($transportType) {
			case self::MAIL_TYPE_SMTP:
				$this->_transport = new Zend_Mail_Transport_Smtp($this->_smtpConfig['host'], $this->_smtpConfig);
				$this->_useSmpt = true;
			break;
			case self::MAIL_TYPE_MAIL:
			default:
				$this->_transport = new Zend_Mail_Transport_Sendmail();
				$this->_useSmpt = false;
			break;
		}
	}

	public function getBody() {
		return $this->_body;
	}

	public function setBody($body) {
		$this->_body = $body;
	}

	public function getFromMail() {
		return $this->_fromMail;
	}

	public function setFromMail($fromMail) {
		$this->_fromMail = $fromMail;
	}

	public function getToMail() {
		return $this->_toMail;
	}

	public function setToMail($toMail) {
		$this->_toMail = $toMail;
	}

	public function getFrom() {
		return $this->_from;
	}

	public function setFrom($from) {
		$this->_from = $from;
	}

	public function getTo() {
		return $this->_to;
	}

	public function setTo($to) {
		$this->_to = $to;
	}

    public function createAttachment($attachment) {
        $this->_attachment = $attachment;
    }
}

