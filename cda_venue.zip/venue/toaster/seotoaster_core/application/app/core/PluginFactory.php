<?php

/**
 * Description of PlaginFactory
 *
 * @author iamne
 */
class RCMS_Core_PluginFactory {

	private function __construct() {}

	public static function createPlugin($pluginName, $options = array(), $data = array()) {
		$pluginName = strtolower($pluginName);
		$pluginNameClassName = ucfirst($pluginName);
		self::_validatePlugin($pluginName);
		return new $pluginNameClassName($options, $data);
	}

	private static function _validatePlugin($pluginName) {
		$pluginDir = RCMS_Object_QuickConfig_QuickConfig::$pluginsDir . $pluginName;
		if(!is_dir($pluginDir)) {
			throw new Exception('Directory for plugin ' . $pluginName . ' is missing');
		}
		$pluginFile = $pluginDir . '/' .ucfirst($pluginName) . '.php';
		if(!file_exists($pluginFile)) {
			throw new Exception('Plugin ' . $pluginName . ' is missing');
		}
		require_once $pluginFile;
	}

}

