<?php

/**
 * BaseController is the wrapper for Zend_Controller_Action
 *
 * We use it to extends Zend_Controller_Action with new methods that we may need
 *
 * @author eugene
 */
abstract class RCMS_Core_BaseController extends Zend_Controller_Action
{
    /**
     * Model for current controller
	 * 
     * @var Model object
     */
    protected $_model = null;

	/**
	 * Session accessor
	 *
	 * @var Zend_Session_Namespace
	 */
    protected $_session = null;

	/**
	 * Registry accessor
	 *
	 * @var Zend_Registry
	 */
    protected $_config;

	/**
	 * Url of current website
	 *
	 * @var string
	 */
    protected $_websiteUrl = '';

	/**
	 * Translator
	 *
	 * @var RCMS_Object_Parser_LanguageParser
	 */
	protected $_translator = null;

	/**
	 * Cache object
	 *
	 * @var Zend_Cache
	 */
	protected $_cache = null;

    /**
     * Init method.
	 * 
     * @return void
     */
    public function init() {
		$this->getResponse()->setHeader('Content-Type', 'text/html')->sendHeaders('charset','UTF-8');

		$this->_config          = unserialize(Zend_Registry::get('config'));
		$this->_session         = new Zend_Session_Namespace($this->_config->website->website->url);
		$this->_translator      = new RCMS_Object_Parser_LanguageParser($this->_session->langId);

		if ($this->_session->isLogged || $this->_session->memberLogged) {
            if($this->_session->currentUser !== null) {
                $this->view->currentUser = unserialize($this->_session->currentUser);
            }
        }
		else {
            $this->_session->isLogged     = false;
			$this->_session->memberLogged = false;
        }
		$this->view->isLogged     = $this->_session->isLogged;
		$this->view->memberLogged = $this->_session->memberLogged;
        $this->view->config       = $this->_config;
		$this->view->websiteUrl   = $this->getWebSiteUrl();
		
    }

	public function  preDispatch() {
		parent::preDispatch();
		$this->_initCache();
		if($this->_session->isLogged) {
			$this->_cache->clean(Zend_Cache::CLEANING_MODE_ALL);
		}
	}

	public function  postDispatch() {
		parent::postDispatch();
		$pluginManager = new RCMS_Object_PluginManager_PluginManager($this->_config);
		$this->view->additionalMenu = $pluginManager->fetchPluginsMenu();
		$pluginManager->fetchPluginsRoutes();
	}

	/**
	 * Initialization of cache system
	 * 
	 */
	protected function _initCache() {
		$frontendOptions = array(
			'lifetime'                  => 7200, // cache lifetime of 2 hours
			'cache_id_prefix'           => 'page_',
			'automatic_serialization'   => true,
			'ignore_user_abort'         => true
		);
		$backendOptions = array(
			'cache_dir'              => 'tmp/cache/',
		);
		$this->_cache = Zend_Cache::factory('Core', 'File', $frontendOptions, $backendOptions);
	}

    /**
     * This function checks login of user.
	 * 
     * @return void
     */
    protected function _checkLogin($allowedActions = array()) {
        if (!$this->_session->isLogged && !$this->_session->memberLogged) {
			if(!empty ($allowedActions)) {
				$params = $this->getRequest()->getParams();
				if (!in_array($params['action'], $allowedActions)) {
					$this->_loginRedirect();
				}
			}
			else {
				$this->_loginRedirect();
			}
        }
    }

	protected function _loginRedirect() {
		echo "<script type=\"text/javascript\">
					var tmpredirect = '".$this->view->websiteUrl."sys/login/index/';
					if(parent) {
						parent.tb_remove();
						parent.window.location = tmpredirect;
					}
					window.location = tmpredirect;
				 </script>";
       die();
	}

    /**
     * This function returns url of website.
	 * 
     * @return string
     */
    public function getWebSiteUrl() {
       return $this->_config->website->website->url;
    }

}
