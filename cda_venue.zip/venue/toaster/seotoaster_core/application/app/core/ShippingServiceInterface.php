<?php
/**
 * Interface for Shipping Services Plugins
 * put it seotoaster_core/application/app/objects/Shipping/Services
 */
interface RCMS_Core_ShippingServiceInterface
{
    /**
     * Setting origination address from array
     */
    public function setOrigination(array $address);
    /**
     * Setting destination address from array
     */
    public function setDestination(array $address);
    /**
     * Setting weight and units
     */
    public function setWeight($weight, $unit = '');
    /**
     * Main method to interact with shipper API server and return a result
     */
    public function run();
    /**
     * Returns html form for 'Shipping configuration' screen
     */
    public function getConfigScreen();
}
?>