<?php
interface RCMS_Core_PluginInterface
{
    public function run($requestParams = array());
}

