<?php

/**
 * Description of BaseForm
 *
 * @author NE
 */
class RCMS_Core_BaseForm extends Zend_Form {

	protected $_config = null;

	public function init() {
		parent::init();
		$this->_config = unserialize(Zend_Registry::get('config'));
	}


	public $elementPrefixPaths = array('filter' => array(
        'prefix' => 'RCMS_Filters',
        'path'   =>  '../application/app/filters'
    ));

    
    public $elementFilters = array(
        'STFilterStripslashes'
    );

}
