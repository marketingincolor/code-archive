<?php

/**
 * BaseModel is the wrapper for Zend_Db_Table_Abstract
 *
 * We use it to extends Zend_Db_Table_Abstract with new methods that we may need
 *
 * @author eugene
 */
abstract class RCMS_Core_BaseModel extends Zend_Db_Table_Abstract {

    /**
     * Adapter to the database
     * @var Adapter
     */
    protected $_adapter = null;

    /**
     * Init method for model
     */
    public function init()
    {
        parent::init();
        $this->_adapter = $this->getAdapter();
    }
}
