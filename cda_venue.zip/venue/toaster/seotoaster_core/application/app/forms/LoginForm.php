<?php

/**
 * LoginForm for user login page
 * @author eugene
 */
class RCMS_Form_LoginForm extends Zend_Form
{
    /**
     * Form initialization
     * @see Zend_Form#init()
     */
    public function init()
    {
        parent::init();
        $this->setMethod('post');
        $this->setName('loginForm');

        $this->addElement('text', 'login', array(
                'id'        =>  'yourlogin',
                'required'  =>  'true',
                )
        );

        $this->addElement('password', 'password', array(
                'id'        =>  'yourpassword',
                'required'  =>  'true',
                )
        );

        $this->addElement('submit', 'submit', array(
                'ignore'    =>  'true',
                'id'        =>  'loginboxsubmit',
                'class'     =>  'formsubmit',
                'label'     =>  'Let me in'
                )
        );

        $this->_removeDecoratorErrors();
        $this->setElementDecorators(array('ViewHelper', ));
    }

    /**
     * This function deletes Zend decorators.
     * @return <void>
     */
    private function _removeDecoratorErrors()
    {
        $this->getElement('login')->removeDecorator('Errors');
        $this->getElement('password')->removeDecorator('Errors');
    }
}
