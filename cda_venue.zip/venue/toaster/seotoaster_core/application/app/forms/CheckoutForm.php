<?php

/**
 * Redirect form for manage 301 redirects screen.
 * @author Pavel Savchuk
 */
class RCMS_Form_CheckoutForm extends RCMS_Core_BaseForm
{
    /**
     * Form initialization
     * @see Zend_Form#init()
     */
    public function init()
    {
        $this->setMethod('POST');
        $this->setName('configForm');
        $this->elementPrefixPaths['filter']['path'] = realpath(dirname(__FILE__).'/../filters/');

        $this->addElement('text', 'name', array(
           'id'         =>  'name',
           'validators' =>  array(array('regex', false, array('/^[a-zA-Zа-яА-Я0-9-\s\.\:]+$/'))),
           'filters'    =>  array( new Zend_Filter_StringTrim(), new Zend_Filter_StripTags()),
		   'prefixPath' => $this->elementPrefixPaths,
		   'filters'    => $this->elementFilters,
		   'required'      =>  'true'
            )
        );

	$this->addElement('text', 'email', array(
			'id'         =>  'email',
			'validators'    =>  array(array('regex', false, array('/^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})$/'))),
			'required'      =>  'true',
			'filters'    =>  array( new Zend_Filter_StringTrim(), new Zend_Filter_StripTags()),
            )
        );


		$this->addElement('text', 'address1', array(
           'id'         =>  'address1',
		   'style' => 'width:300px;',
           /*'validators' =>  array(array('regex', false, array('/^[a-zA-Zа-яА-Я0-9-\s\.\:]+$/'))),*/
           'filters'    =>  array( new Zend_Filter_StringTrim(), new Zend_Filter_StripTags()),
		   'prefixPath' => $this->elementPrefixPaths,
		   'filters'    => $this->elementFilters
            )
        );

		$this->addElement('text', 'address2', array(
           'id'         =>  'address2',
		   'style' => 'width:300px;',
          /* 'validators' =>  array(array('regex', false, array('/^[a-zA-Zа-яА-Я0-9-\s\.\:]+$/'))),*/
           'filters'    =>  array( new Zend_Filter_StringTrim(), new Zend_Filter_StripTags()),
		   'prefixPath' => $this->elementPrefixPaths,
		   'filters'    => $this->elementFilters
            )
        );


		$this->addElement('text', 'city', array(
			'id'         =>  'city',
			'validators'    =>  array(array('regex', false, array('/^[^\d]+$/'))),
			'filters'    =>  array( new Zend_Filter_StringTrim(), new Zend_Filter_StripTags()),
            )
        );

		$this->addElement('text', 'state', array(
			'id'         =>  'state',
			'validators'    =>  array(array('regex', false, array('/^[^\d]+$/'))),
			/*'validators'    =>  array(array('regex', false, array('/^[a-zA-Zа-яА-Я0-9-\s\.\:]+$/'))),*/
			'filters'    =>  array( new Zend_Filter_StringTrim(), new Zend_Filter_StripTags()),
            )
        );

		$this->addElement('text', 'zip', array(
			'id'         =>  'zip',
			'validators'    =>  array(array('regex', false, array('/^[0-9]+$/'))),
			'filters'    =>  array( new Zend_Filter_StringTrim(), new Zend_Filter_StripTags()),
            )
        );

	    $this->addElement('text', 'country', array(
			'id'         =>  'country',
			'validators'    =>  array(array('regex', false, array('/^[^\d]+$/'))),
			'filters'    =>  array( new Zend_Filter_StringTrim(), new Zend_Filter_StripTags()),
            )
        );

	    $this->addElement('text', 'phone', array(
			'id'         =>  'phone',
			'validators'    =>  array(array('regex', false, array('/^[0-9-\s\.\:\+]+$/'))),
			'filters'    =>  array( new Zend_Filter_StringTrim(), new Zend_Filter_StripTags()),
            )
        );

		$this->addElement('textarea', 'comments', array(
			'id'         =>  'comments',
			'validators'    =>  array(array('regex', false, array('/^[a-zA-Zа-яА-Я0-9-\s\.\:]+$/'))),
			'filters'    =>  array( new Zend_Filter_StringTrim(), new Zend_Filter_StripTags()),
            )
        );

	  $this->addElement('submit', 'submit', array(
		   'id'=> 'submit',
		   'class' => 'formsubmit',
           'label'=>'{%QOUTE ME%}'
            )
        );

        $this->addElement('hidden', 'website_url', array('value'=>unserialize(Zend_Registry::get('config'))->website->website->url));
        $this->_removeDecoratorErrors();
        $this->setElementDecorators(array('ViewHelper', ));
    }

    /**
     * This function deletes Zend decorators.
     * @return <void>
     */
    private function _removeDecoratorErrors(){
        $this->getElement('name')->removeDecorator('Errors');
		$this->getElement('email')->removeDecorator('Errors');
        $this->getElement('address1')->removeDecorator('Errors');
		$this->getElement('address2')->removeDecorator('Errors');
		$this->getElement('city')->removeDecorator('Errors');
		$this->getElement('zip')->removeDecorator('Errors');
		$this->getElement('state')->removeDecorator('Errors');
		$this->getElement('country')->removeDecorator('Errors');
		$this->getElement('phone')->removeDecorator('Errors');
		$this->getElement('comments')->removeDecorator('Errors');
    }
}
