<?php

/**
* TextcontainerForm class.
* @author Eugene I. Nehzuta
*/
class RCMS_Form_TextcontainerForm extends RCMS_Core_BaseForm {

    /**
     * Form initialization
     * @see Zend_Form#init()
     */
    public function init()
    {
        $this->setMethod('post');
        $this->setName('containerTextForm');
        $this->elementPrefixPaths['filter']['path'] = realpath(dirname(__FILE__).'/../filters/');

        $this->addElement('checkbox', 'publish_content', array (
            'id'        =>  'publish_content',
            'attribs'   =>  array('checked' => 'checked')
            )
        );

        $this->addElement('checkbox', 'publish_on_date', array (
            'id'    =>  'publish_on_date'
            )
        );

        $this->addElement('text', 'datepicker', array(
            'value' =>  '',
            'id'    =>  'datepicker'
            )
        );

        $this->addElement('textarea', 'admincontentarea', array(
            'class'      => 'tinymce',
            'style'    => 'width:100%;height:100%;',
			'prefixPath' => $this->elementPrefixPaths,
			'filters'    => $this->elementFilters
        ));

        $this->addElement('submit', 'submit', array(
            'id'        =>  'edittextsubmit',
            'class'     =>  'formsubmit',
            'ignore'    =>  'true',
            'label'	=>  '{%Done%}'
            )
        );

        $this->addElement('hidden', 'featuredareas', array());
		$this->addElement('hidden', 'ctype', array());
        $this->addElement('hidden', 'blog', array());
        $this->addElement('hidden', 'website_url', array('value'=>unserialize(Zend_Registry::get('config'))->website->website->url));
        $this->addElement('hidden', 'pageId', array('value'=>unserialize(Zend_Registry::get('config'))->website->website->url));
        $this->setElementDecorators(array('ViewHelper',	'Errors'));
    }

}
