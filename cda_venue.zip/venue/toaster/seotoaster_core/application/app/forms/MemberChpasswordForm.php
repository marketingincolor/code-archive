<?php

/**
 * MemberChpasswordForm provides form to change password
 *
 * @author iamne
 */
class RCMS_Form_MemberChpasswordForm extends RCMS_Core_BaseForm {

	public function init() {
		parent::init();
		$this->setName('memberchPass');
		$this->setAction('javascript:;')->setMethod('post');
		$this->setAttrib('id', 'membership_chpass');
		$this->elementPrefixPaths['filter']['path'] = realpath(dirname(__FILE__).'/../filters/');

		//old password field
		$this->addElement('password', 'oldPass', array(
			'id'         => 'old_pass',
			'filters'    => array(new Zend_Filter_StringTrim(), new Zend_Filter_StripTags()),
			'required'   =>  'true',
			'prefixPath' => $this->elementPrefixPaths,
			'filters'    => $this->elementFilters,
			'label'      => '{%Old password%}'
		));

		//new password
		$this->addElement('password', 'newPass', array(
			'id'         => 'new_pass',
			'filters'    => array(new Zend_Filter_StringTrim(), new Zend_Filter_StripTags()),
			'required'   =>  'true',
			'prefixPath' => $this->elementPrefixPaths,
			'filters'    => $this->elementFilters,
			'label'      => '{%New password%}'
		));

		//new password confirm
		$this->addElement('password', 'newPassAgain', array(
			'id'         => 'new_pass_again',
			'filters'    => array(new Zend_Filter_StringTrim(), new Zend_Filter_StripTags()),
			'required'   =>  'true',
			'prefixPath' => $this->elementPrefixPaths,
			'filters'    => $this->elementFilters,
			'label'      => '{%New password again%}'
		));

		//submit button
		$this->addElement('submit', 'btnChPass', array(
			'id'    => 'btn_chpass',
			'class' => 'formsubmit',
			'label' => '{%UPDATE%}'
		));

		//website url hidden field
		$this->addElement('hidden', 'websiteUrl', array(
			'id'    => 'website_url',
			'value' => $this->_config->website->website->url
		));
	}
}

