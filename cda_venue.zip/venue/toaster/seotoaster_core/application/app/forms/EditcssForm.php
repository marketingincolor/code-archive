<?php

/**
 * EditcssForm class.
 *
 * @author Eugene I. Nehzuta
 */
class RCMS_Form_EditcssForm extends RCMS_Core_BaseForm {

    /**
     * Form initialization
     * @see Zend_Form#init()
     */
    public function init()
    {
        $this->setMethod('post');
        $this->setName('editCssForm');
        $this->elementPrefixPaths['filter']['path'] = realpath(dirname(__FILE__).'/../filters/');

        $this->addElement('textarea', 'content', array(
            'id'        =>  'csscode',
//            'required'  =>  true,
            'attribs'   =>  array('rows' => '20', 'cols' => '60'),
			'prefixPath' => $this->elementPrefixPaths,
			'filters'    => $this->elementFilters
        ));

        $this->addElement('select', 'selectcss', array (
            'id'    =>  'selectcss'
        ));

        $this->addElement('submit', 'submit', array(
            'class'     =>  'formsubmit',
            'id'        =>  'editcsssubmit',
            'ignore'	=>  'true',
            'label'     =>  '{%Done%}'
                )
        );
    }
}
