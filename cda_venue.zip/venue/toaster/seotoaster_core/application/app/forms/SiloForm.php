<?php

/**
 * Description of SiloForm
 * @author NE
 */
class RCMS_Form_SiloForm extends RCMS_Core_BaseForm {

    /**
     * Form initialization
     * @see Zend_Form#init()
     */
    public function init()
    {
        $this->setMethod('post');
        $this->setName('siloForm');
        $this->elementPrefixPaths['filter']['path'] = realpath(dirname(__FILE__).'/../filters/');

        $this->addElement('text', 'siloName', array(
            'id'            =>  'silo-name',
            'validators'    =>  array (array('stringLength', false, array(3, 255)), new Zend_Validate_Alnum(true)),
            'filters'       =>  array ( new Zend_Filter_StringTrim(), new Zend_Filter_StripTags()),
			'prefixPath'    => $this->elementPrefixPaths,
			'filters'       => $this->elementFilters
            )
        );

        $this->addElement('button', 'add', array(
            'id'        =>  'addbutton',
            'class'     =>  'formsubmit',
            'required'  =>  'true',
            'label'     =>  '{%Add%}',
            )
        );
        $this->addElement('hidden', 'websiteUrl', array());
        $this->setElementDecorators(array('ViewHelper',	'Errors'));
    }
}
