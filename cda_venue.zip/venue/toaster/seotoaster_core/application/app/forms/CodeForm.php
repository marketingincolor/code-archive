<?php

/**
 * Code form class.
 *
 * @author Eugene I. Nehzuta
 */
class RCMS_Form_CodeForm extends RCMS_Core_BaseForm {

    /**
     * Form initialization
     * @see Zend_Form#init()
     */
    public function init()
    {
        $this->setMethod('post');
        $this->setName('codeForm');
        $this->elementPrefixPaths['filter']['path'] = realpath(dirname(__FILE__).'/../filters/');

        $this->addElement('textarea', 'inlinecode', array(
            'id'        =>  'inlinecode',
            'attribs'   =>  array('rows' => '20', 'cols' => '60'),
			'prefixPath' => $this->elementPrefixPaths,
			'filters'    => $this->elementFilters
        ));

        $this->addElement('submit', 'submit', array(
            'id'        =>  'editcodesubmit',
            'class'     =>  'formsubmit',
            'ignore'	=>  'true',
            'label'     =>  '{%Done%}'
            )
        );
        $this->setElementDecorators(array('ViewHelper',	'Errors'));
    }
}
