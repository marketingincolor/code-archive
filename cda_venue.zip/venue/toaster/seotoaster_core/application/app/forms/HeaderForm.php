<?php

/**
 * Header form class.
 *
 * @author Eugene I. Nehzuta
 */
class RCMS_Form_HeaderForm extends RCMS_Core_BaseForm {

    /**
     * Form initialization
     * @see Zend_Form#init()
     */
    public function init()
    {
        $this->setMethod('post');
        $this->setName('headerForm');
        $this->elementPrefixPaths['filter']['path'] = realpath(dirname(__FILE__).'/../filters/');

        $this->addElement('text', 'headertext', array(
                'id'         => 'editheader',
				'filters'    => array(new Zend_Filter_StripTags()),
				'prefixPath' => $this->elementPrefixPaths,
				'filters'    => $this->elementFilters
        ));

        $this->addElement('submit', 'submit', array(
                'id'        =>  'editheadersubmit',
                'class'     =>  'formsubmit',
                'ignore'    =>  'true',
                'label'     =>  '{%Done%}'
                )
        );
		$this->addElement('hidden', 'ctype', array());
        $this->setElementDecorators(array('ViewHelper',	'Errors'));
    }
}
