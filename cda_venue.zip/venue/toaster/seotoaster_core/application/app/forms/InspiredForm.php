<?php
/**
 * Inspired form class.
 *
 * @author Pavel Savchuk
 */
class RCMS_Form_InspiredForm extends RCMS_Core_BaseForm {

    /**
     * Form initialization
     * @see Zend_Form#init()
     */
    public function init()
    {
        $this->setMethod('post');
        $this->setName('inspiredForm');
        $this->elementPrefixPaths['filter']['path'] = realpath(dirname(__FILE__).'/../filters/');

        $this->addElement('text', 'h1', array(
                'id'        =>  'h1',
                'style'     =>  'width:280px;',
                'onfocus'   =>  'this.select();',
                'label'     =>  '{%Text:%}',
				'prefixPath' => $this->elementPrefixPaths,
				'filters'    => $this->elementFilters
        ));

        $this->addElement('button', 'find', array(
                'id'        =>  'find',
                'class'     =>  'formsubmit',
                'ignore'    =>  'true',
                'label'     =>  '{%Search More%}'
                )
        );

        $this->addElement('hidden', 'website_url', array('value'=>unserialize(Zend_Registry::get('config'))->website->website->url));
        $this->setElementDecorators(array('ViewHelper',	));
    }
}
