<?php

/**
 * EditcssForm class.
 *
 * @author Eugene I. Nehzuta
 */
class RCMS_Form_EditrobotsForm extends RCMS_Core_BaseForm {

    /**
     * Form initialization
     * @see Zend_Form#init()
     */
    public function init()
    {
        $this->setMethod('post');
        $this->setName('editRobotsForm');
        $this->elementPrefixPaths['filter']['path'] = realpath(dirname(__FILE__).'/../filters/');

        $this->addElement('textarea', 'content', array(
            'id'        =>  'robotscode',
            'class'     =>  'robotscode',
            'required'  =>  true,
            'attribs'   =>  array('rows' => '20', 'cols' => '60'),
			'prefixPath' => $this->elementPrefixPaths,
			'filters'    => $this->elementFilters
        ));
        $this->content->removeDecorator('label');
        $this->content->removeDecorator('tag');
        $this->content->removeDecorator('Errors');

        $this->addElement('submit', 'submit', array(
            'class'     =>  'formsubmit',
            'id'        =>  'editrobotssubmit',
            'ignore'	=>  'true',
            'label'     =>  '{%Done%}'
            )
        );
        $this->submit->removeDecorator('tag');
        $this->submit->removeDecorator('DtDdWrapper');
    }
}
