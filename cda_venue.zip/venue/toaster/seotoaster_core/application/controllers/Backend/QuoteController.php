<?php

/**
 * Description of QuoteController
 *
 * @author NE
 */
class Backend_QuoteController extends RCMS_Core_BaseController {

	/**
	 * Data from shopping card config
	 * 
	 * @var array Name value pairs
	 */
	private $_shoppingConfig = array();

	/**
	 * Data from system config
	 *
	 * @var array Name value pairs
	 */
	private $_systemConfig = array();

    private $_locale = null;
	/**
	 * Initialization of the controller
	 * 
	 */
	public function init() {
        parent::init();
        $this->_checkLogin(array('preview', 'pdf'));
        $this->_model = new Backend_QuoteModel();
        $this->_shoppingConfig = $this->_model->selectShoppingConfig();
        if (null === $this->_locale){
            $this->_locale = new Zend_Locale(Zend_Locale::getLocaleToTerritory($this->_shoppingConfig['country']));
        }
    }

	/**
	 * Index action.
	 *
	 * Shows quote existing and new quotes list
	 */
	public function indexAction() {
		$this->_helper->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		
		//assigning variables
		//quote statuses
		$this->view->quotesAvstatuses = array(
			'new'  => 'New',
			'sent' => 'Sent',
			'sold' => 'Sold',
			'lost' => 'Lost'
		);
		//information about all quotes
		$this->view->quotesData = $this->_getAllQuotes();
		$this->view->websiteUrl = $this->getWebsiteUrl();
		
		//for translator
		echo $this->_translator->processScreen($this->view->render($this->getViewScript()));
	}

	/**
	 * Edit action.
	 *
	 */
	public function editAction()
    {
        $this->_helper->viewRenderer->setNoRender(true);
        
        $localer = new DateLocaler($this->_locale);
        $this->view->registerHelper($localer, 'dateLocaler');
        $user = unserialize($this->_session->currentUser)->getLogin();
        $quoteId = (int) $this->getRequest()->getParam('qid');
		if($quoteId > 0) {
			$generator = new RCMS_Object_Generator_Generator();
			$quote = new RCMS_Object_Quote_Quote($quoteId);
			$userCart = new RCMS_Object_Shopping_ShoppingUserCart($quote->getShoppingCartId());
			$cartData = $userCart->getCartData();
            //counting total price of all items in the user's cart
			$totalPrice = 0;
            $totalTax = 0;
            if (is_array($cartData)){
                foreach($cartData as $key => $value) {
                    $totalPrice += $value['price'] * $value['count'];
                }
                //taxes counting
                $totalTax = $this->_countTaxes($userCart);
            }
           
			//assigning varriables
			$this->view->quoteDetails = array(
				'quoteId'         => $quote->getId(),
				'hasPreview'      => ($quote->getContent() != ''),
				'quoteName'       => $quote->getName(),
				'quoteDate'       => strtotime($quote->getDate()),
				'quoteIntMsg'     => $quote->getInternalMessage(),
				'quoteDisclaimer' => $quote->getDisclaimer(),
                'quoteShipping'   => false,
                'quoteValidUntil' => $quote->getValidUntilDate()?strtotime($quote->getValidUntilDate()):strtotime($quote->getDate()),
			);
            if (!empty($this->_session->quotemailtext))
                $this->view->quoteDetails['mailToUser'] =  $this->_session->quotemailtext;
            else
                $this->view->quoteDetails['mailToUser'] = $this->_shoppingConfig['quote_email_body'];

            //shipping if it's enabled in config
            if ($this->_shoppingConfig['shipping_type'] != 'pickup'){
                $shipping = new RCMS_Object_Shipping_Shipping($quote->getShoppingCartId());
                $this->view->shippingData = $shipping->getShippingAddress();
                $this->view->quoteDetails['quoteShipping'] = $shipping->getShippingCost();
            }

			//all items in user's cart
            $this->view->quoteDiscount   = $quote->getDiscount();
			$this->view->totalPrice      = $totalPrice;
            $this->view->totalTax        = $totalTax;
			$this->view->cartData        = $cartData;
			$this->view->shoppingConfig  = $this->_shoppingConfig;
			$this->view->cartId          = $userCart->getId();
			$this->view->userMail        = $userCart->getEmail();
			$this->view->quoteEdit       = true;
            $this->view->lastEditedBy    = $quote->getLastEditedBy();
            $this->view->owner			 = $quote->getOwner();//$user;
			$this->view->additionalUserData = array(
                'name'     => $userCart->getName(),
				'address1' => $userCart->getAddress1(),
				'address2' => $userCart->getAddress2(),
                'company'  => $userCart->getCompany(),
				'country'  => $userCart->getCountry(),
				'state'    => $userCart->getState(),
				'city'     => $userCart->getCity(),
				'zip'      => $userCart->getZip(),
				'phone'    => $userCart->getPhone()
			);
		}
		$this->view->websiteUrl = $this->getWebsiteUrl();
		$this->view->path = $this->_config->website->website->path;
        $this->view->datepickerFormat = $localer->datepickerDateFormat;
        $this->view->lang = $this->_locale->getLanguage();
		//for translator
		echo $this->_translator->processScreen($this->view->render($this->getViewScript()));
	}

	
	
	
	
	
	
	
	
	
	
	public function reworkAction()
    {
        $this->_helper->viewRenderer->setNoRender(true);
        
        $localer = new DateLocaler($this->_locale);
        $this->view->registerHelper($localer, 'dateLocaler');
        $user = unserialize($this->_session->currentUser)->getLogin();
        $quoteId = (int) $this->getRequest()->getParam('qid');
		if($quoteId > 0) {
			$generator = new RCMS_Object_Generator_Generator();
			$quote = new RCMS_Object_Quote_Quote($quoteId);
			$userCart = new RCMS_Object_Shopping_ShoppingUserCart($quote->getShoppingCartId());
			$cartData = $userCart->getCartData();
            //counting total price of all items in the user's cart
			$totalPrice = 0;
            $totalTax = 0;
            if (is_array($cartData)){
                foreach($cartData as $key => $value) {
                    $totalPrice += $value['price'] * $value['count'];
                }
                //taxes counting
                $totalTax = $this->_countTaxes($userCart);
            }
           
			//assigning varriables
			$this->view->quoteDetails = array(
				'quoteId'         => $quote->getId(),
				'hasPreview'      => ($quote->getContent() != ''),
				'quoteName'       => $quote->getName(),
				'quoteDate'       => strtotime($quote->getDate()),
				'quoteIntMsg'     => $quote->getInternalMessage(),
				'quoteDisclaimer' => $quote->getDisclaimer(),
                'quoteShipping'   => false,
                'quoteValidUntil' => $quote->getValidUntilDate()?strtotime($quote->getValidUntilDate()):strtotime($quote->getDate()),
			);
            if (!empty($this->_session->quotemailtext))
                $this->view->quoteDetails['mailToUser'] =  $this->_session->quotemailtext;
            else
                $this->view->quoteDetails['mailToUser'] = $this->_shoppingConfig['quote_email_body'];

            //shipping if it's enabled in config
            if ($this->_shoppingConfig['shipping_type'] != 'pickup'){
                $shipping = new RCMS_Object_Shipping_Shipping($quote->getShoppingCartId());
                $this->view->shippingData = $shipping->getShippingAddress();
                $this->view->quoteDetails['quoteShipping'] = $shipping->getShippingCost();
            }

			//all items in user's cart
            $this->view->quoteDiscount   = $quote->getDiscount();
			$this->view->totalPrice      = $totalPrice;
            $this->view->totalTax        = $totalTax;
			$this->view->cartData        = $cartData;
			$this->view->shoppingConfig  = $this->_shoppingConfig;
			$this->view->cartId          = $userCart->getId();
			$this->view->userMail        = $userCart->getEmail();
			$this->view->quoteEdit       = true;
            $this->view->lastEditedBy    = $quote->getLastEditedBy();
            $this->view->owner			 = $quote->getOwner();//$user;
			$this->view->additionalUserData = array(
                'name'     => $userCart->getName(),
				'address1' => $userCart->getAddress1(),
				'address2' => $userCart->getAddress2(),
                'company'  => $userCart->getCompany(),
				'country'  => $userCart->getCountry(),
				'state'    => $userCart->getState(),
				'city'     => $userCart->getCity(),
				'zip'      => $userCart->getZip(),
				'phone'    => $userCart->getPhone()
			);
		}
		$this->view->websiteUrl = $this->getWebsiteUrl();
		$this->view->path = $this->_config->website->website->path;
        $this->view->datepickerFormat = $localer->datepickerDateFormat;
        $this->view->lang = $this->_locale->getLanguage();
		//for translator
		echo $this->_translator->processScreen($this->view->render($this->getViewScript()));
	}
	
	
	
	
	
	
	

	public function addnewAction()
    {

		$userCart = new RCMS_Object_Shopping_ShoppingUserCart();
		$timePostfix = date('Ymd-His');
		$userCart->setName(RCMS_Object_QuickConfig_QuickConfig::$temporaryNewQuoteName . $timePostfix);
		$userCart->setEmail('email@email.com');
		$cartId = $userCart->save();
        
		$quote = new RCMS_Object_Quote_Quote();
		$quote->setShoppingCartId($cartId);
		$quote->setName($userCart->getName());
        $quote->setStatus(RCMS_Object_Quote_Quote::Q_STATUS_NEW);
        $quote->setValidUntilDate(date('Y-m-d',time()+3*24*60*60));
        $user = unserialize($this->_session->currentUser)->getLogin();
        $quote->setLastEditedBy($user);
        $quote->setOwner($user);
        $quoteId = $quote->save();
        
        if ($quoteId > 0) {
            $this->_redirect($this->getWebSiteUrl() . 'sys/backend_quote/edit/qid/' . $quoteId);
        } else {
            $this->_redirect($this->getWebSiteUrl());
        }
	}

	public function updatequoteoncreationAction() {
		$this->_helper->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);

        if($this->getRequest()->isPost()) {
			$quoteId = (int) $this->getRequest()->getParam('qid');
            
			$name = $this->getRequest()->getParam('name');
			$quoteMail = $this->getRequest()->getParam('qMail');
			$quoteDate = $this->getRequest()->getParam('qDate');
            $quoteName = $this->getRequest()->getParam('qName');
            $quoteValidUntilDate = $this->getRequest()->getParam('qValidUntilDate');
			
			$quote = new RCMS_Object_Quote_Quote($quoteId);
			$quote->setDate(date('Y-m-d H:i:s', strtotime($quoteDate)));
            $quote->setValidUntilDate(date('Y-m-d H:i:s', strtotime($quoteValidUntilDate)));
            $quote->setName($quoteName);
            $quote->save();

			$cart = new RCMS_Object_Shopping_ShoppingUserCart($quote->getShoppingCartId());
			$cart->setName($name);
			$cart->setEmail($quoteMail);
            $cart->setCompany(RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('company')));
			$cart->setCountry(RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('country')));
			$cart->setState(RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('state')));
			$cart->setCity(RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('city')));
			$cart->setZip(RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('zip')));
			$cart->setAddress1(RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('address1')));
			$cart->setAddress2(RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('address2')));
			$cart->setPhone(RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('phone')));
			$cart->save();

            if ($this->_shoppingConfig['shipping_type'] != 'pickup'){
                $this->_updateShipping($cart);
            }
            echo json_encode(array('error' => 0, 'msg' => 'success'));
		}
	}

	/**
	 * Update quote status. (AJAX calling in quote.js)
	 * 
	 */
	public function updatestatusAction()
    {
		$this->_helper->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
        
		if ($this->getRequest()->isPost()) {
			$quoteId = intval($this->getRequest()->getParam('qid'));
			$status = $this->getRequest()->getParam('status');
			$quote = new RCMS_Object_Quote_Quote($quoteId);
			$quote->setStatus($status);
            $user = unserialize($this->_session->currentUser)->getLogin();
            $quote->setLastEditedBy($user);
			$result = $quote->save();

			if ($result) {
				echo json_encode(array('error' => 0, 'msg' => 'success'));
			} else {
				echo json_encode(array('error' => 1, 'msg' => 'Can\'t update quote status. Something went wrong'));
			}
		}
	}

	/**
	 * Delete quote. (AJAX calling in quote.js)
	 *
	 */
	public function deletequoteAction()
    {
		$this->_helper->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);

		if ($this->getRequest()->isPost()) {
			$quoteId = intval($this->getRequest()->getParam('qid'));
			$quote = new RCMS_Object_Quote_Quote($quoteId);
			$userCart = new RCMS_Object_Shopping_ShoppingUserCart($quote->getShoppingCartId());
            $shipping = new RCMS_Object_Shipping_Shipping($userCart->getId());

			if ($quote->delete()) {
				$result = $userCart->delete();
				if ($result) {
                    $shipping->delete();
					echo json_encode(array('error' => 0, 'msg' => 'success'));
				} else {
					echo json_encode(array('error' => 1, 'msg' => 'Unable to remove user cart. Something went wrong'));
				}
			} else {
				echo json_encode(array('error' => 1, 'msg' => 'Unable to remove quote. Something went wrong'));
			}
		}
	}

	/**
	 * Generate quote action (AJAX calling in quote.js)
	 *
	 * Generate quote content for user and sends him an email with link to his quote preview
	 * 
	 */
	public function generateAction() {
		$this->_helper->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
        
		$generator = new RCMS_Object_Generator_Generator();
		$this->_systemConfig = $this->_model->selectSystemConfig();
        $loggedUser = unserialize($this->_session->currentUser);
		$user       = $loggedUser->getLogin();
        $userEmail  = $loggedUser->getEmail();
        unset($loggedUser);
		$quoteId = $this->getRequest()->getParam('qid');
		$quote = new RCMS_Object_Quote_Quote($quoteId);

        $emailToUser = RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('emailSend'));
        $discount    = RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('discount'));
        
        if ($emailToUser == 'true') {
            //text to put in email to user
            $userCart = new RCMS_Object_Shopping_ShoppingUserCart($quote->getShoppingCartId());
            $userMailText = RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('usrMailText'));
            $userMailText = str_replace('{$name}', $userCart->getName(), $userMailText);
            $userMailText = str_replace('{$date}', date('Y-m-d'), $userMailText);
            $userMailText = str_replace('{$quote_url}', $this->getWebSiteUrl() . 'sys/backend_quote/preview/qid/' . $quoteId . '.' . md5($quoteId) . '.' . $quoteId, $userMailText);
            $userMailText = str_replace('{$logged_user}', '<a href="mailto:'.$userEmail.'">'.$user.'</a>', $userMailText);
            //sending email to user
            //$mailSent = $this->_sendMailToUser(array('email'=>$userCart->getEmail(),'name'=>$userCart->getName()), $quoteId, $userMailText);
            $mailSent = $this->_sendMailToUser(array('email'=>$userCart->getEmail(),'name'=>$user), $quoteId, $userMailText);
            //unset($userCart);
            //if mail sent, then we will generate quote content and set quote status as "sent"
            if($mailSent === true) {
                //$userCart = new RCMS_Object_Shopping_ShoppingUserCart($quote->getShoppingCartId());
                $totalTax = $this->_countTaxes($userCart);
                $quote->setDisclaimer(RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('disclaimer')));
                $quote->setDiscount($discount);
                $quote->setContent($generator->generateQuoteContent($quote, $userCart, $totalTax));
                $quote->setInternalMessage(RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('intMessage')));
                $quote->setStatus(RCMS_Object_Quote_Quote::Q_STATUS_SENT);
                $quote->setLastEditedBy($user);
                $quote->setOwner($user);
                $quote->save();

                $adsubject = 'Admin copy of quote request from user '.$user;
               	$adbody = $userMailText;
                $adheader = "From: noreply@vifurniture.com\r\n";
                $adheader .= "MIME-Version: 1.0\r\n";
                $adheader .= "Content-Type: text/html; charset=utf-8\r\n";
                mail($this->_shoppingConfig['email'],$adsubject,$adbody,$adheader);
                //$this->sendEmail($this->_shoppingConfig['email'], $this->_shoppingConfig['company'], $this->_configTableArray['admin_email'], '', $adsubject, $adbody, $useSmtp);
                    
                //send response wich shows that everything went well
                echo json_encode(array('error' => 0, 'msg' => 'success'));
            } else {
                //if mail not sent, send error response
                echo json_encode(array('error' => 1, 'msg' => 'Can not send email. Quote was not generated'));
            }
        } elseif ($emailToUser == 'false') {
            $userCart = new RCMS_Object_Shopping_ShoppingUserCart($quote->getShoppingCartId());
            $totalTax = $this->_countTaxes($userCart);
            $quote->setDisclaimer(RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('disclaimer')));
            $quote->setDiscount($discount);
            $quote->setContent($generator->generateQuoteContent($quote, $userCart, $totalTax));
            $quote->setInternalMessage(RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('intMessage')));
            $quote->setLastEditedBy($user);
            $quote->setOwner($user);
            $quote->save();

            echo json_encode(array('error' => 0, 'msg' => 'saved'));
        }

        if ($this->_shoppingConfig['shipping_type'] != 'pickup'){
            $this->_updateShipping($userCart);
        }
        $this->_session->quotemailtext = trim($this->getRequest()->getParam('usrMailText'));
                
	}

	/**
	 * Show quote preview
	 */
	public function previewAction() {
		$this->_helper->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		$preQuoteInfo = explode('.', $this->getRequest()->getParam('qid'));

		if ($preQuoteInfo[0] != $preQuoteInfo[2]) {
			echo '<h1>Ooops! Wrong quote?</h1>';
			return;
		}
		$quoteId = $preQuoteInfo[0];
		$quote = new RCMS_Object_Quote_Quote($quoteId);
		echo $this->_translator->processScreen($quote->getContent());
	}

	public function addproducttocartAction() {
		$this->_helper->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);

		$cartId = intval($this->getRequest()->getParam('cid'));
		$productId = intval($this->getRequest()->getParam('pid'));

		$userCart = new RCMS_Object_Shopping_ShoppingUserCart($cartId);
		$cartData = $userCart->getCartData();

        $updated = false;
        foreach ($cartData as &$item){
            if ($item['id'] == $productId && !isset($item['parent'])){
                $item['count']++;
                $updated = true;
                break;
            } 
        }
        if (!$updated) {
            $product = new RCMS_Object_Product_Product($productId);
            $cartData[] = array(
                'count' => 1,
                'photo' => $product->getPhoto(),
                'name'  => $product->getName(),
                'price' => $product->getPrice(),
                'note'  => '',
            	'memo'  => '',
                'id'    => $product->getId()
            );
            if ($product->getFreebies() != ''){
                foreach (explode(',', $product->getFreebies()) as $id){
                    $freebie = new RCMS_Object_Product_Product($id);
                    $cartData[] = array(
                        'count' => 1,
                        'photo' => $freebie->getPhoto(),
                        'name'  => $freebie->getName(),
                        'price' => '0',
                        'note'  => '{%free%}',
                        'id'    => $freebie->getId(),
                        'parent'=> $productId

                    );
                    unset($freebie);
                }
            }
        }
		$userCart->setCartData($cartData);
		$result = $userCart->save();
		if($result) {
			echo json_encode(array('error' => 0, 'msg' => 'success'));
		}
		else {
			echo json_encode(array('error' => 1, 'msg' => 'Can not add product. Something went wrong'));
        }
	}

	/**
	 * Update user cart
	 * 
	 */
	public function updatecartAction() {
		$this->_helper->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		$cartId = $this->getRequest()->getParam('qid');
		$userCart = new RCMS_Object_Shopping_ShoppingUserCart($cartId);
		$cartData = $userCart->getCartData();
		//item that should be removed
		//$toRemove = json_decode(RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('toRemove')));
		//items wich price should be updated
		$toUpdatePrice = json_decode(RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('toUpdPrice')));
		//items wich note should be updated
		$adminNotes = json_decode(RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('notes')));
		$adminMemo = json_decode(RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('memo')));
		//items wich quantity should be updated
		$toUpdateQty = json_decode(RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('toUpdQty')));
        $quoteId = (int) $this->getRequest()->getParam('quoteId');
        $quote = new RCMS_Object_Quote_Quote($quoteId);
        if ($quote->getId() > 0) {
            $quote->setDisclaimer(RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('disclaimer')));
            $quote->setInternalMessage(RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('intMsgText')));
            $user = unserialize($this->_session->currentUser)->getLogin();
            $quote->setLastEditedBy($user);
            $quote->setDiscount(RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('discount')));
            $quote->save();

            if ($this->_shoppingConfig['shipping_type'] != 'pickup'){
                $this->_updateShipping($userCart);
            }
        }
		//update items price
		if(!empty ($toUpdatePrice)) {
			foreach ($toUpdatePrice as $priceItem) {	
				if(array_key_exists($priceItem->id, $cartData)) {
					$cartData[$priceItem->id]['price'] = $priceItem->value;
				}
			}
		}
		//update items qty
		if(!empty($toUpdateQty)) {
			foreach($toUpdateQty as $qtyItem) {
                $updId  = $qtyItem->id;
                $updQty = $qtyItem->value;
				if(array_key_exists($updId, $cartData)) {
					if($updQty == 0) {
                        // removing product with it freebies
                        foreach ($cartData as $key => $cartItem){
                            if (isset($cartItem['parent']) && $cartItem['parent']==$cartData[$updId]['id']){
                                unset($cartData[$key]);
                            }
                        }
                        unset ($cartData[$updId]);
						continue;
					}
					if($cartData[$updId]['count'] != $updQty) {
                        //updating quality
						$cartData[$updId]['count'] = $updQty;
                        foreach ($cartData as &$cartItem){
                            if (isset($cartItem['parent']) && $cartItem['parent']==$cartData[$updId]['id']){
                                $cartItem['count'] = $updQty;
                            }
                        }
					}
				}
			}
		}
		//update items notes
		if(!empty($adminNotes)) {
			foreach($adminNotes as $noteData) {
				if(array_key_exists($noteData->id, $cartData)) {
					$cartData[$noteData->id]['note'] = $noteData->value;
				}
			}
		}
		//update items memo
		if(!empty($adminMemo)) {
			foreach($adminMemo as $memoData) {
				if(array_key_exists($memoData->id, $cartData)) {
					$cartData[$memoData->id]['memo'] = $memoData->value;
				}
			}
		}
		//saving cart
        $this->_session->quotemailtext = trim($this->getRequest()->getParam('mailUserText'));
        $userCart->setCartData($cartData);
		$userCart->save();
	}

	/**
	 * Getting data about quotes from database
	 * 
	 */
	private function _getAllQuotes() {
		$quotesData = $this->_model->selectAllQuotes();
		return $quotesData;
	}

	/**
	 * Sending mail to the user
	 *
	 */
	private function _sendMailToUser($mailTo, $quoteId, $mailText) {
		$mail = new RCMS_Object_Mailer_Mailer();
		if($this->_systemConfig['use_smtp']) {
			$mail->setSmtpConfig($this->_systemConfig['smtp_login'], $this->_systemConfig['smtp_password'], $this->_systemConfig['smtp_host']);
			$mail->setTransport(RCMS_Object_Mailer_Mailer::MAIL_TYPE_SMTP);
		}
		$mail->setFrom($this->_shoppingConfig['company']);
		$mail->setFromMail($this->_shoppingConfig['email']);
		$mail->setTo($mailTo['name']);
		$mail->setToMail($mailTo['email']);
		$mail->setSubject($this->_shoppingConfig['quote_email_subj']);
		$mail->setBody($mailText);
		return $mail->send();
	}

	
	
	
	
    public function pdfAction()
    {
        $this->_helper->getHelper('layout')->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);

        $quoteId = (int) $this->getRequest()->getParam('id');
        $invoiceId = $this->getRequest()->getParam('invoice');
        $quote = new RCMS_Object_Quote_Quote($quoteId);
        if ($quote->getId() <= 0) {
            return;
        }
        $pdf = new Zend_Pdf();
        $pdfPage = new Zend_Pdf_Page(Zend_Pdf_Page::SIZE_A4);
        $font = Zend_Pdf_Font::fontWithName(Zend_Pdf_Font::FONT_HELVETICA);
        //$font = Zend_Pdf_Font::fontWithName(Zend_Pdf_Font::FONT_TIMES_ROMAN);
        $padding = 20;
        $encoding = 'UTF-8';

        /*** left block ***/
        $shoppingConfig = $this->_shoppingConfig;
        $companyLogo = trim($this->_config->website->website->path.$shoppingConfig['company_logo']);
        $companyName = trim($shoppingConfig['company']); 
        $companyUrl = 'www.vifurniture.com';       
        $companyAddress = trim($shoppingConfig['address']);
        if (trim($shoppingConfig['address'])  != '' && trim($shoppingConfig['address2'])) $companyAddress .= ', ';
        if (trim($shoppingConfig['address2']) != '') $companyAddress .= $shoppingConfig['address2'];
        $companyAddress2 = trim($shoppingConfig['city']);
        if ((trim($shoppingConfig['city'])!='') and (trim($shoppingConfig['state'])!='' or trim($shoppingConfig['zip'])!='')) $companyAddress2 .= ', ';
        $companyAddress2 .= trim($shoppingConfig['state']);
        if (trim($shoppingConfig['state'])!='') $companyAddress2 .= ' ';
        $companyAddress2 .= trim($shoppingConfig['zip']);
        $companyCountry = trim($shoppingConfig['country']);
        $companyPhone = trim($shoppingConfig['phone']);
        $companyEmail = trim($shoppingConfig['email']);
        $img = null;
        $imageInfo = getimagesize($companyLogo);

        switch ($imageInfo['mime']){
            case 'image/png':
                $img = new Zend_Pdf_Resource_Image_Png($companyLogo);
                break;
            case 'image/jpeg':
                $img = new Zend_Pdf_Resource_Image_Jpeg($companyLogo);
                break;
            case 'image/tiff':
                $img = new Zend_Pdf_Resource_Image_Tiff($companyLogo);
                break;
            default:
                break;
        }
        
        /*if (is_file($companyLogo) && preg_match('/\.(png|jpg|jpe|jpeg|tiff|tif)$/', basename($companyLogo)) && is_object($img)) {
            //$logoWidth = $img->getPixelWidth() < 600 ? $img->getPixelWidth() : 600;
            //$logoHeight = $img->getPixelHeight() < 150 ? $img->getPixelHeight() : 150;
            $logoWidth = $img->getPixelWidth();
            $logoHeight = $img->getPixelHeight();
            $pdfPage->drawImage($img, $padding, ($pdfPage->getHeight() - $padding) - $logoHeight, $logoWidth, $pdfPage->getHeight() - $padding);
        	$Y_HeightLeft = ($pdfPage->getHeight() - $padding) - $logoHeight;
        } else {*/
            $Y_HeightLeft = $pdfPage->getHeight() - $padding;
        /*}*/
   		/*if ($companyUrl !== '') {
            $Y_HeightLeft -= 10;
            $pdfPage->setFont($font, 10);
            $pdfPage->drawText($companyUrl, $padding, $Y_HeightLeft, $encoding);
        }*/
        if ($companyName !== '') {
            $Y_HeightLeft -= 30;
            $pdfPage->setFont($font, 10);
            $pdfPage->drawText($companyName, $padding, $Y_HeightLeft, $encoding);
        }
        $pdfPage->setFont($font, 10);

        if ($companyAddress !== '') {
            $Y_HeightLeft -= 10;            
            $pdfPage->drawText($companyAddress, $padding, $Y_HeightLeft, $encoding);
        }

        if ($companyAddress2 !== '') {
            $Y_HeightLeft -= 10;
            $pdfPage->drawText($companyAddress2, $padding, $Y_HeightLeft, $encoding);
        }
        
        /*if ($companyCountry !== '') {
            $Y_HeightLeft -= 10;
            $pdfPage->drawText($companyCountry, $padding, $Y_HeightLeft, $encoding);
        }*/

        if ($companyPhone !== '') {
            $Y_HeightLeft -= 10;
            $pdfPage->drawText($companyPhone, $padding, $Y_HeightLeft, $encoding);
        }
        
        if ($companyEmail !== '') {
            $Y_HeightLeft -= 10;
            $pdfPage->drawText($companyEmail, $padding, $Y_HeightLeft, $encoding);
        }
        
        
        /*** end left block ***/

        /*** right block ***/
        $Y_HeightRight = $pdfPage->getHeight() - 40;
        $X_WidthRight = $pdfPage->getWidth() - 200;
        $pdfPage->setFont($font, 10);

        //$Y_HeightRight -= 10;
        $pdfPage->setFont($font, 10);
        //$pdfPage->drawText('Quote Generated by Venue Industries Furniture', $X_WidthRight, $Y_HeightRight, $encoding);
        //$Y_HeightRight -= 10;
        if($quote->getDate()) {
            $pdfPage->drawText(date("Y-m-d",strtotime($quote->getDate())), $pdfPage->getWidth()-60, $Y_HeightRight, $encoding);
        }
        $shoppingCart = new RCMS_Object_Shopping_ShoppingUserCart($quote->getShoppingCartId());

        if ($shoppingCart->getName()) {
            $Y_HeightRight -= 20;
            $pdfPage->drawText((strlen($shoppingCart->getName()) < 20 ? ucfirst($shoppingCart->getName()) : substr($shoppingCart->getName(), 0, 18).'...'), $X_WidthRight, $Y_HeightRight, $encoding);
            //$Y_HeightLeft -= 20;
            //$pdfPage->drawText((strlen($shoppingCart->getName()) < 20 ? ucfirst($shoppingCart->getName()) : substr($shoppingCart->getName(), 0, 18).'...'), $padding, $Y_HeightLeft, $encoding);
        }

        if ($shoppingCart->getCompany()) {
            $Y_HeightRight -= 10;
            $pdfPage->drawText($shoppingCart->getCompany(), $X_WidthRight, $Y_HeightRight, $encoding);
            //$Y_HeightLeft -= 10;
            //$pdfPage->drawText($shoppingCart->getCompany(), $padding, $Y_HeightLeft, $encoding);
        }
        $userPostAddress  = $shoppingCart->getAddress1();
        if ($shoppingCart->getAddress1() && $shoppingCart->getAddress1()) $userPostAddress .= ', ';
        $userPostAddress .= $shoppingCart->getAddress2();
        if ($userPostAddress) {
            $Y_HeightRight -= 10;
            $pdfPage->drawText($userPostAddress, $X_WidthRight, $Y_HeightRight, $encoding);
            //$Y_HeightLeft -= 10;
            //$pdfPage->drawText($userPostAddress, $padding, $Y_HeightLeft, $encoding);
        }

        $userPostAddress2  = $shoppingCart->getCity();
        if ($shoppingCart->getCity() && ($shoppingCart->getState() or $shoppingCart->getZip())) $userPostAddress2 .= ', ';
        $userPostAddress2 .= $shoppingCart->getState();
        if ($shoppingCart->getState() && $shoppingCart->getZip()) $userPostAddress2 .= ' ';
        $userPostAddress2 .= $shoppingCart->getZip();

        if ($userPostAddress2) {
            $Y_HeightRight -=10;
            $pdfPage->drawText($userPostAddress2, $X_WidthRight, $Y_HeightRight, $encoding);
            //$Y_HeightLeft -=10;
            //$pdfPage->drawText($userPostAddress2, $padding, $Y_HeightLeft, $encoding);
        }

        /*if ($shoppingCart->getCountry()) {
            $Y_HeightRight -=10;
            $pdfPage->drawText($shoppingCart->getCountry(), $X_WidthRight, $Y_HeightRight, $encoding);
            //$Y_HeightLeft -=10;
            //$pdfPage->drawText($shoppingCart->getCountry(), $padding, $Y_HeightLeft, $encoding);
        }*/
        if ($shoppingCart->getEmail()) {
            $Y_HeightRight -=10;
            $pdfPage->drawText($shoppingCart->getEmail(), $X_WidthRight, $Y_HeightRight, $encoding);
            //$Y_HeightLeft -=10;
            //$pdfPage->drawText($shoppingCart->getEmail(), $padding, $Y_HeightLeft, $encoding);
        }

        if ($shoppingCart->getPhone()) {
            $Y_HeightRight -= 10;
            $pdfPage->drawText($shoppingCart->getPhone(), $X_WidthRight, $Y_HeightRight, $encoding);
            //$Y_Heightleft -= 10;
            //$pdfPage->drawText($shoppingCart->getPhone(), $padding, $Y_HeightLeft, $encoding);
        }
        
        /*** end right block ***/

        /*** center block ***/
        $currency = $shoppingConfig['currency'];
        $pdfPage->setFont($font, 12);
        $pdfPage->drawText((null !== $invoiceId ? 'Spec Sheet # ' . $invoiceId :  'Spec Sheet # ' . $quoteId . ' - ' . $shoppingCart->getName() ), $pdfPage->getWidth()/2.25, 700, $encoding);
        $Y_HeightCenter = 670;//570;
        
        $pdfPage->setFillColor(Zend_Pdf_Color_Html::color('#eeeeee'));
        $pdfPage->drawRectangle(0, 690, $pdfPage->getWidth(), 660, Zend_Pdf_Page::SHAPE_DRAW_FILL);

        $pdfPage->setFont($font, 8);
        $pdfPage->setFillColor(Zend_Pdf_Color_Html::namedColor('black'));
        $x_Pos = array (
            'num'     => 10,
        	'photo'   => 40,
            'product' => 200,
            'note'    => 330,
        	'memo'    => 400,
            'qty'     => 480,
            'baseprice'   => 505,
        	'price'   => 555
            );
        $pdfPage->drawText('#', $x_Pos['num'], $Y_HeightCenter, $encoding);
        $pdfPage->drawText('Photo', $x_Pos['photo'], $Y_HeightCenter, $encoding);
        $pdfPage->drawText('Product', $x_Pos['product'], $Y_HeightCenter, $encoding);
        $pdfPage->drawText('Location', $x_Pos['note'], $Y_HeightCenter, $encoding);

        $pdfPage->drawText('Note', $x_Pos['memo'], $Y_HeightCenter, $encoding);
        
        $pdfPage->drawText('Qty', $x_Pos['qty'], $Y_HeightCenter, $encoding);
        //$pdfPage->drawText('Price ('.$currency.')',  $x_Pos['price'], $Y_HeightCenter, $encoding);
        $pdfPage->drawText('Base Price',  $x_Pos['baseprice'], $Y_HeightCenter, $encoding);
        $pdfPage->drawText('Price',  $x_Pos['price'], $Y_HeightCenter, $encoding);

        $data = $shoppingCart->getCartData(true);
        $Y_HeightCenter -= 15;
        $pdfPage->setFont($font, 10);
        $pdfPage->setLineColor(Zend_Pdf_Color_Html::color('#eeeeee'));
        $pdfPage->setLineWidth(0.5);
        $totalPrice = 0;
        $totalTax   = $this->_countTaxes($shoppingCart);
        $i = 1;
        foreach ($data as $item) {
            $photo = trim($this->_config->website->website->path.$item['photo']);
            $img = null;
            $imageInfo = getimagesize($photo);
            $listpos = $i;
            $i++;
            
            switch ($imageInfo['mime']){
                case 'image/png':
                    $img = new Zend_Pdf_Resource_Image_Png($photo);
                    break;
                case 'image/jpeg':
                    $img = new Zend_Pdf_Resource_Image_Jpeg($photo);
                    break;
                case 'image/tiff':
                    $img = new Zend_Pdf_Resource_Image_Tiff($photo);
                    break;
                default:
                    break;
            }
            
            
            
            $pdfPage->setFont($font, 8);
            
                if (strlen($listpos) > 25 && strpos($listpos, ' ') !== false) {
                $idTmp = explode(' ', $listpos);
                $idStr = '';
                $y_Tmp = $Y_HeightCenter - 12;
                foreach ($idTmp as $value) {
                    $idStr .= $value . ' ';
                    if (strlen($idStr)>=20) {
                        $pdfPage->drawText($idStr, $x_Pos['num'], $y_Tmp, $encoding);
                        $y_Tmp -= 12;
                        $idStr = '';
                    }
                }
                if ($idStr) $pdfPage->drawText($idStr, $x_Pos['num'], $y_Tmp, $encoding);
            } else {
                $pdfPage->drawText(substr($listpos, 0, 24), $x_Pos['num'], $Y_HeightCenter-30, $encoding);
            }
            
            
            

            if (is_file($photo) && preg_match('/\.(png|jpg|jpe|jpeg|tiff|tif)$/', basename($photo)) && is_object($img)) {
                //$pdfPage->drawImage($img, $x_Pos['photo'], $Y_HeightCenter-90, 180, $Y_HeightCenter-5);
                $pdfPage->drawImage($img, $x_Pos['photo'], $Y_HeightCenter-($img->getPixelHeight()*.5), ($img->getPixelWidth()*.5)+40, $Y_HeightCenter);
            } else {
                $pdfPage->drawText('No Image', $x_Pos['photo']-10, $Y_HeightCenter-70, $encoding);
            }
            
			$pdfPage->setFont($font, 8);

			$optionstring = $item['options'];
			//$optionsdata = '';
			//foreach ($optionstring as $key => $value) {
    		//$optionsdata .= "$key: $value||";
        	//}

            if (strlen($item['itemId']) > 30 && strpos($item['itemId'], ' ') !== false ) {
                $nameTmp = explode(' ', $item['itemId']);
                $nameStr = '';
                $y_Tmp = $Y_HeightCenter - 12;
                foreach ($nameTmp as $value) {
                    $nameStr .= $value . ' ';
                    if (strlen($nameStr)>=30) {
                        $pdfPage->drawText($nameStr, $x_Pos['product'], $y_Tmp, $encoding);
                        $y_Tmp -= 12;
                        $nameStr = '';
                    }
                }
                
                if ($nameStr) $pdfPage->drawText($nameStr, $x_Pos['product'], $y_Tmp, $encoding);
                //$pdfPage->drawText($optionsdata, $x_Pos['product'], $Y_HeightCenter-38, $encoding);
                $y_Tmp = $Y_HeightCenter - 38;
                foreach ($optionstring as $key => $value) {
                    $optionsStr .= "$key: $value ";
                    if (strlen($optionsStr)>=5) {
                        $pdfPage->drawText($optionsStr, $x_Pos['product'], $y_Tmp, $encoding);
                        $y_Tmp -= 10;
                        $optionsStr = '';
                    }
                }
                
            } else {
                $pdfPage->drawText($item['itemId'], $x_Pos['product'], $Y_HeightCenter-30, $encoding);
                //$pdfPage->drawText($optionsdata, $x_Pos['product'], $Y_HeightCenter-38, $encoding);
                $y_Tmp = $Y_HeightCenter - 38;
                foreach ($optionstring as $key => $value) {
                    $optionsStr .= "$key: $value ";
                    if (strlen($optionsStr)>=5) {
                        $pdfPage->drawText($optionsStr, $x_Pos['product'], $y_Tmp, $encoding);
                        $y_Tmp -= 10;
                        $optionsStr = '';
                    }
                }
            }
            
            
            
            
            
            
            if (strlen($item['note']) > 25 && strpos($item['note'], ' ') !== false) {
                $noteTmp = explode(' ', $item['note']);
                $noteStr = '';
                $y_Tmp = $Y_HeightCenter - 12;
                foreach ($noteTmp as $value) {
                    $noteStr .= $value . ' ';
                    if (strlen($noteStr)>=15) {
                        $pdfPage->drawText($noteStr, $x_Pos['note'], $y_Tmp, $encoding);
                        $y_Tmp -= 10;
                        $noteStr = '';
                    }
                }
                if ($noteStr) $pdfPage->drawText($noteStr, $x_Pos['note'], $y_Tmp, $encoding);
            } else {
                $pdfPage->drawText(substr($item['note'], 0, 24), $x_Pos['note'], $Y_HeightCenter-30, $encoding);
            }
            
            if (strlen($item['memo']) > 25 && strpos($item['memo'], ' ') !== false) {
                $memoTmp = explode(' ', $item['memo']);
                $memoStr = '';
                $y_Tmp = $Y_HeightCenter - 12;
                foreach ($memoTmp as $value) {
                    $memoStr .= $value . ' ';
                    if (strlen($memoStr)>=15) {
                        $pdfPage->drawText($memoStr, $x_Pos['memo'], $y_Tmp, $encoding);
                        $y_Tmp -= 10;
                        $memoStr = '';
                    }
                }
                if ($memoStr) $pdfPage->drawText($memoStr, $x_Pos['memo'], $y_Tmp, $encoding);
            } else {
                $pdfPage->drawText(substr($item['memo'], 0, 24), $x_Pos['memo'], $Y_HeightCenter-30, $encoding);
            }
            
            $pdfPage->setFont($font, 8);
            $pdfPage->drawText($item['count'], $x_Pos['qty'], $Y_HeightCenter-30, $encoding);
            //$pdfPage->drawText($item['price'].' '.$currency, $x_Pos[price], $Y_HeightCenter-30, $encoding);
            $pdfPage->drawText('$'.$item['price'].'.00', $x_Pos['baseprice'], $Y_HeightCenter-30, $encoding);
            $pdfPage->drawText('$'.$item['price'] * $item['count'].'.00', $x_Pos['price'], $Y_HeightCenter-30, $encoding);
            //$pdfPage->drawLine(0, $Y_HeightCenter-60, $pdfPage->getWidth(), $Y_HeightCenter-60);
            $pdfPage->drawLine(0, $Y_HeightCenter-90, $pdfPage->getWidth(), $Y_HeightCenter-90);
            $totalPrice += $item['price'] * $item['count'];
            
            if ($Y_HeightCenter - 90 < 0) {
                $pdf->pages[] = $pdfPage;
                $pdfPage = new Zend_Pdf_Page(Zend_Pdf_Page::SIZE_A4);
                $pdfPage->setFont($font, 12);
                $pdfPage->setLineColor(Zend_Pdf_Color_Html::color('#eeeeee'));
                $pdfPage->setLineWidth(0.5);
                $Y_HeightCenter = $pdfPage->getHeight()-15;
            } else {
                //$Y_HeightCenter -= 70;
                $Y_HeightCenter -= 100;
            }

        }
        if ($Y_HeightCenter - 90 < 0) {
                $pdf->pages[] = $pdfPage;
                $pdfPage = new Zend_Pdf_Page(Zend_Pdf_Page::SIZE_A4);
                $pdfPage->setFont($font, 12);
                $pdfPage->setLineColor(Zend_Pdf_Color_Html::color('#eeeeee'));
                $pdfPage->setLineWidth(0.5);
                $Y_HeightCenter = $pdfPage->getHeight()-15;
        }

        /*if ($quote->getDisclaimer()) {
            $y_Tmp = $Y_HeightCenter - 20;
            //$pdfPage->drawText('Disclaimer: ', $x_Pos['photo'], $y_Tmp+15, $encoding);
            if (strlen($quote->getDisclaimer()) > 60 && strpos($quote->getDisclaimer(), ' ') !== false) {
                
                $disclaimerTmp = explode(' ', $quote->getDisclaimer());
                $disclaimerStr = '';
                
                foreach ($disclaimerTmp as $value) {
                    $disclaimerStr .= $value . ' ';
                    if (strlen($disclaimerStr)>=60) {
                        $pdfPage->drawText($disclaimerStr, $x_Pos['photo'], $y_Tmp, $encoding);
                        $y_Tmp -= 16;
                        $disclaimerStr = '';
                    }
                }
                if ($disclaimerStr) $pdfPage->drawText($disclaimerStr, $x_Pos['photo'], $y_Tmp, $encoding);
            } else {
                $pdfPage->drawText(substr($quote->getDisclaimer(), 0, 60), $x_Pos['photo'], $y_Tmp, $encoding);
            }
            //$pdfPage->drawText($quote->getDisclaimer(), 50, $Y_HeightCenter-40, $encoding);
        }*/

        $pdfPage->setFont($font, 10);
        
        if ($totalPrice) {
            $Y_HeightCenter -= 20;
            //$pdfPage->drawText('Sub-total: ', $pdfPage->getWidth()-220, $Y_HeightCenter, $encoding);
            ////$pdfPage->drawText($totalPrice.' ('.$shoppingConfig['currency'].')', $pdfPage->getWidth()-140, $Y_HeightCenter, $encoding);
            //$pdfPage->drawText($totalPrice, $pdfPage->getWidth()-140, $Y_HeightCenter, $encoding);
        }
        if ($totalTax) {
            //$Y_HeightCenter -= 20;
            //$pdfPage->drawText('Tax: ', $pdfPage->getWidth()-220, $Y_HeightCenter, $encoding);
            //$pdfPage->drawText($totalTax.' ('.$shoppingConfig['currency'].')', $pdfPage->getWidth()-140, $Y_HeightCenter, $encoding);
        }
        if ($shoppingConfig['shipping_type'] != 'pickup') {
            $shippObj = new RCMS_Object_Shipping_Shipping($shoppingCart->getId());

            $shipping = number_format($shippObj->getShippingCost(),2,'.','');
            if ($shipping) {
                $Y_HeightCenter -= 20;
                $pdfPage->drawText('Shipping: ', $pdfPage->getWidth()-220, $Y_HeightCenter, $encoding);
                $pdfPage->drawText($shipping.' ('.$shoppingConfig['currency'].')', $pdfPage->getWidth()-140, $Y_HeightCenter, $encoding);
            }
        }
        $Y_HeightCenter -= 10;
        $pdfPage->setLineColor(Zend_Pdf_Color_Html::color('#7c7c7c'));
        $pdfPage->setLineWidth(1.25);
        $pdfPage->drawLine($pdfPage->getWidth()-230, $Y_HeightCenter, $pdfPage->getWidth()-10, $Y_HeightCenter);

        $grandTotal = $totalPrice + $totalTax + $shipping;

        $Y_HeightCenter -= 20;
        //$pdfPage->drawText('Grand Total: ', $pdfPage->getWidth()-220, $Y_HeightCenter, $encoding);
        //$pdfPage->drawText($grandTotal.' ('.$shoppingConfig['currency'].')', $pdfPage->getWidth()-140, $Y_HeightCenter, $encoding);
        $pdfPage->drawText('Base Price Total Estimate: ', $pdfPage->getWidth()-220, $Y_HeightCenter, $encoding);
        $pdfPage->drawText('$'.$grandTotal.'.00', $pdfPage->getWidth()-90, $Y_HeightCenter, $encoding);
		
        $Y_HeightCenter -= 10;
        $pdfPage->setFont($font, 8);
        $bpte = '* The Base Price Total Estimate reflects the sum of suggested base prices shown in this Spec Sheet and is provided solely as a budgeting tool to keep track of the approximate cost of the furniture package presented. Actual pricing may be discounted or increased based on the quantities and options chosen. Shipping and taxes not included. All pricing is USD.';
            $y_Tmp = $Y_HeightCenter - 10;
            if (strlen($bpte) > 50 && strpos($bpte, ' ') !== false) {
                
                $bpteTmp = explode(' ', $bpte);
                $bpteStr = '';
                
                foreach ($bpteTmp as $value) {
                    $bpteStr .= $value . ' ';
                    if (strlen($bpteStr)>=50) {
                        $pdfPage->drawText($bpteStr, $pdfPage->getWidth()-220, $y_Tmp, $encoding);
                        $y_Tmp -= 8;
                        $bpteStr = '';
                    }
                }
                if ($bpteStr) $pdfPage->drawText($bpteStr, $pdfPage->getWidth()-220, $y_Tmp, $encoding);
            } 
        //$pdfPage->drawText($bpte, $pdfPage->getWidth()-220, $Y_HeightCenter, $encoding);
        
        /*** end center block ***/
        
        $pdf->pages[] = $pdfPage;
        $pdfString = $pdf->render();
        $this->getResponse()->setHeader('Content-Disposition', 'attachment; filename='. str_replace(' ', '_', $shoppingCart->getName()).'.pdf')
        	->setHeader('Content-Type', 'application/pdf');
        echo $pdfString;
    }
    
    

    
    public function excelAction()
    {
    	require_once $this->_config->website->website->path.'/Classes/PHPExcel.php';
    	
    	$this->_helper->getHelper('layout')->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
        
        $quoteId = (int) $this->getRequest()->getParam('id');
        $invoiceId = $this->getRequest()->getParam('invoice');
        $quote = new RCMS_Object_Quote_Quote($quoteId);
        if ($quote->getId() <= 0) {
            return;
        }
        $shoppingCart = new RCMS_Object_Shopping_ShoppingUserCart($quote->getShoppingCartId());

        $objPHPExcel = new PHPExcel();
        $objPHPExcel->setActiveSheetIndex(0);
        $worksheet = $objPHPExcel->getActiveSheet();
        $worksheet->getDefaultRowDimension()->setRowHeight(15);
        $worksheet->getDefaultColumnDimension()->setWidth(20);
        $worksheet->getDefaultStyle()->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
		$worksheet->getDefaultStyle()->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_TOP);
		$worksheet->getDefaultStyle()->getAlignment()->setWrapText(true);
		
        $worksheet->mergeCells('A1:G1');
        $worksheet->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
        $worksheet->getStyle('A1')->getFont()->setSize(12)->setBold(true);
        $worksheet->setCellValue('A1', 'Spec Sheet #'.$quote->getId().' - '.$quote->getName());
        $worksheet->mergeCells('A2:G2');
        $worksheet->getStyle('A2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
        $worksheet->getStyle('A2')->getFont()->setSize(12)->setBold(true);
		$worksheet->setCellValue('A2', 'Venue Industries Furniture');
        $worksheet->mergeCells('A3:G3');
        $worksheet->getStyle('A3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
		//$worksheet->setCellValue('A3', '');

        $worksheet->setCellValue('A4', 'Item #');
        $worksheet->setCellValue('B4', 'Photo');
        $worksheet->setCellValue('C4', 'Product/Options');
        $worksheet->getStyle('C4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
        $worksheet->setCellValue('D4', 'Location');
        $worksheet->getStyle('D4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
        $worksheet->setCellValue('E4', 'Note');
        $worksheet->getStyle('E4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
        $worksheet->setCellValue('F4', 'Quantity');
        $worksheet->getStyle('F4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
        $worksheet->setCellValue('G4', 'Base Price');
        $worksheet->getStyle('G4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
        $worksheet->setCellValue('H4', 'Price');
        $worksheet->getStyle('H4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
        $worksheet->getStyle('A4:H4')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('00CCCCCC');
        $worksheet->getColumnDimension('A')->setAutoSize(true);
        $worksheet->getColumnDimension('B')->setWidth(40);
        $worksheet->getColumnDimension('C')->setAutoSize(true);
        $worksheet->getColumnDimension('D')->setAutoSize(true);
        $worksheet->getColumnDimension('F')->setAutoSize(true);
        $worksheet->getColumnDimension('G')->setAutoSize(true);
        $worksheet->getColumnDimension('H')->setAutoSize(true);
		
        $data = $shoppingCart->getCartData(true);
        $baseRow = 6;
        foreach ($data as $r => $item) {
            $row = $baseRow + $r;
			//$worksheet->insertNewRowBefore($row,1);
            $worksheet->getRowDimension($row)->setRowHeight(160);
            $worksheet->setCellValue('A'.$row, $r+1);

	        $objDrawing = new PHPExcel_Worksheet_Drawing();
			$objDrawing->setPath($this->_config->website->website->path.$item['photo']);
			$objDrawing->setCoordinates('B'.$row);
			//$objDrawing->setHeight(170);
			$objDrawing->setOffsetX(10);
			$objDrawing->setOffsetY(10);
			$objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
            
			$optionstring = $item['options'];
			foreach ($optionstring as $key => $value) {
                    $optionsStr .= "$key: $value\n";
			}
			$itemname = $item['itemId'];
            $worksheet->getCell('C'.$row)->setValue("$itemname\n$optionsStr");
            $worksheet->getStyle('C'.$row)->getAlignment()->setWrapText(true);
            $worksheet->getStyle('C'.$row)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
            $worksheet->setCellValue('D'.$row, $item['note']);
            $worksheet->getStyle('D'.$row)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
            $worksheet->setCellValue('E'.$row, $item['memo']);
            $worksheet->getStyle('E'.$row)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
            $worksheet->setCellValue('F'.$row, $item['count']);
            $worksheet->getStyle('F'.$row)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
            $total = $item['count']*$item['price'];
            $worksheet->setCellValue('G'.$row, $item['price']);
            $worksheet->getStyle('G'.$row)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
            $worksheet->getStyle('G'.$row)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
            $worksheet->setCellValue('H'.$row, $item['price']*$item['count']);
            $worksheet->getStyle('H'.$row)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
            $worksheet->getStyle('H'.$row)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
			$optionsStr = '';
			$totalPrice += $item['price']*$item['count'];
        }
        $worksheet->removeRow($baseRow-1,1);
        
		$worksheet->setCellValue('G'.$worksheet->getHighestRow(), 'Total: $');
		$worksheet->getStyle('G'.$worksheet->getHighestRow())->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
		$worksheet->setCellValue('H'.$worksheet->getHighestRow(), $totalPrice);
		$worksheet->getStyle('H'.$worksheet->getHighestRow())->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
		
        ob_end_clean();

        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="'.$quote->getName().'.xls"');

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        ob_end_clean();
        
        $objWriter->save('php://output');
        $objPHPExcel->disconnectWorksheets();
        unset($objPHPExcel);

    }
    
    
    public function excellAction()
    {
    	$this->_helper->getHelper('layout')->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
        
        $localer = new DateLocaler($this->_locale);
        $this->view->registerHelper($localer, 'dateLocaler');
        $user = unserialize($this->_session->currentUser)->getLogin();
        $quoteId = (int) $this->getRequest()->getParam('id');
		if($quoteId > 0) {
			$generator = new RCMS_Object_Generator_Generator();
			$quote = new RCMS_Object_Quote_Quote($quoteId);
			$userCart = new RCMS_Object_Shopping_ShoppingUserCart($quote->getShoppingCartId());
			$cartData = $userCart->getCartData();
            //counting total price of all items in the user's cart
			$totalPrice = 0;
            $totalTax = 0;
            if (is_array($cartData)){
                foreach($cartData as $key => $value) {
                    $totalPrice += $value['price'] * $value['count'];
                }
                //taxes counting
                $totalTax = $this->_countTaxes($userCart);
            }
           
			//assigning varriables
			$this->view->quoteDetails = array(
				'quoteId'         => $quote->getId(),
				'hasPreview'      => ($quote->getContent() != ''),
				'quoteName'       => $quote->getName(),
				'quoteDate'       => strtotime($quote->getDate()),
				'quoteIntMsg'     => $quote->getInternalMessage(),
				'quoteDisclaimer' => $quote->getDisclaimer(),
                'quoteShipping'   => false,
                'quoteValidUntil' => $quote->getValidUntilDate()?strtotime($quote->getValidUntilDate()):strtotime($quote->getDate()),
			);

			//all items in user's cart
            $this->view->quoteDiscount   = $quote->getDiscount();
			$this->view->totalPrice      = $totalPrice;
            $this->view->totalTax        = $totalTax;
			$this->view->cartData        = $cartData;
			$this->view->shoppingConfig  = $this->_shoppingConfig;
			$this->view->cartId          = $userCart->getId();
			$this->view->userMail        = $userCart->getEmail();
			$this->view->quoteEdit       = true;
            $this->view->lastEditedBy    = $quote->getLastEditedBy();
            $this->view->owner			 = $quote->getOwner();//$user;
			$this->view->additionalUserData = array(
                'name'     => $userCart->getName(),
				'address1' => $userCart->getAddress1(),
				'address2' => $userCart->getAddress2(),
                'company'  => $userCart->getCompany(),
				'country'  => $userCart->getCountry(),
				'state'    => $userCart->getState(),
				'city'     => $userCart->getCity(),
				'zip'      => $userCart->getZip(),
				'phone'    => $userCart->getPhone()
			);
		}
		$this->view->websiteUrl = $this->getWebsiteUrl();
		$this->view->path = $this->_config->website->website->path;
        $this->view->datepickerFormat = $localer->datepickerDateFormat;
        $this->view->lang = $this->_locale->getLanguage();
		//for translator
		echo $this->_translator->processScreen($this->view->render($this->getViewScript()));
    }
    
    /**
     * Internal function that updates shipping information
     * @param RCMS_Object_Shopping_ShoppingUserCart $userCart
     * @access private
     * @return void
     */
    private function _updateShipping(RCMS_Object_Shopping_ShoppingUserCart $userCart){
        $shipping = new RCMS_Object_Shipping_Shipping($userCart->getId());
        $shippingCost = $this->getRequest()->getParam('shipping');

        if ($this->getRequest()->getParam('shippingData') == '1'){
            $shippingData = array(
                'firstname' => $userCart->getName(),
                'lastname'  => '',
                'email'     => $userCart->getEmail(),
                'address1'  => $userCart->getAddress1(),
                'address2'  => $userCart->getAddress2(),
                'city'      => $userCart->getCity(),
                'state'     => $userCart->getState(),
                'zip'       => $userCart->getZip(),
                'country'   => $userCart->getCountry(),
                'phone'     => $userCart->getPhone()
            );
        }elseif ($this->getRequest()->getParam('shippingData') == '0'){
            return false;
        }else{
            $shippingData = (array)json_decode(RCMS_Tools_Tools::stripSlashesIfQuotesOn($this->getRequest()->getParam('shippingData')));
        }
        $shipping->setShippingAddress($shippingData);
        $shipping->setShippingService(array('type' => 'manual quote', 'price' => $shippingCost));
        $shipping->saveShipping();

    }
    
    /**
     * Internal function recalculates taxes for taxable products in the cart
     * @param RCMS_Object_Shopping_ShoppingUserCart $userCart
     * @return string in number format xxx.xx
     * @access private
     */
    private function _countTaxes(RCMS_Object_Shopping_ShoppingUserCart $userCart) {
        $cartData = $userCart->getCartData();
        $totalTax = 0;
        $taxRules = unserialize($this->_shoppingConfig['tax-rules']);

        $shipping = new RCMS_Object_Shipping_Shipping($userCart->getId());
        $shippingAddress = $shipping->getShippingAddress();
        unset($shipping);
        
        if (empty($shippingAddress) || $this->_shoppingConfig['shipping_type'] == 'pickup'){
            $shippingAddress = array (
                'country' => $userCart->getCountry(),
                'state' => $userCart->getState()
            );
        }

        foreach ($taxRules as $rule) {
            
            if (($rule['zone'] == $shippingAddress['country'] && !empty($shippingAddress['state']) && in_array($shippingAddress['state'], explode(',', $rule['subzone'])))
                || (($shippingAddress['state']=='null' || empty($shippingAddress['state'])) && in_array($shippingAddress['country'], explode(',', $rule['subzone']))) ){
                
                foreach ($cartData as $key => $value) {
                    $product = new RCMS_Object_Product_Product($value['id']);
                    if ($product->getId() > 0  && $product->getTax()) {
                        $totalTax += $value['count'] * $value['price'] * ($rule['tax'][$product->getTax()] / 100);
                    }
                    unset($product);
                }
            }
        }
        return number_format($totalTax,2,'.','');
    }
}
