<?php
/**
 * Member controller takes care of all members actions
 * such as password changing, etc...
 *
 * @author Eugene I. Nezhuta
 */
class Backend_MemberController extends RCMS_Core_BaseController {

	public function init() {
		parent::init();
        $this->_checkLogin();
    }

	public function chpasswordAction() {
		$this->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		$this->view->chpassForm = new RCMS_Form_MemberChpasswordForm();
		echo $this->_translator->processScreen($this->view->render($this->getViewScript()));
	}

	public function updatepassAction() {
		$this->getHelper('layout')->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		$oldPass      = $this->getRequest()->getParam('oldPass');
		$newPass      = $this->getRequest()->getParam('newPass');
		$newPassAgain = $this->getRequest()->getParam('newPassAgain');
		$user         = unserialize($this->_session->currentUser);
		if(empty($newPass) || empty ($newPassAgain)) {
			echo json_encode(array('error' => '1', 'msg' => 'All fields are required.'));
			exit;
		}
		if($user->getPassword() != md5($oldPass)) {
			echo json_encode(array('error' => '1', 'msg' => 'Old password is incorrect.'));
			exit;
		}
		if($newPass !== $newPassAgain) {
			echo json_encode(array('error' => '1', 'msg' => 'New password and new password confirmation not much.'));
			exit;
		}
		$user->setPassword(md5($newPass));
		$user->save();
		$this->_session->currentUser = serialize($user);
		echo json_encode(array('error' => '0', 'msg' => ''));
	}

}

