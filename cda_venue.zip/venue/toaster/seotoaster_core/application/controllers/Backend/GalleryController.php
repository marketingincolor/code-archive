<?php

class Backend_GalleryController extends RCMS_Core_BaseController
{
    
    public function init()
    {
        $this->_model = new Backend_DeeplinkModel();
        parent::init();
        $this->_checkLogin();
    }

    public function indexAction()
    {
        $this->_helper->getHelper('layout')->disableLayout();
        $gallery = $this->getRequest()->getParam('gallery');
        $this->view->galleryName = $gallery;
		$content = $this->_translator->processScreen($this->view->render($this->getViewScript()));
		$this->_helper->viewRenderer->setNoRender(true);
		echo $content;
    }

    public function coolirisrssAction()
    {
        $this->_helper->getHelper('layout')->disableLayout();

        if ($this->getRequest()->isPost()) {
            $gallery = $this->getRequest()->getParam('gallery');
            $config = unserialize(Zend_Registry::get('config'));
            $path = $config->website->website->path . $config->website->website->galleries;

            if ($gallery != '' && is_dir($path . $gallery) &&is_dir($path . $gallery . '/thumbnails/')) {

                $this->view->images      = RCMS_Tools_FilesystemTools::scanDir($path . $gallery . '/thumbnails/');
                $this->view->galleryName = $gallery;
                $this->view->pathGallery = $this->getWebSiteUrl()
                        . ($pathGallery[(count($pathGallery)-1)]!=''?$pathGallery[(count($pathGallery)-1)]:'galleries')
                        . '/' . $gallery . '/';
                $this->view->websiteUrl  = $this->getWebSiteUrl();
                $coolirisRss             = $this->view->render($this->getViewScript());
                RCMS_Tools_FilesystemTools::saveFile($path . $gallery . '/' . $gallery . ".xml", $coolirisRss);
            }
        }
    }
}