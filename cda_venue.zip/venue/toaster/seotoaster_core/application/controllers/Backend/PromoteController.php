<?php

class Backend_PromoteController extends RCMS_Core_BaseController {

    public function init()
    {
		parent::init();
		$this->_checkLogin();
		$this->_model = new Backend_PromoteModel();
	}

    public function promoteAction()
    {
        $this->_helper->getHelper('layout')->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
        $this->view->services = $this->_model->selectAllService();
        echo $this->_translator->processScreen($this->view->render($this->getViewScript()));
    }

    public function addpingserviceAction()
    {
        $this->_helper->getHelper('layout')->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);

        if ($this->getRequest()->isPost()) {
            $service = trim($this->getRequest()->getParam('service'));
            $id = (int) $this->_model->insertService($service);
            $content = '';
            if ($id > 0) {
                $content .= '<div id="service-'.$id.'" class="service">'."\n";
                $content .= '<div class="service-url"><span title="'.$service.'">'.(strlen($service) < 50 ? $service : substr($service,0,50).'...').'</span></div>'."\n";
                $content .= '<div class="service-edit"><a href="#" onclick="editService('.$id.');return false;">edit</a></div>'."\n";
                $content .= '<div class="service-delete"><a href="#" onclick="deleteSevice('.$id.');return false;">delete</a></div>'."\n</div>\n";
            }
            echo json_encode(array('id' => $id, 'content' => $content));
        }
    }

    public function deleteserviceAction()
    {
        $this->_helper->getHelper('layout')->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);

        if ($this->getRequest()->isPost()) {
            $id = (int) $this->getRequest()->getParam('id');
            $delete = $this->_model->deleteService($id);
            echo json_encode(array('del' => $delete));
        }
    }

    public function updateserviceAction()
    {
        $this->_helper->getHelper('layout')->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);

        if ($this->getRequest()->isPost()) {
            $id = (int) $this->getRequest()->getParam('id');
            $url = trim($this->getRequest()->getParam('service'));
            $update = $this->_model->updateService($url, $id);
            echo json_encode(array('update' => $update, 'service' => $url));
        }
    }

}
