<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of LoginController
 *
 * @author eugene
 */
class LoginController extends RCMS_Core_BaseController
{
	/**
	 * Initialization of the controller
	 *
	 * Here we specify model and other usefull initialization of data
	 */

	public function init() {
		parent::init();
		$this->_model = new LoginModel();
	}
	
	public function indexAction() {
		$recovering = $this->getRequest()->getParam('recovering');
		if($recovering=="success"){
			$this->view->recoveringSuccessMessage = true;
		}
		if(isset($this->_session->isLogged) && (true === $this->_session->isLogged)) {
            $this->_redirect($this->view->websiteUrl);
		}
		
		$userHttpClient = RCMS_Tools_Tools::getUserHttpClient();
		if($userHttpClient == 'msie') {
			$this->view->ieWarning = 'Ahummm...  Internet Explorer is not capable of handling well the latest technologies we chose to use in Seotoaster. Please use any other browsers.';
		}

		$this->view->loginForm = new RCMS_Form_LoginForm();
		if($this->getRequest()->isPost()) {
			if($this->view->loginForm->isValid($this->getRequest()->getParams())) {

				$login = $this->getRequest()->getParam('login');
				$password = $this->getRequest()->getParam('password');
				$userData = $this->_model->selectUserIdByLoginPass($login, $password);
				if(!empty ($userData)) {
					$user = new RCMS_Object_User_User($userData->id);
					$user->setLastLogin(date("Y-m-d H:i:s", time()));
					$user->save();
					$this->_session->memberLogged = ($user->getRoleId() == RCMS_Object_User_User::USER_ROLE_MEMBER);
					$this->_session->currentUser = serialize($user);
					$this->_session->isLogged = true;
					$this->_redirect($this->view->websiteUrl);
				}
				else {
					$this->view->invalidLogin = true;
					$this->view->invalidLoginPas = true;
				}
			}
			else {
				$this->view->invalidLogin = true;
				$this->view->errorElements = $this->view->loginForm->getMessages();
			}
		}
		//getting avialable languages
		$languages = array();
		$langsDir = unserialize(Zend_Registry::get('config'))->website->website->path . 'downloads';
		//var_dump($langsDir); die();
		$langList = RCMS_Tools_FilesystemTools::findFilesByExt($langsDir, RCMS_Object_Parser_LanguageParser::LANG_FILE_EXTENSION);
		if($langList) {
			foreach ($langList as $langItem) {
				$languages[] = str_replace('.lng', '', $langItem);
			}
		}
		$this->view->langs = $languages;
		//end working with languages
		
		$content = $this->_translator->processScreen($this->view->render($this->getViewScript()));
		$this->_helper->viewRenderer->setNoRender(true);
		echo $content;
	}

	public function logoutAction() {
		if(isset($this->_session->isLogged) && (true === $this->_session->isLogged)) {
			$this->_session->unsetAll();
			//$this->_cache(Zend_Cache::CLEANING_MODE_ALL);
		}
		$this->_redirect($this->view->websiteUrl);
	}

	public function setlangAction() {
		$this->_helper->getHelper('layout')->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
		$langId = $this->getRequest()->getParam('langId');
		$this->_session->langId = $langId;
	}

	public function memberAction() {
		$this->_helper->viewRenderer->setNoRender(true);
		if($this->getRequest()->isPost()) {
			$memberLogin    = $this->getRequest()->getParam('memberLoginName');
			$memberPass     = $this->getRequest()->getParam('memberPassword');
			$pageToRedirect = $this->getRequest()->getParam('pageToRedirect');
			$memberData  = $this->_model->selectUserIdByLoginPass($memberLogin, $memberPass);
			if($memberData && is_object($memberData)) {
				if($memberData->role_id == RCMS_Object_User_User::USER_ROLE_MEMBER) {
					$user = new RCMS_Object_User_User($memberData->id);
					$user->setLastLogin(date("Y-m-d H:i:s", time()));
					$user->save();
					$this->_session->memberLogged = true;
					$this->_session->memberLogin  = $memberData->login;
					$this->_session->memberEmail  = $memberData->email;
					$this->_session->memberNick   = $memberData->nickname;
					$this->_session->currentUser  = serialize($user);
					$memberLandingPageData = $this->_model->selectMemberLandingPage();
					$pageToRedirect = (!empty($memberLandingPageData) && $memberLandingPageData['url']) ? $memberLandingPageData['url'] . '.html' : $pageToRedirect;
					$this->_redirectMember($pageToRedirect);
				}
			}
			$this->_session->memberError = 'Sorry!  We can\’t find a member with that log-in information.  Please try again.';
			$this->_redirectMember($pageToRedirect);
		}
	}

	private function _redirectMember($pageToRedirect = '') {
		if($pageToRedirect) {
			//$pageToRedirect = ($pageToRedirect != $this->getWebSiteUrl()) ? $this->getWebSiteUrl() . $pageToRedirect : $this->getWebSiteUrl();
			$this->_redirect($pageToRedirect, array('exit' => true));
		}
		$this->_redirect($this->getWebSiteUrl(), array('exit' => true));
	}

	public function memberlogoutAction() {
		$this->_helper->viewRenderer->setNoRender(true);
		if(isset($this->_session->memberLogged) && (true === $this->_session->memberLogged)) {
			$this->_session->memberLogged = false;
			$this->_session->unsetAll();
			$returnToUrl = $this->getRequest()->getParam('returnTo');
			$this->_redirectMember($returnToUrl);
		}
	}
	
}

