<?php
/**
 * Description of JoinController
 *
 * @author eddt
 */
class JoinController extends RCMS_Core_BaseController {

	public function init() {
		parent::init();
		$this->_model = new JoinModel();
	}
    public function indexAction() {
        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->getHelper('layout')->disableLayout();
        $form = new RCMS_Form_UserForm();
        $form->role->setMultiOptions($this->_model->selectRoles());
        $form->setDecorators(array(
                array('ViewScript', array('viewScript' => 'forms/join.phtml'))
            ));
        $this->view->form = $form;

        if($this->getRequest()->isPost() &&
            $this->view->form->isValid($this->getRequest()->getParams()))
        {
            switch ($this->getRequest()->getParam('submit'))
            {
                case 'Submit':
                    $exist = $this->_model->selectUserByLogin($this->view->form->login->getValue());
                    if(intval($exist) == 0) {
                        $user = new RCMS_Object_User_User();
                        $user->setNickName($this->view->form->nickname->getValue());
                        $user->setLogin($this->view->form->login->getValue());
                        $user->setPassword(md5($this->view->form->password->getValue()));
                        $user->setEmail($this->view->form->email->getValue());
                        $user->setRoleId($this->view->form->role->getValue());
                        $user->setIdSeosambaUser(0);
                        $user->setStatus('active');
                        $user->setLastLogin(date("Y-m-d H:i:s"));
                        $user->setRegDate(date("Y-m-d H:i:s"));
                        $user->setIpAddress($_SERVER['REMOTE_ADDR']);
                        $user->save();
                        //$this->view->form->reset();
                        $this->view->success = 'User added.';
                        
                        /* send email to new user on successful join */
                        $mailText = 'Hello, '.$this->view->form->nickname->getValue().',<br />';
                        $mailText .= '<br />';
                        $mailText .= 'Thank you for signing up for EasySpecSheet!<br />';
                        $mailText .= '<br />';
                        $mailText .= 'When you\'re ready to start speccing furniture for your venue, just go to http://www.easyspecsheet.com and <br />';
                        $mailText .= 'enter the following login information:<br />';
                        $mailText .= '<br />';
                        $mailText .= 'Login (username): '.$this->view->form->login->getValue().'<br />';
                        $mailText .= 'Password: '.$this->view->form->password->getValue().'<br />';
                        $mailText .= '<br />';
                        $mailText .= 'We recommend you keep this information for your records. Logging in gives you access to all the site\'s functionality.<br />';
                        $mailText .= '<br />';
                        $mailText .= 'We hope you enjoy using the system, and if you have any questions or comments, please contact us at http://www.vifurniture.com/contact-us.html<br />';
                        $mailText .= '<br />';
                        $mailText .= 'Thank you,<br />';
						$mailText .= 'The Team at Venue Industries Furniture<br />';
						$mailText .= 'Creators of EasySpecSheet<br />';
						
                        $mail = new RCMS_Object_Mailer_Mailer();
						if($this->_systemConfig['use_smtp']) {
							$mail->setSmtpConfig($this->_systemConfig['smtp_login'], $this->_systemConfig['smtp_password'], $this->_systemConfig['smtp_host']);
							$mail->setTransport(RCMS_Object_Mailer_Mailer::MAIL_TYPE_SMTP);
						}
						$mail->setFrom('Venue Industries Furniture');
						$mail->setFromMail('venuefurniture@gmail.com');
						$mail->setTo($this->view->form->nickname->getValue());
						$mail->setToMail($this->view->form->email->getValue());
						$mail->setSubject('Welcome to EasySpecSheet');
						$mail->setBody($mailText);
						$mail->send();
						
						
						
                        $mail1 = new RCMS_Object_Mailer_Mailer();
						if($this->_systemConfig['use_smtp']) {
							$mail1->setSmtpConfig($this->_systemConfig['smtp_login'], $this->_systemConfig['smtp_password'], $this->_systemConfig['smtp_host']);
							$mail1->setTransport(RCMS_Object_Mailer_Mailer::MAIL_TYPE_SMTP);
						}
						$mail1->setFrom('Venue Industries Furniture');
						$mail1->setFromMail('venuefurniture@gmail.com');
						$mail1->setTo('Cheryl Parrish');
						$mail1->setToMail('cparrish@marketingincolor.com');
						$mail1->setSubject('New ESS User');
						$mail1->setBody('A new user has just joined EasySpecSheet : '.$this->view->form->nickname->getValue().'');
						$mail1->send();
						
                        $mail2 = new RCMS_Object_Mailer_Mailer();
						if($this->_systemConfig['use_smtp']) {
							$mail2->setSmtpConfig($this->_systemConfig['smtp_login'], $this->_systemConfig['smtp_password'], $this->_systemConfig['smtp_host']);
							$mail2->setTransport(RCMS_Object_Mailer_Mailer::MAIL_TYPE_SMTP);
						}
						$mail2->setFrom('Venue Industries Furniture');
						$mail2->setFromMail('venuefurniture@gmail.com');
						$mail2->setTo('John Parrish');
						$mail2->setToMail('jparrish@marketingincolor.com');
						$mail2->setSubject('New ESS User');
						$mail2->setBody('A new user has just joined EasySpecSheet : '.$this->view->form->nickname->getValue().'');
						$mail2->send();
						
                        $mail3 = new RCMS_Object_Mailer_Mailer();
						if($this->_systemConfig['use_smtp']) {
							$mail3->setSmtpConfig($this->_systemConfig['smtp_login'], $this->_systemConfig['smtp_password'], $this->_systemConfig['smtp_host']);
							$mail3->setTransport(RCMS_Object_Mailer_Mailer::MAIL_TYPE_SMTP);
						}
						$mail3->setFrom('Venue Industries Furniture');
						$mail3->setFromMail('venuefurniture@gmail.com');
						$mail3->setTo('Chuck Courter');//Chuck Courter
						$mail3->setToMail('chuckcourter@gmail.com');//chuckcourter@gmail.com
						$mail3->setSubject('New ESS User');
						$mail3->setBody('A new user has just joined EasySpecSheet : '.$this->view->form->nickname->getValue().'');
						$mail3->send();
						
                        /* end send email*/
                        
                    	$this->_redirect($this->view->websiteUrl.'join-success.html');
                    } else {
                        //$this->view->error = 'This user/login already exists - Please try again.';
                        $this->_redirect($this->view->websiteUrl.'join-message.html');
                    }
                    break;
                case 'Update':
                    $login = $this->view->form->login->getValue();
                    $user = new RCMS_Object_User_User($this->view->form->id->getValue());
                    $exist = $this->_model->selectUserByLogin($login);
                    
                    if($exist == 0 || ($exist == 1 && $login == $user->getLogin())) {
                        $user->setNickName($this->view->form->nickname->getValue());
                        $user->setLogin($login);
                        if($user->getPassword() != $this->view->form->password->getValue()) {
                            $user->setPassword(md5($this->view->form->password->getValue()));
                        }
                        $user->setEmail($this->view->form->email->getValue());
                        $user->setRoleId($this->view->form->role->getValue());
                        $user->save();                        
                    } else {                        
                        $this->view->error = 'This login is existed.';
                    }
                    //$this->view->form->reset();
                    break;
            }
        }
        else
        {
            $errors = $this->view->form->getMessages();            
            $this->view->error = $this->generateError($errors);
        }
        $this->view->users = $this->_model->selectAllUser();
		$content = $this->_translator->processScreen($this->view->render($this->getViewScript()));
		$this->_helper->viewRenderer->setNoRender(true);
		echo $content;
    }

	public function welcomeAction() {
        	
	}
	
/**
 *
 * @param <array> $errors
 * @return <string>
 */
    private function generateError($errors)
    {
        if(!empty($errors) && is_array($errors))
        {
            $message = '';
            foreach($errors as $field => $error)
            {
                switch ($field)
                {
                    case 'nickname':
                        $message .= (isset($error['isEmpty'])?"Nickname field can't be empty.\n":'');
                        $message .= (isset($error['regexNotMatch'])?"Nickname field can only contain letters, digits, spaces, '-' and '_'.\n":'');
                        break;
                    case 'login':
                        $message .= (isset($error['isEmpty'])?"Login field can't be empty.\n":'');
                        $message .= (isset($error['regexNotMatch'])?"Login field can only contain letters, digits, '-' and '_'.\n":'');
                        break;
                    case 'password':
                        $message .= (isset($error['isEmpty'])?"Password field can't be empty.\n":'');
                        $message .= (isset($error['stringLengthTooShort'])?"Password field is too short (minimum 5 characters).\n":'');
                        $message .= (isset($error['stringLengthTooLong'])?"Password field is is too long (maximum 255 characters).\n":'');
                        break;
                    case 'email':
                        $message .= (isset($error['isEmpty'])?"Email field can't be empty.\n":'');
                        $message .= (isset($error['regexNotMatch'])?"Email field is wrong.\n":'');
                        break;
                    case 'role':
                        $message .= (isset($error['isEmpty'])?"Role field can't be empty.\n":'');
                        break;
                }
            }
            //return nl2br($message);
            $this->_redirect($this->view->websiteUrl.'join-message.html');
        }
        return '';
    }

}
