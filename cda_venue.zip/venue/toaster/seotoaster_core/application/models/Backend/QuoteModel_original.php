<?php

/**
 * Description of QuoteModel
 *
 * @author NE
 */
class Backend_QuoteModel extends RCMS_Core_BaseModel {

	public function selectAllQuotes() {
		$select = $this->getAdapter()->select()
			->from(
				array('sc' => 'shopping_quote'),
				array(
					'id',
					'name',
					'status',
					'content',
					'date',
                    'last_edited_by'
				)
			);
		return $this->getAdapter()->fetchAll($select);
	}

	public function selectShoppingConfig()
    {
        $sql = $this->_adapter->select()->from('shopping_config');
        return $this->_adapter->fetchPairs($sql);
    }

	public function selectSystemConfig() {
		$sql = $this->_adapter->select()->from('config');
        return $this->_adapter->fetchPairs($sql);
	}

}
