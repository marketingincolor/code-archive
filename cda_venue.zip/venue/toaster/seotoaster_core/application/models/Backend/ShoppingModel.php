<?php
class Backend_ShoppingModel extends RCMS_Core_BaseModel {

    protected $_products = 'shopping_products';
    protected $_group = 'shopping_groups';
    protected $_shoppingconfig = 'shopping_config';
    protected $_config = 'config';
    protected $_category = 'category';
    protected $_template = 'template';
    protected $_shoppingPayPalPayment = 'shopping_paypal_payments';
	protected $_pageImageTable = 'page_image';

    public function selectGroups()
    {
        $sql = $this->_adapter->select()->from($this->_group);
        return $this->_adapter->fetchAll($sql);
    }

    public function selectGroupByName($name)
    {
        $sql = $this->_adapter->select('id, name')->from($this->_group)->where('name = ?', $name);
        return $this->_adapter->fetchAssoc($sql);
    }

    public function insertGroup($name)
    {
        $sql = $this->_adapter->insert($this->_group, array('name' => $name));
        return $this->_adapter->lastInsertId($this->_group);
    }

    public function deleteGroup($id)
    {
        $where = sprintf('id = %d', $id);
        return $this->_adapter->delete($this->_group, $where);
    }

    public function selectAllProducts()
    {
        $sql = $this->_adapter->select()->from($this->_products);
        return $this->_adapter->fetchAll($sql);
    }

    public function selectCategoryProducts()
    {
        $sql = $this->_adapter->select('id')->from($this->_category)->where("name = '" . RCMS_Object_QuickConfig_QuickConfig::$productsCategoryName . "'");
        return $this->_adapter->fetchOne($sql);
    }

    public function insertCategoryProducts($idParent, $name)
    {
        $this->_adapter->insert($this->_category, array('id_parent' => $idParent, 'name' => $name));
        return $this->_adapter->lastInsertId($this->_category);
    }

	/**
	 * Insert image for the page (page teaser image) into page_image table
	 *
	 * @param integer $pageId
	 * @param string $path
	 * @return integer
	 */
	public function insertPageImage($pageId, $path, $name) {
		$this->_adapter->insert(
			$this->_pageImageTable,
			array(
				'page_id' => $pageId,
				'name'    => $name,
				'path'    => $path
			)
		);
		return $this->_adapter->lastInsertId($this->_pageImageTable);
	}

    public function selectTemplateByName($name)
    {
        $sql = $this->_adapter->select('id')->from($this->_template)->where("name = '$name'");
        return $this->_adapter->fetchOne($sql);
    }

    public function selectShoppingConfig()
    {
        $sql = $this->_adapter->select()->from($this->_shoppingconfig);
        return $this->_adapter->fetchPairs($sql);
    }

    public function updateShoppingConfig($name, $value)
    {
        $sql = 'INSERT INTO '.$this->_shoppingconfig.' (name, value) VALUES (?,?)
        ON DUPLICATE KEY UPDATE name = ?, value = ?';
        $this->_adapter->query($sql, array($name, $value, $name, $value));
    }

    public function selectBrands()
    {
        $sql = $this->_adapter->select()->from($this->_products, 'brand')->where("brand <> ''")->distinct();
        return $this->_adapter->fetchAll($sql);
    }

    public function updateGroup($name, $id)
    {
        return $this->_adapter->update($this->_group, array('name' => $name), sprintf("id = %d", $id));
    }

	public function selectAllConfigSettings()
    {
        $select = $this->_adapter->select()->from($this->_config);
        return $this->_adapter->fetchPairs($select);
    }

	public function selectShoppingCartAdminEmail()
    {
		$select = $this->_adapter->select()->from($this->_shoppingconfig,array('value'))->where("name = 'email'")->limit(1);
        return $this->_adapter->fetchOne($select);
	}

    public function insertShoppingPayPalPayment($data)
    {
        return $this->_adapter->insert($this->_shoppingPayPalPayment, $data);
    }

    public function selectTaxRules()
    {
        $sql = $this->_adapter->select()->from($this->_shoppingconfig,array('value'))->where("name = 'tax-rules'")->limit(1);
        return $this->_adapter->fetchOne($sql);
    }
    public function selectTaxLabels()
    {
        $sql = $this->_adapter->select()->from($this->_shoppingconfig,array('value'))->where("name = 'tax-labels'")->limit(1);
        return $this->_adapter->fetchOne($sql);
    }
    /**
     * Get all pages
     * @return <array>
     */
    public function selectAllPages()
    {
        $select = $this->_adapter->select()
			->from(
				array('p' => 'page'),
				array(
					'id',
					'nav_name',
					'url',
					'h1',
					'category_id',
					'is_404page'
				)
			)
			->joinLeft(
				array('c' => 'category'),
				'c.id = p.category_id',
				array(
					'parentCategoryId' => 'id_parent',
				)
			)
			->where('url <> ?', RCMS_Object_QuickConfig_QuickConfig::$draftCategoryUrl)
			->where("url <> 'no-category'");
        return $this->_adapter->fetchAll($select);
    }

	public function selectProductCategoryPage() {
		$select = $this->getAdapter()->select()
			->from(
				array('p' => 'page'),
				array(
					'id'
				)
			)
			->where('nav_name=?', RCMS_Object_QuickConfig_QuickConfig::$productsCategoryName);
		return $this->getAdapter()->fetchOne($select);
	}

}
