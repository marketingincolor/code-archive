<?php

/**
 * Description of ImporterModel
 *
 * @author NE
 */
class Backend_ImporterModel extends RCMS_Core_BaseModel {

}
