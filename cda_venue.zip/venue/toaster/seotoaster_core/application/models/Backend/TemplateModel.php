<?php

class Backend_TemplateModel extends RCMS_Core_BaseModel {
	
	protected $table = 'template';
	
	public function selectAllTemplates()
	{
		$select = $this->_adapter->select()->from($this->table);
		return $this->_adapter->fetchAll($select);
	}
	
	public function selectTemplateExist($name)
	{
        $where = sprintf("name = '%s'", $name);
		$select = $this->_adapter->select()->from($this->table,"COUNT(*)")->where($where);
        return $this->getAdapter()->fetchOne($select);
	}

    public function selectConfig()
    {
        $select = $this->_adapter->select('name, value')->from('config')->where('name IN("img_small","img_medium","img_large")');
        return $this->_adapter->fetchAll($select);
    }

    public function selectTemplateByName($name)
    {
        $where = sprintf("name = '%s'", $name);
		$select = $this->_adapter->select()->from($this->table)->where($where);
        return $this->getAdapter()->fetchAll($select);
    }


    public function selectCurrentTheme()
    {
        $sql = $this->_adapter->select()
        ->from(array('config'=>'config'), array('value'=>'value'))
        ->where("name='current_theme'");
        return $this->_adapter->fetchOne($sql);
    }
}