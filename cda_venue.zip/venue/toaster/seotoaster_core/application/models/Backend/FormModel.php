<?php

/**
 * Description for Form Model
 *
 * @author Pavel Savchuk
 */
class Backend_FormModel extends RCMS_Core_BaseModel {

	private $_pageTableName = 'page';
    private $_variableTableName = 'variable_content';
    

	//@todo move it from here!
	public function selectConfigForImage() {
        $select = $this->_adapter->select('name, value')->from('config')->where('name IN("img_small","img_medium","img_large")');
        return $this->_adapter->fetchAssoc($select);
    }

/**
     * Get all featured areas names
	 *
     * @return <array>
     */
    public function selectFeaturedAreasNames()
    {
        $select = $this->_adapter->select()->from('featured_area',array('name'=>'name'))->order("name ASC");
        $adapter = $this->getAdapter();
        return $adapter->fetchAssoc($select, null, Zend_Db::FETCH_ASSOC);
    }


	/**
     * Get all pages
	 *
     * @return <array>
     */
    public function selectAllPages()
    {
        $select = $this->_adapter->select()->from($this->_pageTableName);
        return $this->_adapter->fetchAll($select);
    }

    public function selectAllVariables()
    {
        $select = $this->_adapter->select()->from($this->_variableTableName, array('name'=>'name') );
        return $this->_adapter->fetchAll($select);
    }

     public function selectAdminEmail()
    {
        $select = $this->getAdapter()->select()->from('config')->where('name = ?', 'admin_email');
        return  $this->getAdapter()->fetchPairs($select);
    }
}

