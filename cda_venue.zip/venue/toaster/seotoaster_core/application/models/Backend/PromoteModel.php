<?php

class Backend_PromoteModel extends RCMS_Core_BaseModel {

    private $_tablePingService = 'ping_service';
    
    public function insertService($service)
    {
        $sql = $this->getAdapter()->insert($this->_tablePingService, array('url' => $service));
        return $this->getAdapter()->lastInsertId($this->_tablePingService);
    }

    public function selectAllService()
    {
        $sql = $this->getAdapter()->select()->from($this->_tablePingService);
        return $this->getAdapter()->fetchAll($sql);
    }

    public function updateService($url, $id)
    {
        return $this->getAdapter()->update($this->_tablePingService, array('url' => $url), 'id = '.$id);
    }

    public function deleteService($id)
    {
        return $this->getAdapter()->delete($this->_tablePingService, 'id = '.$id);
    }

}