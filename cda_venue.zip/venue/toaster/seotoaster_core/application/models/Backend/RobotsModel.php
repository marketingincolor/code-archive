<?php

/**
 * Index model for Login Controller
 *
 * @author eugene
 */
class Backend_RobotsModel extends RCMS_Core_BaseModel {

	
}