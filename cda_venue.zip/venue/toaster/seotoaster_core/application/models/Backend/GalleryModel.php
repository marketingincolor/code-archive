<?php
class Backend_GalleryModel extends RCMS_Core_BaseModel {

}