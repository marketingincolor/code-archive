<?php

/**
 * Description of ContainerModel
 *
 * @author NE
 */
class Backend_InspiredModel extends RCMS_Core_BaseModel {

    protected  $_thesaurusTable = 'thesaurus_en';

      public function getSynonyms($where)
      {
          $select = $this->_adapter->select('DISTINCT ')->from($this->_thesaurusTable,array('the_root'=>'the_root', 'synonym_word'=>'synonym_word'))->where($where)->limit(10);
          return $this->_adapter->fetchAll($select);
      }

      public function checkDataInTable()
      {
          $select = $this->_adapter->select()->from($this->_thesaurusTable)->limit(1);
          return $this->_adapter->fetchRow($select);
      }


}

