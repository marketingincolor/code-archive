<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of PrsculptingModel
 *
 * @author NE
 */
class Backend_PrsculptingModel extends RCMS_Core_BaseModel {

    /**
     * Get all pages
     *
     * @return array
     */
    public function getPages($categoryId = 0) {
		$where = sprintf("c.id_parent = '%s'", $categoryId);
        $select = $this->getAdapter()->select()
	    ->from(
		array('p' => 'page'),
		array(
			'id',
			'navigationName' => 'nav_name',
			'weight',
			'siloId' => 'silo_id'
		)
	    )
	    ->joinLeft(
			array('c' => 'category'),
			'p.category_id=c.id',
			array(
				'categoryName' => 'name',
				'categoryId' => 'id'
			)
	    )
	    ->where($where)
	    ->where('url != \'index\'')
		->where('url != ?', RCMS_Object_QuickConfig_QuickConfig::$draftCategoryUrl)
		->where('is_404page != \'1\'');
	    //->order('p.order ASC');
        return $this->_adapter->fetchAll($select, null, Zend_Db::FETCH_ASSOC);
    }

    public function removeAsCat($siloName) {
	$data = array(
	    'as_cat' => '0'
	);
	$where = sprintf("name='%s'", $siloName);
	$this->getAdapter()->update('silo', $data, $where);
    }

    public function selectSilos() {
	$select = $this->getAdapter()->select()
	    ->from(
		array('s' => 'silo'),
		array(
		    'id',
		    'name',
		    'asCat' => 'as_cat'
	    	)
	    );
	return $this->getAdapter()->fetchAll($select);
    }

    public function selectSiloIdByName($siloName) {
		$select = $this->getAdapter()->select()
			->from(
			array('s' => 'silo'),
			array(
				'id',
			)
			)
			->where('name=?', $siloName);
		return $this->getAdapter()->fetchOne($select);
    }

	public function removeDependencies($siloId) {
		$data = array (
			'silo_id' => 0
	    );
	    $where = sprintf("silo_id=%d", $siloId);
	    return $this->_adapter->update('page', $data, $where);
	}
}

