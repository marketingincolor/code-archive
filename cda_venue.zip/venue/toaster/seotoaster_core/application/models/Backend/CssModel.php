<?php

/**
 * Index model for Login Controller
 *
 * @author eugene
 */
class Backend_CssModel extends RCMS_Core_BaseModel {

private $_configTableName = "config";
	   /**
     * @method Select all from config
     * @param string $parentId
     */
    public function selectAllFromConfig() {
        $select = $this->getAdapter()->select()->from($this->_configTableName);
        $result = $this->_adapter->fetchPairs($select);
        return $result;
    }
}