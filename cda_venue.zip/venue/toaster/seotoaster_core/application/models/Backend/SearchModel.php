<?php
/**
 * Description for Search Model
 *
 * @author Pavel Savchuk
 */
class Backend_SearchModel extends RCMS_Core_BaseModel {

	/**
	 * Selects neccessary data for lucene index document
	 * @return <array>
	 */
public function selectDataForSearchIndex()
	{
	$select = $this->getAdapter()->select()
        ->from(
            array('p' => 'page'),
            array(
                                'id' => 'id',
                                'meta_description' => 'meta_description',
                                'meta_keywords' => 'meta_keywords',
                                'header_title' => 'header_title',
								'short_description' => 'short_description'
            ))
        /*->join(
            array('c' => 'container'),
            'c.page_id = p.id',array()
          )->join(
            array('con' => 'content'),
            'con.id_container = c.id',
			array('value'=>'con.value')
          )*/;
        return $result = $this->_adapter->fetchAll($select, null, Zend_Db::FETCH_ASSOC);
	}


}
