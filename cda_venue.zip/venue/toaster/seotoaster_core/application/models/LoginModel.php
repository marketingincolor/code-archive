<?php

/**
 * LoginModel model for Login Controller
 *
 * @author eugene
 */
class LoginModel extends RCMS_Core_BaseModel {

	protected $_name = 'user';

	/**
	 * Select user id from db using login and password
	 *
	 * @param string $login
	 * @param string $password
	 */
	public function selectUserIdByLoginPass($login, $password) {		
		$where = sprintf("login = '%s' AND password = '%s'", $login, md5($password));
		$select = $this->getAdapter()->select()->from($this->_name)->where($where);
		$result = $this->_adapter->fetchRow($select, null, Zend_Db::FETCH_OBJ);
		return $result;
	}

	public function selectMemberLandingPage() {
		$select = $this->getAdapter()->select()
			->from('page',
				array(
					'url',
					'id'
				)
			)
			->where('page.memlanding = ?', '1');
		return $this->getAdapter()->fetchRow($select);
	}
}

