<?php
/**
 * Join Model for Join Controller
 *
 * @author eddt
 */
class JoinModel extends RCMS_Core_BaseModel {


/**
 *Method selects roles
 * @return <array>
 */
	public function selectRoles() {
		$sql = $this->_adapter->select()->from('role')->where("id <> '3'");
		return $this->_adapter->fetchPairs($sql);
	}
/**
 *Method selects user by login name
 * @param <string> $name
 * @return <array>
 */
	public function selectUserByLogin($name) {
		$where = sprintf("login = '%s'", $name);
		$select = $this->_adapter->select()->from('user',"COUNT(*)")->where($where);
		return $this->_adapter->fetchOne($select);
	}

/**
 *Method selects all users
 * @return <array>
 */
	public function selectAllUser() {
		$sql = $this->getAdapter()->select()
			->from(array('u' => 'user'),
			array('id' => 'id', 'nickname' => 'nickname', 'login' => 'login', 'email' => 'email'))
			->join(array('r' => 'role'), 'r.id = u.role_id', array('role_name'=>'name'))
			->where("role_id <> '3'");
		return $this->_adapter->fetchAll($sql);
	}
}