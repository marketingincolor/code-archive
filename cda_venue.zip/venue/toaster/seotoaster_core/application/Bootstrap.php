<?php

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{
	/**
	 * Init DOCTYPE for views and make sure that we use XHTML DocType declaration
	 * 
	 */
	protected function _initDocType() {
		$this->bootstrap('view');
		$view = $this->getResource('view');
		$view->doctype('XHTML1_STRICT');
	}

	protected function _initIncPath() {
		set_include_path(realpath(APPLICATION_PATH . '/models') . PATH_SEPARATOR . get_include_path());
		set_include_path(realpath(APPLICATION_PATH . '/views/helpers') . PATH_SEPARATOR . get_include_path());
	}

	/**
	 * Init autoloader for our classes
	 * 
	 */
	protected function _initAutoload()
    {
		$resourceLoader = new Zend_Loader_Autoloader_Resource(array(
			'basePath'      => APPLICATION_PATH . '/app',
			'namespace'     => 'RCMS',
			'resourceTypes' => array(
				'core' => array(
					'path'      => 'core',
					'namespace' => 'Core'
				),
				'form' => array(
					'path'      => 'forms',
					'namespace' => 'Form'
				),
				'object' => array(
					'path'      => 'objects',
					'namespace' => 'Object'
				),
				'tools' => array(
					'path'      => 'tools',
					'namespace' => 'Tools'
				),
			)
		));
	   $autoloader = Zend_Loader_Autoloader::getInstance();
	   $autoloader->setFallbackAutoloader(true);
	   $autoloader->suppressNotFoundWarnings(false);
	}

	protected function _initDB()
    {
		$config = new Zend_Config_Ini(APPLICATION_PATH . '/configs/' . SITE_NAME . 'application.ini', 'database');
		$db = Zend_Db::factory($config->database);
		//
		//$db->getProfiler()->setEnabled(true);
		//$profiler = $db->getProfiler();
		//
		Zend_Db_Table_Abstract::setDefaultAdapter($db);
		Zend_Registry::set('db', serialize($db));
    }
    
    protected function _initConfig()
    {
        $xmlConfig = new Zend_Config_Xml(APPLICATION_PATH . '/configs/' . SITE_NAME . 'routesext.xml');
        $frontController = Zend_Controller_Front::getInstance();
        $router = $frontController->getRouter();
        $router->addConfig($xmlConfig, 'routes');

    	$config = new Zend_Config_Ini(APPLICATION_PATH . '/configs/' . SITE_NAME . 'application.ini');
    	Zend_Registry::set('config', serialize($config));
    }


}

