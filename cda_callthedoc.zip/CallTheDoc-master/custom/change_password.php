<?php
include_once('nf/init.php');
$nf = new nfFw('users', 'generic');

$nf->auth->options['message_noauth'] = "You must be logged in to change your password";
$nf->auth->secure(':loggedin:');
$nf->auth->checkAuthorized();

switch (@$_REQUEST['action']) {
	case 'submit_password': {
		$validates = $nf->users->validates();
		$password = $nf->users['password'];

		if (!$validates) {
			$nf->users['password'] = $nf->users['password_confirm'] = '';
			nf::flash("Please double-check all fields colored in red, then press the Submit button again", "error");
			break;
		}

		$nf->users->clearData();

		if (!$nf->auth['id']) {
			nf::flash("Your login credentials could not be found - Please re-login and try again", "error");
			break;
		}

		if (!$password) {
			nf::flash("You must enter a new password", "error");
			break;
		}

		$nf->users['id'] = $nf->auth['id'];
		$nf->users['password'] = md5($password);
		nf::flash("Your password has been changed");
		$nf->users->save();
		$nf->users->clearData();


		break;
	}

	default:
}


// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'change_password';
$nf['content_template'] = 'subpage';
// Main layout template
include($nf->base_dir ."templates/main.php");

