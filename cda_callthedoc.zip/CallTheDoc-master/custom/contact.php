<?php
/* Label: "Contact Us" */

$nf->instantiate('contacts', 'mailing_list list');

// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

switch (@$_REQUEST['action']) {
	case 'save': {
		if (!$nf->contacts->validates()) {
			nf::flash("Please fill in all fields colored in red, then press the Submit button again", "error");
			break;
		}

		nf::flash("Your info has been saved. Thank you for contacting us.");

		/*
		$nf->list->add(
			$nf->contacts['name'],
			$nf->contacts['email'],
			'contacts',
			$nf->contacts['phone']
		);
		*/
		$nf->contacts->save();

		ob_start();
		include($nf->base_dir .'templates/email/contact.php');
		$body = ob_get_clean();
		//mail($nf->settings['contact_email'], 'New Contact Us form submission', $body, 'From: no_reply@website.com');
		$rv = mail($nf->settings['contact_email'], '['. $nf->settings['site_name'] .'] New Contact Us form submission ', $body, 'From: '. $nf->settings['site_name'] .' <'. $nf->settings['from_email'] .'>');

		$nf->contacts->clearData();
		break;
	}

	default:
}



$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'contact';
$nf['content_template'] = 'subpage';
$nf->page_css = array('lightness');
$nf->page_scripts = array('jqueryui');
// Main layout template

include($nf->base_dir ."templates/main.php");

