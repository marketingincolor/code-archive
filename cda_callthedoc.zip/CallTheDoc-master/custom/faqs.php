<?php
/* Label: "FAQs" */
$nf->instantiate('faqs');


$nf->faqs->find('all', array('order' => 'row_order ASC'));

// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'faqs';
$nf['content_template'] = 'subpage';
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");


