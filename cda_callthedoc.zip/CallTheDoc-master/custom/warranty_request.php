<?php
/* Label: "Warranty Request" */

$nf->instantiate(
	'warranty_requests wreqs',
	'customers'
);

// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

$nf->customers->find('id', $nf->auth['foreign_id'], array(
	'fields' => array(
		'customers.*',
		new nfDbExpression('DATE_ADD(move_in_date, INTERVAL 1 YEAR) closing_date'),
		new nfDbExpression('(NOW() > DATE_ADD(move_in_date, INTERVAL 1 YEAR)) closed'),
	)
));

if ($nf->customers['closed'] == 1) {
	nf::redirect('/warranty-closed');
}

switch (@$_REQUEST['action']) {
	case 'save': {
		if (!$nf->wreqs->validates()) {
			nf::flash("Please fill in all fields colored in red, then press the Submit button again", "error");
			break;
		}

		nf::flash("Your info has been saved. You will be contacted shortly.");

		/*
		$nf->list->add(
			$nf->wreqs['name'],
			$nf->wreqs['email'],
			'contacts',
			$nf->wreqs['phone']
		);
		*/
		$nf->wreqs->save();

		ob_start();
		include($nf->base_dir .'templates/email/warranty_request.php');
		$body = ob_get_clean();
		//mail($nf->settings['contact_email'], 'New Contact Us form submission', $body, 'From: no_reply@website.com');
		$rv = mail($nf->settings['contact_email'], '['. $nf->settings['site_name'] .'] New Warranty Request ', $body, 'From: '. $nf->settings['site_name'] .' <'. $nf->settings['from_email'] .'>');

		$nf->wreqs->clearData();
		break;
	}

	default:
}


$nf->wreqs->clearData();
$nf->wreqs->push(array(
	'name' => $nf->customers['name'],
	'address' => $nf->customers['home_address'],
	'email' => $nf->customers['email'],
	'closing_date' => nf::dateFormat($nf->customers['closing_date'], '%B %e %G'),
));


$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'customers/warranty_requests';
$nf['content_template'] = 'subpage';
$nf->page_css = array('lightness');
$nf->page_scripts = array('jqueryui');
// Main layout template

include($nf->base_dir ."templates/main.php");

