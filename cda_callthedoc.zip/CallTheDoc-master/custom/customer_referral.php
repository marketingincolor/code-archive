<?php
/* Label: "Customer Referral" */

$nf->instantiate('referrals', 'mailing_list list', 'members');

// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

switch (@$_REQUEST['action']) {
	case 'save': {
		include($nf->base_dir ."custom/pieces/realpersonlib.php");
		$valid_code = (rpHash($nf->referrals['code']) == $_POST['realPersonHash']);

		if (!$nf->referrals->validates()) {
			nf::flash("Please fill in all fields colored in red, then press the Submit button again", "error");
			break;
		}
		if (!$valid_code) {
			nf::flash("Please re-enter the Security Code", "error");
			break;
		}
		nf::flash("Your referral has been sent. Thank you.");

		$nf->referrals->save();

		ob_start();
		include($nf->base_dir .'templates/email/referral.php');
		
		$body = ob_get_clean();
		//mail($nf->settings['contact_email'], 'New Contact Us form submission', $body, 'From: no_reply@website.com');
		//$rv = mail($nf->settings['contact_email'], '['. $nf->settings['site_name'] .'] New Customer Referral ', $body, 'From: '. $nf->settings['site_name'] .' <'. $nf->settings['from_email'] .'>');
		$rv = mail($nf->referrals['referral_email'], 'Thought You Might Be Interested', $body, 'From: '. $nf->referrals['name'] .' <'. $nf->referrals['email'] .'>');

		$nf->referrals->clearData();
		break;
	}

	default:
}



$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'referrals';
$nf['content_template'] = 'subpage';
$nf->page_css = array('lightness', 'realperson');
$nf->page_scripts = array('realperson', 'jqueryui', 'form_web2');
// Main layout template

include($nf->base_dir ."templates/main.php");

