<?php
/* Label: "Site Map" */

$nf->instantiate('pages', 'pages sitemap', 'subdomains', 'settings');


// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

$nf['current_url'] = $nf->pages['url'];


$nf->sitemap->find('all', array(
	'order' => 'LOWER(title) ASC',
	'conditions' => array(
		'sitemap_exclude !=' => '1',
		'franchisee_id' => '0'
	)
));


$nf['subcontent_template'] = 'sitemap';
$nf['content_template'] = 'subpage';
// Main layout template
include($nf->base_dir ."templates/main.php");

