<?php

$conditions = array(
		'username' => @$_POST['username']
);

if (@$_POST['id']) {
	$conditions[] = array('id !=' => @$_POST['id']);
}


$count = $nf->users->find('count', array(
	'conditions' => $conditions
));

echo json_encode($count);
exit;

