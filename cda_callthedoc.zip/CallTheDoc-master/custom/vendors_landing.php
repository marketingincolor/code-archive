<?php
/* Label: "Vendors Landing" */

$nf->instantiate(
	'pages',
	'settings',
	'vendors',
	'projects',
	'project_bids bids',
	'attached_files attached',
	'uploads'
);


// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");


switch (@$_REQUEST['action']) {
	case 'download': {
		$nf->vendors->find('id', $nf->auth['foreign_id']);
		if ($nf->vendors['id']) { 
			$nf->uploads->find('id', @$_GET['fid']);
			$nf->projects->find('id', @$_GET['pid']);

			$nf->db->quickQuery("INSERT INTO log SET type='download',details=?,relation=?,foreign_id=?",
				('File '. $nf->uploads['filename'] .' from Project '. $nf->projects['name']),
				$nf->auth['type'],
				$nf->auth['foreign_id']
			);
		}

		nf::redirect($nf->uploadFilename(@$_GET['fid']));

		exit;
	}

	case 'save_bid': {
		$nf->projects->find('id', @$_GET['pid']);
		if ($nf->projects->numRows() > 0) {
			$nf->projects->row()->filterByVendor($nf->auth['foreign_id']);
		}
		if ($nf->projects->numRows() == 0) {
			nf::flash('No project is available with that ID', 'error');
			nf::redirect($nf->pages['url']);
		}

		$nf->bids['amount'] = strtr($nf->bids['amount'], array(
			'$' => '',
			',' => ''
		));

		$nf->bids['project_id'] = $nf->projects['id'];
		$nf->bids['vendor_id'] = $nf->auth['foreign_id'];
		$nf->bids->save();

		$nf->db->quickQuery("INSERT INTO log SET type='bid',details=?,relation=?,foreign_id=?",
			('$'. number_format($nf->bids['amount']) .' for Project '. $nf->projects['name']),
			$nf->auth['type'],
			$nf->auth['foreign_id']
		);

		$nf->bids->clearData();
	}

	case 'view_project': {
		$nf->projects->find('id', @$_GET['pid']);
		if ($nf->projects->numRows() > 0) {
			$nf->projects->row()->filterByVendor($nf->auth['foreign_id']);
		}
		if ($nf->projects->numRows() == 0) {
			nf::flash('No project is available with that ID', 'error');
			nf::redirect($nf->pages['url']);
		}

		$view = 'project';

		break;
	}

	default:
}



switch (@$view) {
	case 'project': {
		// Get a row if we don't have one already
		if ($nf->projects->numRows() == 0) {
			$nf->projects->find('id', @$_GET['pid']);
		}

		if ($nf->projects['type'] == 'revision') {
			$nf->projects->parent = $nf->projects->find('id', $nf->projects['parent_id'], array(
				'array_only' => true,
				'update_model_data' => false
			));

			$nf->projects['name_orig'] = $nf->projects['name'];
			$nf->projects['name'] = $nf->projects->parent['name'] .' [Revision "'. $nf->projects['name'] .'"]';;
		}

		$nf->bids->rows_all = $nf->bids->find('all', array(
			'conditions' => array(
				'project_id' => $nf->projects['id'],
				'vendor_id' => $nf->auth['foreign_id']
			),
			'order' => 'date_added ASC',
			'update_model_data' => false
		));

		$nf->attached->find('all', array(
			'order' => 'file_order ASC',
			'conditions' => array('type' => 'project', 'foreign_id' => $nf->projects['id']),
			'fields' => array('upload_id', 'description', 'u.orig_filename'),
			'join' => array('model' => 'uploads u', 'clause' => 'u.id = attached.upload_id')
		));

		break;
	}


	case 'landing':
	default:
		$nf->projects->rows_all = $nf->projects->find('all', array(
			'fields' => array(
				'id',
				'name', 
				'vendors',
				'type',
				'parent_id',
				'date_added',
				'date_changed',
				new nfDbExpression('(SELECT COUNT(*) FROM project_bids pb WHERE pb.project_id = projects.id) bids')
			),
			'conditions' => array(
				'status' => 'Open'
			),
			'order' => 'row_order ASC, date_added ASC',
			'update_model_data' => false
		));
		foreach ($nf->projects->rows_all as $row) {
			$row->filterByVendor($nf->auth['foreign_id']);
		}
		break;
}



$nf['current_url'] = $nf->pages['url'];

$nf['subcontent_template'] = 'vendors/'. nf::coalesce($view, 'landing');
$nf['content_template'] = 'subpage';
$nf->page_scripts = array('nfFuncs', 'nfFuncs', 'json', 'uploadify', 'currency');
$nf->page_css = array('table_ltgray', 'admin_styles_mini');
// Main layout template
include($nf->base_dir ."templates/main.php");


