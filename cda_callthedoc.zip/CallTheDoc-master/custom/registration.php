<?php
/* Label: "Registration" */
$nf->instantiate('members', 'users');
// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

switch (@$_REQUEST['action']) {
	case 'ajax_username_test': {
		include($nf->base_dir ."custom/pieces/ajax_username_test.php");
	}

	case 'save': {
		include($nf->base_dir ."custom/pieces/realpersonlib.php");

		$nf->members->fields = $nf->members->fields_frontend;
		$nf->members->buildFields();

		$valid_form = $nf->members->validates();
		$valid_code = (rpHash($nf->members['code']) == $_POST['realPersonHash']);

		$nf->members->invalidate('code', 'Please re-enter the code');

		if (!$valid_form) {
			nf::flash("Please fill in all fields colored in red, then press the Submit button again", "error");
			break;
		}

		if (!$valid_code) {
			nf::flash("Please re-enter the Security Code", "error");
			break;
		}

		$nf->members->save();
		$nf->users->push(array(
			'username' => $nf->members['email'],
			'password' => md5($nf->members['password']),
			'permissions' => 'user,member',
			'type' => 'member',
			'email' => $nf->members['email'],
			'foreign_id' => $nf->members['id'],
			'landing_page' => 'members'
		));
		$nf->users->save();
		$nf->members['user_id'] = $nf->users['id'];
		$nf->members['membership_id'] = 1021430 + $nf->members['id'];
		$nf->members->save();

		//nf::flash("Your info has been saved. You can now log in:");

		/*
		ob_start();
		include($nf->base_dir .'templates/email/contact.php');
		$body = ob_get_clean();
		//mail($nf->settings['contact_email'], 'New Contact Us form submission', $body, 'From: no_reply@website.com');
		$rv = mail($nf->settings['contact_email'], '['. $nf->settings['site_name'] .'] New Contact Us form submission ', $body, 'From: '. $nf->settings['site_name'] .' <'. $nf->settings['from_email'] .'>');
		*/

		nf::redirect('./ccform');
		break;
	}

	default:
}

$nf->members['code'] = null;
$nf->members['password'] = null;
$nf->members['password_confirm'] = null;

$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'registration';
$nf['content_template'] = 'subpage';
$nf->page_css = array('realperson');
$nf->page_scripts = array('nfFuncs', 'realperson', 'form_web2');
// Main layout template

include($nf->base_dir ."templates/main.php");
