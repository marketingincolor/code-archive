<?php
/* Label: "Standard" */

$nf->instantiate('pages', 'settings');


// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

$nf['current_url'] = $nf->pages['url'];


$nf['subcontent_template'] = 'generic_page';
//$nf['content_template'] = 'subpage_'. nf::coalesce($nf->pages['layout_type'], 'type1');
$nf['content_template'] = 'subpage';
$nf->page_scripts = array();
// Main layout template
include($nf->base_dir ."templates/main.php");

