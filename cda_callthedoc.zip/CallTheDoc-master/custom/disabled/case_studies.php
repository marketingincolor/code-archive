<?php
/* Label: "Case Studies (listing)" */
$nf->instantiate('case_studies');


$nf->case_studies->find('all', array(
	'order' => 'row_order ASC, LOWER(header) ASC'
));


// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'case_studies';
$nf['content_template']  = 'subpage_'. nf::coalesce($nf->pages['layout_type'], 'type1');
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");

