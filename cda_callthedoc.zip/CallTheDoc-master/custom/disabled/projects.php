<?php
/* Label: "Projects" */

$nf->instantiate(
	'projects',
	'project_sponsors',
	'sponsors',
	'project_galleries',
	'project_videos'
);


$nf->projects->rows_per_page = 3;
$nf->projects->page = nf::coalesce(@$_GET['page'], 1);

if (@$_GET['sponsor']) {
	$nf->project_sponsors->find('all', array(
		'conditions' => array('sponsor_id' => $_GET['sponsor'])
	));

	$nf->sponsors->find('id', $_GET['sponsor']);

	$nf->projects->find('all', array(
		'conditions' => array(
			'id' => $nf->project_sponsors->column('project_id')
		)
	));
} else {
	$nf->projects->find('all', array(
		'conditions' => array(
			'completed' => ((@$_GET['arg1'] == 'completed') ? 'Yes' : 'No')
		)
	));
}


$nf['header_link'] = "[ Completed Projects ]";
$nf['header_link_dest'] = $nf['full_url'] = $nf->base_url ."projects/completed/";


// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'projects';
$nf['content_template'] = 'subpage_'. nf::coalesce($nf->pages['layout_type'], 'type1');
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");

