<?php
/* Label: "Galleries" */
$nf->instantiate(
	'attached_files photos',
	'projects',
	'sponsors',
	'galleries',
	'videos',
	'project_sponsors',
	'project_galleries',
	'project_videos'
);

// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

if (
	in_array(@$_GET['type'], array('photo', 'video')) &&
	in_array(@$_GET['source'], array('project', 'sponsor')) &&
	@$_GET['fid']
) {
	// Helper vars
	$type = $nf['type'] = $_GET['type'];
	$source = $nf['source'] = $_GET['source'];
	$fid = $nf['fid'] = $_GET['fid'];

	switch ($type) {
		case 'photo': {
			if ($source == 'project') {
				$nf->projects->find('id', $fid);
				$nf->pages['header'] = "Photo Galleries for ". $nf->projects['title'];

				$project_ids = $fid;
			} else if ($source == 'sponsor') {
				$nf->sponsors->find('id', $fid);
				$nf->pages['header'] = "Photo Galleries for projects sponsored by ". $nf->sponsors['title'];

				$nf->project_sponsors->find('all', array('conditions' => array('sponsor_id' => $fid)));
				$project_ids = $nf->project_sponsors->column('project_id');
			}

			$nf['photo_count'] = $nf->project_galleries->photoCount($project_ids);

			$nf->project_galleries->rows_per_page = 1;
			$nf->project_galleries->page = nf::coalesce(@$_GET['page'], 1);
			$nf->project_galleries->find('all', array(
				'conditions' => array('project_id' => $project_ids),
				'order' => 'row_order ASC',
				'group_by' => 'project_galleries.gallery_id'
			));
			$gallery_id = $nf['gallery_id'] = $nf->project_galleries['gallery_id'];

			$nf['subcontent_template'] = 'gallery_photo';
			break;
		}

		case 'video': {
			$videos = array();
			foreach ($nf->videos->categories as $cat) {
				if ($source == 'project') {
					$nf->projects->find('id', $fid);
					$nf->pages['header'] = "Videos for ". $nf->projects['title'];

					$project_ids = $fid;
				} else if ($source == 'sponsor') {
					$nf->sponsors->find('id', $fid);
					$nf->pages['header'] = "Videos for projects sponsored by ". $nf->sponsors['title'];

					$nf->project_sponsors->find('all', array('conditions' => array('sponsor_id' => $fid)));
					$project_ids = $nf->project_sponsors->column('project_id');
				}

				$videos[$cat] = $nf->project_videos->find('all', array(
					'conditions' => array(
						'videos.category' => $cat,
						'project_id' => $project_ids
					),
					'join' => array(
						'model' => 'videos',
						'clause' => 'video_id = videos.id'
					),
					'order' => 'row_order ASC',
					'array_only' => true
				));
			}

			$nf['videos'] = $videos;


			$nf['subcontent_template'] = 'gallery_video';
			break;
		}

		default:
	}
} else if (in_array(@$_GET['type'], array('photo', 'video')) && @$_GET['gid']) {
	// Helper vars
	$type = $nf['type'] = $_GET['type'];
	$gid = $nf['gid'] = $_GET['gid']; // Either gallery id or video id

	switch ($type) {
		case 'photo': {
			$nf['gallery_id'] = $gid;

			$nf['photo_count'] = $nf->photos->find('count', array(
				'conditions' => array('type' => 'gallery_photo', 'foreign_id' => $gid)
			));

			$nf->galleries->find('id', $gid);
			$nf->pages['header'] = $nf->galleries['title'];

			$nf['subcontent_template'] = 'gallery_photo';
			break;
		}

		case 'video': {
			$nf->videos->find('id', $gid);

			$nf->pages['header'] = "Video: ". $nf->videos['description'];

			$nf['subcontent_template'] = 'single_video';
			break;
		}

		default:
	}
} else if (!@$_GET['gid']) {
	$nf->galleries->find('all');
	foreach ($nf->galleries as $index => $gallery) {
		$nf->photos->find('first', array(
			'conditions' => array(
				'foreign_id' => $gallery['id'],
				'type' => 'gallery_photo'
			),
			'order' => 'file_order ASC'
		));
		$nf->galleries[$index]['thumbnail_img'] = $nf->photos['upload_id'];
	}

	$nf['subcontent_template'] = 'gallery_photo_list';
}


$nf['current_url'] = $nf->pages['url'];
$nf['content_template'] = 'subpage';
$nf->page_scripts = array('scrollto', 'easing', 'swfobject');
// Main layout template
include($nf->base_dir ."templates/main.php");

