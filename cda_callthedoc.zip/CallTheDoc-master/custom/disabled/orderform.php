<?php
/* Label: "Order Form" */
$nf->instantiate('order','order_form_location','mailing_list list','home_page','pages areas');

// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");


switch (@$_REQUEST['action']) {
	case 'save': {
		include_once('includes/recaptchalib.php');


		if (!$nf->order->validates() || !$nf->order_form_location->validates()) {
				nf::flash("Please fill in all fields colored in red, then press the Submit button again");
			break;
		}

    /****** Begin Recaptcha ********/
		/*
    $publickey = "6Le8sb0SAAAAAO-7G9S_I8MZPFt1H8Z0mG40uTxT";
    $privatekey = "6Le8sb0SAAAAAEFwigo4qF3N_iHlfEf1Pl9Hl-jx";

    $recaptcha_resp = recaptcha_check_answer($privatekey,
      $_SERVER["REMOTE_ADDR"],
      @$_POST["recaptcha_challenge_field"],
      @$_POST["recaptcha_response_field"]
    );

    if (!$recaptcha_resp->is_valid) {
			nf::flash("Please enter the correct text in the Captcha field");
			break;
    }
		*/
    /****** End Recaptcha ********/

		nf::flash("Thank you for ordering your testing services with USAMDT. A representative will be in touch with you within one business day.");	
		
		$nf->order->save();
				
		$id = $nf->db->quickQuery("SELECT LAST_INSERT_ID()");				
				
		$idfor = $id[0]['LAST_INSERT_ID()'];
				
		foreach($_POST['count'] as $val => $count_elemet) {
			
			$address = $_POST['data']['order_form_location']['address'];
			$state = $_POST['data']['order_form_location']['state'];
			$zip = $_POST['data']['order_form_location']['zip'];
			$no_of_employees = $_POST['data']['order_form_location']['no_of_employees'];					
			
			$nf->db->quickQuery("INSERT INTO order_form_location SET oder_form_id = '$idfor', address = '$address[$val]', state = '$state[$val]', zip = '$zip[$val]', no_of_employees = '$no_of_employees[$val]'");								
						
		}
			
		ob_start();
		
		include($nf->base_dir .'templates/email/order.php');	
		
		$bodyMssg = ob_get_clean();
		
		$body = "Thank you for ordering your testing services with USAMDT. A representative will be in touch with you within one business day.\n\n We appreciate you choosing USAMDT and we look forward to working with your organization.\n\nSigned\n\nCasey Neubert\n\nCustomer Support Services\n";
					
		mail($nf->order['email'], 'USAMDT Confirmation Email', $body, 'From: website@usamobiledrugtesting.com');		
		mail($nf->settings['contact_email'], 'USAMDT New Order form submission', $bodyMssg, 'From: website@usamobiledrugtesting.com');
//		mail('ana@idxwebdesigns.com,llanos_karlo@yahoo.com', 'USAMDT New Order form submission', $bodyMssg, 'From: website@usamobiledrugtesting.com');
				
		$nf->order->clearData();
		break;
	}

	default:
}


$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'orderform';
$nf['content_template'] = 'subpage';
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");

