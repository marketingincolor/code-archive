<?php
/* Label: "Downloads Home" */
$nf->instantiate('download_categories cats', 'downloads');


//$nf->links->find('all', array('order' => 'row_order ASC'));
//$nf->news->find('all', array('order' => 'date ASC','limit' => 3));

// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

if (@$_GET['arg1']) {
	$nf->cats->find('first', array(
		'conditions' => array(
			'url_segment' => @$_GET['arg1']
		)
	));
	$nf->pages['top_header'] .= ' - '. $nf->cats['name'];
	$nf->downloads->rows_all = $nf->downloads->find('all', array(
		'order' => 'row_order ASC, LOWER(name) ASC',
		'conditions' => array(
			'category_id' => $nf->cats['id']
		),
		'array_only' => true,
	));
	$nf['subcontent_template'] = 'download_category';
} else {
	$nf['subcontent_template'] = 'download_categories';
}

$nf->cats->find('all', array(
	'order' => 'LOWER(name) ASC',
	'array_only' => true,
));



$nf['current_url'] = $nf->pages['url'];
$nf['content_template'] = 'subpage';
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");


