<?php
/* Label: "Feature" */
$nf->instantiate('features');


$nf->features->page = nf::coalesce(@$_GET['page'], 1);
$nf->features->find('id', @$_GET['arg1']);
$nf['title'] = $nf->features['title'];


// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");
$nf->pages['top_header'] = $nf->features['title'];
$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'feature';
$nf['content_template'] = 'subpage_type4';
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");

