<?php
/* Label: "Bulk Mail Opt-out" */
$nf->instantiate('mailing_list list', 'generic');

// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

switch (@$_REQUEST['action']) {
	case 'submit': {
		$nf->list->find('all', array(
			'conditions' => array(
				'address' => $nf->generic['address']
			)
		));

		if ($nf->list->numRows() > 0) {
			foreach ($nf->list as $index => $row) {
				$row['opted_out'] = 'Yes';
			}
			$nf->list->save();

			nf::flash("Your email address is now opted out of future mailings");
		} else {
			nf::flash("Your email address could not be found in the mailing list");
		}
		break;
	}

	default:
}



$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'opt_out';
$nf['content_template'] = 'subpage_type1';
$nf->page_css = array('lightness');
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");

