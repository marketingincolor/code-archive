<?php
/* Label: "Bankruptcy Assessment" */

$nf->instantiate('bankruptcy_assessment assessment');

// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

switch (@$_REQUEST['action']) {
	case 'save': {
		if (!$nf->assessment->validates()) {
			nf::flash("Please fill in all fields colored in red, then press the Submit button again", "error");
			break;
		}

		nf::flash("Your info has been saved. Thank you for contacting us.");

		$nf->assessment->save();

		ob_start();
		include($nf->base_dir .'templates/email/assessment.php');
		$body = ob_get_clean();
		$rv = mail($nf->settings['contact_email'], '['. $nf->settings['site_name'] .'] New Bankruptcy Assessment form submission ', $body, 'From: '. $nf->settings['site_name'] .' <'. $nf->settings['from_email'] .'>');

		$nf->assessment->clearData();
		break;
	}

	default:
}



$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'assessment';
$nf['content_template'] = 'subpage';
$nf->page_css = array('lightness');
$nf->page_scripts = array('jqueryui');
// Main layout template

include($nf->base_dir ."templates/main.php");

