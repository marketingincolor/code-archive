<?php
/* Label: "Testimonials" */

$nf->instantiate('pages', 'settings', 'testimonials');


// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

$nf['current_url'] = $nf->pages['url'];


$nf->testimonials->page = nf::coalesce(@$_GET['page'], 1);
$nf->testimonials->find('all', array(
	'order' => 'row_order ASC'
));


$nf['subcontent_template'] = 'testimonials';
$nf['content_template'] = 'subpage';
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");

