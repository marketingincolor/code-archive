<?php
/* Label: "Realtors Landing" */

$nf->instantiate('pages', 'settings', 'realtors_protected_customers custs');

switch (@$_REQUEST['action']) {
	case 'delete': {
		nf::flash("Customer has been removed from list.");

		$nf->custs->delete($x = array(
			'realtor_id' => $nf->auth['foreign_id'],
			'id' => @$_GET['cid']
		));

		break;
	}

	case 'save': {
		nf::flash("Customer has been added.");

		$nf->custs['realtor_id'] = $nf->auth['foreign_id'];
		$nf->custs->save();
		break;
	}

	default:
}

$nf->custs->find('all', array(
	'fields' => array(
		'id',
		'name',
		'realtor_id',
		new nfDbExpression('DATEDIFF(NOW(), date_added) row_age')
	),
	'conditions' => array(
		'realtor_id' => $nf->auth['foreign_id']
	),
	'order' => 'date_added ASC'
));


// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

$nf['current_url'] = $nf->pages['url'];

$nf['subcontent_template'] = 'realtors_landing';
$nf['content_template'] = 'subpage';
$nf->page_scripts = array('nfFuncs');
$nf->page_css = array('table_ltgray', 'admin_styles_mini');
// Main layout template
include($nf->base_dir ."templates/main.php");

