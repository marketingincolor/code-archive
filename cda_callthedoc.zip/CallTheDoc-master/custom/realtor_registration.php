<?php
/* Label: "Realtor Registration" */

$nf->instantiate('realtors', 'users');

// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

switch (@$_REQUEST['action']) {
	case 'ajax_username_test': {
		include($nf->base_dir ."custom/pieces/ajax_username_test.php");
	}

	case 'save': {
		include($nf->base_dir ."custom/pieces/realpersonlib.php");

		$nf->realtors->fields = $nf->realtors->fields_frontend;
		$nf->realtors->buildFields();

		$valid_form = $nf->realtors->validates();
		$valid_code = (rpHash($nf->realtors['code']) == $_POST['realPersonHash']);

		$nf->realtors->invalidate('code', 'Please re-enter the code');

		if (!$valid_form) {
			nf::flash("Please fill in all fields colored in red, then press the Submit button again", "error");
			break;
		}

		if (!$valid_code) {
			nf::flash("Please re-enter the Security Code", "error");
			break;
		}



		$nf->realtors->save();
		$nf->users->push(array(
			'username' => $nf->realtors['email'],
			'password' => md5($nf->realtors['password']),
			'permissions' => 'user,realtor',
			'type' => 'realtor',
			'email' => $nf->realtors['email'],
			'foreign_id' => $nf->realtors['id'],
			'landing_page' => 'realtors'
		));
		$nf->users->save();
		$nf->realtors['user_id'] = $nf->users['id'];
		$nf->realtors->save();

		nf::flash("Your info has been saved. You can now log in:");


		/*
		ob_start();
		include($nf->base_dir .'templates/email/contact.php');
		$body = ob_get_clean();
		//mail($nf->settings['contact_email'], 'New Contact Us form submission', $body, 'From: no_reply@website.com');
		$rv = mail($nf->settings['contact_email'], '['. $nf->settings['site_name'] .'] New Contact Us form submission ', $body, 'From: '. $nf->settings['site_name'] .' <'. $nf->settings['from_email'] .'>');
		*/


		nf::redirect('/login');
		break;
	}

	default:
}



$nf->realtors['code'] = null;
$nf->realtors['password'] = null;
$nf->realtors['password_confirm'] = null;


$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'realtor_registration';
$nf['content_template'] = 'subpage';
$nf->page_css = array('realperson');
$nf->page_scripts = array('nfFuncs', 'realperson', 'form_web2');
// Main layout template

include($nf->base_dir ."templates/main.php");

