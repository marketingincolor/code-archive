<?php
/* Label: "Members Landing" */

$nf->instantiate(
	'pages', 
	'settings', 
	'users', 
	'members'
);

//$nf->landing_memid = @$_GET['name'];//@$_GET['id'];//$nf->users['id'];
//$nf->members->find('id', $nf->auth['id']);
//$nf->memid = $nf->auth['id'];

switch (@$_REQUEST['action']) {
	case 'member_update': {
		$nf->members->fields = $nf->members->fields_backend;
		$nf->members->buildFields();
		
		//$nf->members->find('id', $nf->members['user_id']);
		//$nf->members->find('user_id', $nf->auth['id']);

		if (!$nf->members['password']) {
			unset($nf->members['password']);
		} else {
			$nf->members['password'] = md5($nf->members['password']);
		}
		
		/*$nf->members->push(array(
			'address' => $nf->members['address'],
			'email' => $nf->members['email'],
			'first_name' => $nf->members['first_name'],
			'last_name' => $nf->members['last_name'],
		));*/

		$nf->members->save();
		
		//update user data
		if ($nf->members['user_id']) {
			$nf->users->find('id', $nf->members['user_id']);
			$nf->users['username'] = $nf->members['email'];
			$nf->users['email'] = $nf->members['email'];
		} 
		if ($nf->members['password']) {
			$nf->users['password'] = $nf->members['password'];
		}
		$nf->users->save();
		$nf->users->clearData();

		$nf->members->clearData();
		nf::flash("Your changes have been saved.");
		//$view = 'edit_account' ;
		break;
	}

	case 'edit_account': {
		$nf->members->find('all', array('conditions' => array('user_id' => $nf->auth['id']),));
		//$nf->members->find('user_id', $nf->auth['id']);
		$view = 'edit_account';
		break;
	}
	
	case 'make_tempid': {
		/*** generate pdf */
		require_once($nf->base_dir ."includes/tcpdf/tcpdf.php");
		require_once($nf->base_dir ."includes/fpdi/fpdi.php");
		
		class PDF extends FPDI {
		    var $_tplIdx;
		    function Header() {
		        if (is_null($this->_tplIdx)) {
		            //$this->setSourceFile($nf->base_dir .'templates/postscript/membership_card.pdf');
					$this->setSourceFile($nf->base_dir .'templates/postscript/member-card-full2.pdf');
		            $this->_tplIdx = $this->importPage(1);
		        }
		        $this->useTemplate($this->_tplIdx);
		    }
		    function Footer() {}
		}
		
		// initiate PDF
		//$pdf = new PDF('L','mm', array(77.5,108.5));
		$pdf = new PDF('L','mm', array(85,217));
		$pdf->setFontSubsetting(false);
		
		$pdf->AddPage();
		
        $pdf->SetFont('freesans', 'B', 10.3);
        $pdf->SetTextColor(0, 0, 0);
		$html = $_GET['user_name'].' <br>'.$_GET['user_id'];
		// writeHTMLCell($w, $h, $x, $y, $html='', $border=0, $ln=0, $fill=0, $reseth=true, $align='', $autopadding=true)
        $pdf->writeHTMLCell(50, 8.6, 52, 50.6, $html, 0, 1, 0, true, 'L', true);
		
		$pdf->Output('member_'.$_GET['user_id'].'.pdf', 'D');

		break;
	}
	default:
}


switch (@$view) {
	case 'edit_account': {
	
		break;
	}
	default:
}

// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

$nf['current_url'] = $nf->pages['url'];

$nf['subcontent_template'] = 'members/'. nf::coalesce(@$view, 'landing');
//$nf['subcontent_template'] = 'landing';
$nf['content_template'] = 'subpage';
$nf->page_scripts = array('nfFuncs');
$nf->page_css = array('table_ltgray', 'admin_styles_mini');
// Main layout template
include($nf->base_dir ."templates/main.php");

