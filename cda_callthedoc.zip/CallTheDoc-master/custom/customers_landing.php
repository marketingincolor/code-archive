<?php
/* Label: "Customers Landing" */

$nf->instantiate(
	'pages',
	'settings',
	'customers',
	'customer_news',
	'attached_files attached',
	'attached_files attached_gallery',
	'customer_change_requests req'
);


$nf->customers->find('id', $nf->auth['foreign_id']);

switch (@$_REQUEST['action']) {
	case 'save_approvals': {

		$nf->req->save();

		$nf->settings->find('first');
		include_once($nf->base_dir .'nf/3rdparty/phpmailer.php');

		$req_ids = $nf->req->column('id');
		$mail_success = true;
		foreach ($req_ids as $req_id) {
			$nf->req->find('id', $req_id);
			if ($nf->req['status'] != 'client_approved') { continue; }

			$nf->req->customer = $nf->customers;
			$pdf = $nf->req->asPDF();

			$mail = new PHPMailer(); // defaults to using php "mail()"
			$mail->LE = "\n";

			$mail->From = $nf->settings['from_email'];
			$mail->FromName = $nf->settings['site_name'];
			$mail->Subject = '['. $nf->settings['site_name'] .'] Change Request #'. $nf->req['index'] .' Document';

			ob_start();
			include($nf->base_dir .'templates/email/change_request_document_cust.php');
			$mail->Body = ob_get_clean();
			$mail->isHTML(false);
			//$mail->MsgHTML($body);

			$mail->AddStringAttachment($pdf, 'change_request_'. $nf->req['index'] .'.pdf', 'base64', 'application/pdf');
			$mail->AddAddress($nf->req->customer['email'], $nf->req->customer['name']);

			// Send to customer
			$mail_success = $mail_success && $mail->Send();



			ob_start();
			include($nf->base_dir .'templates/email/change_request_document_admin.php');
			$mail->Body = ob_get_clean();

			$mail->set('to', array());
			$mail->AddAddress($nf->settings['contact_email'], "");

			// Send to Admin
			$mail_success = $mail_success && $mail->Send();
		}

		if (!$mail_success) {
			nf::flash("Your Change Request Approvals have been saved, but an error occurred while emailing documents to be signed.", 'error');
			nf::flash("You should contact Southern Oaks Homes Administration to obtain the documents", 'info');
		} else {
			nf::flash("Your Change Request Approvals have been saved. To finalize the Change Requests, a document will be emailed to you - Please sign and return the document to the Southern Oaks Homes Administration", 'notice');
		}

		$nf->req->clearData();
		$view = 'change_request';
		break;
	}

	case 'save_change_request': {
		$max_row = array_pop($nf->db->quickQuery("SELECT MAX(`index`) idx FROM customer_change_requests WHERE customer_id=?", $nf->auth['foreign_id']));
		$max = $max_row['idx'];


		foreach ($nf->req as $req) {
			if (!trim($req['request'])) {
				$req->deleteRow();
				continue;
			}

			$max++;
			$req['index'] = $max;
		}

		$nf->req->setColumn('customer_id', $nf->auth['foreign_id']);
		$nf->req->setColumn('date_updated', $nf->db->now());
		$nf->req->setColumn('status', 'new');

		$nf->req->save();
		$nf->req->clearData();

		nf::flash("Your Change Requests have been submitted. You will be contacted shortly with a quoted Price.", 'notice');

		$view = 'change_request';
		break;
	}

	case 'change_request': {
		$view = 'change_request';
		break;
	}

	default:
}



switch (@$view) {
	case 'change_request': {
		$nf->req->rows_all = $nf->req->find('all', array(
			'conditions' => array(
				'customer_id' => $nf->auth['foreign_id']
			),
			'order' => 'date_updated ASC',
			'update_model_data' => false,
			'array_only' => true
		));
	}

	default:
		$nf->customer_news->find('all', array(
			'conditions' => array(
				'customer_id' => $nf->customers['id']
			),
			'order' => 'date DESC',
		));

		$nf->attached->find('all', array(
			'order' => 'file_order ASC',
			'conditions' => array('type' => 'customer', 'foreign_id' => $nf->customers['id']),
			'fields' => array('upload_id', 'description', 'u.orig_filename'),
			'join' => array('model' => 'uploads u', 'clause' => 'u.id = attached.upload_id')
		));
		$nf->attached_gallery->find('all', array(
			'order' => 'file_order ASC',
			'conditions' => array('type' => 'customer_gallery', 'foreign_id' => $nf->customers['id']),
			'fields' => array('upload_id', 'description', 'u.orig_filename'),
			'join' => array('model' => 'uploads u', 'clause' => 'u.id = attached_gallery.upload_id')
		));
}


// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

$nf['current_url'] = $nf->pages['url'];

$nf['subcontent_template'] = 'customers/'. nf::coalesce(@$view, 'landing');
$nf['content_template'] = 'subpage';
$nf->page_scripts = array('nfFuncs', 'prettyphoto');
$nf->page_css = array('table_ltgray', 'prettyphoto');
// Main layout template
include($nf->base_dir ."templates/main.php");

