<?php
$nf->instantiate('users', 'generic');

// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

switch (@$_REQUEST['action']) {
	case 'submit': {
		$nf->users->findByEmail($nf->generic['username']);

		if ($nf->users->numRows() == 0) {
			$nf->generic->clearData();
			nf::flash("That username/email address could not be found", "error");
			break;
		}

		if (!filter_var($nf->users['email'], FILTER_VALIDATE_EMAIL)) {
			$nf->generic->clearData();
			nf::flash("That user account does not have a valid email address, password can't be reset", "error");
			break;
		}

		$generated_pw = nf::generateHash(6);
		$nf->users['password'] = md5($generated_pw);

		ob_start();
		include($nf->base_dir .'templates/email/reset_password.php');
		$body = ob_get_clean();

		$rv = mail($nf->users['email'], '['. $nf->settings['site_name'] .'] Reset Password', $body, 'From: '. $nf->settings['site_name'] .' <'. $nf->settings['contact_email'] .'>');
		
		if (!$rv) {
			$nf->generic->clearData();
			nf::flash("An email error occurred - Your new password could not be reset", "error");
			break;
		}

		$nf->users->save();
		nf::flash("A new password should arrive by email in a few minutes. You may log in below:");
		nf::redirect($nf->base_url .'login');

		break;
	}

	default:
}



$nf['current_url'] = $nf->pages['url'];
$nf['subcontent_template'] = 'reset_password';
$nf['content_template'] = 'subpage';
// Main layout template
include($nf->base_dir ."templates/main.php");

