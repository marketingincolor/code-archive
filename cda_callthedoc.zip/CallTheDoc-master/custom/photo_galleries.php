<?php
/* Label: "Photo Galleries" */

$nf->instantiate(
	'pages', 
	'photo_galleries galleries',
	'attached_files attached',
	'settings'
);

$nf->pages->find('first', array(
	'conditions' => array(
		'url' => @$_GET['addr']
	)
));

$nf->settings->find('first');

$nf->galleries->rows_all = $nf->galleries->find('all', array('order' => 'row_order ASC'));

if (@$_GET['gid']) {
	$nf->galleries->find('id', $_GET['gid']);
} else {
	$nf->galleries->find('first', array(
		'order' => 'row_order ASC'
	));
}

$nf->attached->find('all', array(
	'conditions' => array(
		'type' => 'gallery_photo',
		'foreign_id' => $nf->galleries['id']
	),
	'order' => 'file_order ASC'
));

include($nf->base_dir ."includes/subpage_data.php");
$nf['current_url'] = $nf->pages['url'];

$nf['title'] = $nf->settings['site_title'] . $nf->pages['title'];
$nf['meta_desc'] = $nf->pages['meta_desc'];
$nf['meta_keywords'] = $nf->pages['meta_keywords'];

$nf['subcontent_template'] = 'photo_galleries';
$nf['content_template'] = 'subpage';
// Main layout template
$nf->page_css = array('photo_galleries');
$nf->page_scripts = array('jquery-tools', 'easing');
include($nf->base_dir ."templates/main.php");

