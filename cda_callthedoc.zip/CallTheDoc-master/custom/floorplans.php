<?php
/* Label: "Floor Plans" */

$nf->instantiate(
	'floorplans',
	'floorplans_rooms rooms',
	'floorplans_facts facts'
);


// Get generic CMS page data
include($nf->base_dir ."includes/subpage_data.php");

$nf['current_url'] = $nf->pages['url'];


$nf->floorplans->find('all', array(
	'order' => 'row_order ASC, LOWER(name) ASC',
));

foreach ($nf->floorplans as $floorplan) {
	$floorplan->rooms = $nf->rooms->find('all', array(
		'conditions' => array(
			'floorplan_id' => $floorplan['id']
		),
		'order' => 'row_order ASC',
		'by_id' => true
	));

	$floorplan->facts = $nf->facts->find('all', array(
		'conditions' => array(
			'floorplan_id' => $floorplan['id']
		),
		'order' => 'row_order ASC',
		'by_id' => true
	));
}



$nf['subcontent_template'] = 'floorplans';
$nf['content_template'] = 'subpage';
$nf->page_scripts = array('jqueryui');
// Main layout template
include($nf->base_dir ."templates/main.php");

