<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'mic_callthedoc');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'abracadabra');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '~7MwYB^firg9&k|A~zRFJ|vqIA!UO^6OGw3M+{Ar2[9&j6W}gl*(1Yr=:*$;m%>r');
define('SECURE_AUTH_KEY',  'D_g1=_(8)uV|Ie(?)1r6#k|:Tx^oF&WApOVq}g/^w{lYz`@K0kl+3~2r3q4bb7g8');
define('LOGGED_IN_KEY',    't-A]Q  w.jn_S5~1pEmRL9u!PLs}{}HZSMj$Vmmb#|8(?`97[$t,1T&v_[Gkckd.');
define('NONCE_KEY',        '>eCW,|I`EV[;&-.J)>:]kKqJeBE}DE-&W|to9h>8([P!]8[cy(2F!zRVU48RkA=U');
define('AUTH_SALT',        ')!4o[;bJl(s;0m.8bxV_XopkU246xp^r%!Au2fqnxM*3QUmWT}^^,MV4mOJ`(}h$');
define('SECURE_AUTH_SALT', '?U-qkLvna2fW#UBPB$$,w=zzNV~F(+o!J[|,Y3_sWJ+;DSg[h2R>4?H.4y.~wNl=');
define('LOGGED_IN_SALT',   '1.b`oAC~iPij?@v^P$3x~fPO{dHQog1b3J$&<|N8:mP {f5!V%{a:oeS<{j6nASm');
define('NONCE_SALT',       ':?-vrY]tK1F>+{D[lgoF  Gx_Q5;#^P(@D!_dF@sS-/+X!z~1sdWgFif/f9#}r4M');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress.  A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de.mo to wp-content/languages and set WPLANG to 'de' to enable German
 * language support.
 */
define ('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
