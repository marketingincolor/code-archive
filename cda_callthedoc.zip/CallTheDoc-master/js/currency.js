$(document).ready(function() {
	(function() {
		this.digitsOnly = function() {
			this.value = this.value.replace(/\.\d+$/,'');
			this.value = this.value.replace(/[^0-9]/g,'');
		}

		this.toCurrency = function() {
			// Currency conversion script from http://javascriptsource.com
			num = this.value.toString().replace(/\$|\,/g,'');
			if(isNaN(num))
			num = "0";
			sign = (num == (num = Math.abs(num)));
			/*
			num = Math.floor(num*100+0.50000000001);
			cents = num%100;
			num = Math.floor(num/100).toString();
			if(cents<10)
			cents = "0" + cents;
			*/
			num = num.toString();
			for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
			num = num.substring(0,num.length-(4*i+3))+','+
			num.substring(num.length-(4*i+3));
			//this.value = (((sign)?'':'-') + '$' + num + '.' + cents);
			this.value = (((sign)?'':'-') + '$' + num);
		}

		$(".currency")
			.focus(this.digitsOnly)
			.click(this.digitsOnly)
			.keyup(this.digitsOnly)
			.blur(this.toCurrency);
	})()
});

