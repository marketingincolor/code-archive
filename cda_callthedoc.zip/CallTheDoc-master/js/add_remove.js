$(document).ready(function() {
	function id_to_desc($select, id) {
		return($select.find('option[value="'+ id +'"]').text());
	}
	function rows_apply_zebra($table) {
		$("tr:even", $table).removeClass("even odd").addClass('even');
		$("tr:odd", $table).removeClass("even odd").addClass('odd');
	}

	$(".button_remove_additional").live('click', function() {
		var section = $(this).attr('rel');
		var $row = $(this).parents('tr:eq(0)');
		var $input = $("input[rel='"+ section +"']");
		var $table = $row.parents('table:eq(0)');

		var id = parseInt($row.find('span.id').text());
		var values = PHP_Unserialize($input.val()); 
		var index = values.indexOf(id);

		if (values.indexOf(id) != -1) { 
			values.splice(index, 1);
			$input.val(serialize(values));
		}

		$row.remove();

		rows_apply_zebra($table);

		return(false);
	});

	$(".button_add_additional").click(function() {
		var section = $(this).attr('rel');
		var $select = $("select[rel='"+ section +"']");
		var $table = $("table[rel='"+ section +"']");
		var $input = $("input[rel='"+ section +"']");
		var values = PHP_Unserialize($input.val());

		var id = parseInt($select.val());
		var desc = id_to_desc($select, id);
		if (!id) { return(false); }
		if (values.indexOf(id) != -1) { return(false); }

		$select.val('');

		values.push(id);
		$input.val(serialize(values));

		var $new_row = $table.find('tr.template').clone().removeClass('template')
			.appendTo($table)
			.find('span.id').text(id).end()
			.find('span.text').text(desc).end();

		rows_apply_zebra($table);

		return(false);
	});
});


