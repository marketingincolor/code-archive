<?php
include('../nf/init.php');
$nf = new nfFw(
	'pages',
	'page_tabs',
	'attached_files attached',
	'download_categories cats',
	'users',
	'generic'
);

$data_desc = "Page";
$data_desc_plural = "Pages";

$nf->auth->secure();
$nf->auth->checkAuthorized();

switch (@$_REQUEST['action']) {
	case 'load_tab': {
		$index = @$_POST['index'];
		$nf->page_tabs->data[$index] = (array)@$_POST['data']['page_tabs'][$index];
		$nf->page_tabs->index = $index;
		include($nf->base_dir ."templates/admin/pieces/page_tab.php");
		exit;
	}

	case 'edit': {
		$nf['page'] = $nf->pages->find('first', array('conditions' => array(
			'or' => array(
				'id' => @$_GET['id'],
				'url' => @$_GET['url']
			)
		)));
		break;
	}

	case 'new': {
		$nf->pages['name'] = 'New page';
		$nf->pages['layout_type'] = 'type1';
		break;
	}

	case 'delete': {
		$model = $nf->pages;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}


	case 'save': {
		$id = @$nf->pages['id'];
		$nf->pages['type'] = 'page';
		$nf->pages->save();
		$nf->attached->saveFromJSON('page', $id);

		$nf->page_tabs->delete(array(
			'page_id' => $nf->pages['id']
		));
		$nf->page_tabs->setColumn('id', null);
		$nf->page_tabs->save();

		/*
		$nf->page_galleries->delete(array('page_id' => $nf->pages['id']));
		$nf->page_galleries->save();
		*/

		/*
		$nf->page_videos->delete(array('page_id' => $nf->pages['id']));
		$nf->page_videos->save();
		*/

		nf::flash("Changes have been saved.");
		break;
	}

	default:
}


$nf->pages->rows_all = $nf->pages->find('all', array(
	'order' => 'LOWER(name) ASC',
	'update_model_data' => false,
	'array_only' => 'true',
));


if ($nf->pages->numRows() > 0) {
	$nf->attached->find('all', array(
		'order' => 'file_order ASC',
		'conditions' => array('type' => 'page', 'foreign_id' => $nf->pages['id']),
		'fields' => array('upload_id', 'description', 'u.orig_filename'),
		'join' => array('model' => 'uploads u', 'clause' => 'u.id = attached.upload_id')
	));

	$nf->page_tabs->find('all', array(
		'conditions' => array(
			'page_id' => $nf->pages['id']
		),
		'order' => 'row_order ASC'
	));

	$nf->cats->rows_all = $nf->cats->find('all', array(
		'order' => 'LOWER(name) ASC',
		'array_only' => true,
	));

	/*
	$nf->page_galleries->find('all', array(
		'order' => 'row_order ASC, LOWER(name) ASC',
		'conditions' => array(
			'page_galleries.page_id' => $nf->pages['id']
		),
		'fields' => array('page_galleries.*', 'galleries.name'),
		'join' => array(
			'type' => 'left',
			'model' => 'galleries',
			'clause' => 'page_galleries.gallery_id = galleries.id'
		)
	));
	$nf->galleries->find('all', array('order' => 'LOWER(name) ASC'));

	$nf->page_videos->find('all', array(
		'order' => 'row_order ASC, LOWER(description) ASC',
		'conditions' => array(
			'page_videos.page_id' => $nf->pages['id']
		),
		'fields' => array('page_videos.*', 'videos.description'),
		'join' => array(
			'type' => 'left',
			'model' => 'videos',
			'clause' => 'page_videos.video_id = videos.id'
		)
	));

	$nf->videos->find('all', array('order' => 'LOWER(description) ASC'));
	*/
}


$nf['subcontent_template'] = 'pages';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs', 'colorpicker', 'scrollto');
$nf->page_css = array('smoothness', 'colorpicker');
include($nf->base_dir ."templates/admin/main.php");

