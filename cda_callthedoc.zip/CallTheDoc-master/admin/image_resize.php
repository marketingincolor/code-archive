<?php
if (@$_POST['PHPSESSID']) { $_COOKIE['PHPSESSID'] = $_POST['PHPSESSID']; }
include('../nf/init.php');
$nf = new nfFw('images');

$nf->auth->checkAuthorized();

$tmp_dir = $nf->base_dir .'tmp/';

function remove_old_images() {
	$extensions = array('gif', 'png', 'jpg', 'jpeg');
	$pattern = $GLOBALS['tmp_dir'] . '/*.{'. implode(',', $extensions) .'}';
	$files = glob($pattern, GLOB_BRACE);
	foreach($files as $file) {
		//remove files older than a day
		if (filemtime($file) < time() - (24 * 60 *60)) {
			@unlink($file);
		}
	}
}


switch (@$_REQUEST['action']) {
	case 'resize_image': {

		$tmp_file = $tmp_dir . nf::safeFilename(@$_POST['hash']) .'.'. nf::safeFilename(@$_POST['ext']);

		$res = $nf->upload->imageLoadAsResource($tmp_file);
		$nf->upload->resource = $res;
		$nf->upload->imageScale(@$_POST['width'], @$_POST['height'], 'fill', array());

		//header('Content-Disposition: attachment,filename="'. @$_POST['filename'] .'.'. @$_POST['ext'] .'"');

		$nf->upload->output(array(
			'output_type' => @$_POST['ext']
		));

		unlink($tmp_file);

		exit;
	}

	case 'new_image': {
		$filename = @$_FILES['Filedata']['name'];
		$message = '';
		$hash = '';
		$ext = '';

		if ($filename) {
			$hash = nf::generateHash(20);
			$ext = nf::fileExt($filename, false);

			$rv = @move_uploaded_file($_FILES['Filedata']['tmp_name'], $tmp_dir . $hash .'.'. $ext);
			if (!$rv) {
				echo json_encode(array('message' => "Error: Uploaded file couldn't be saved, try again"));
				exit;
			}
		} else {
			$message = "An error occurred uploading the file, please try again";
		}

		echo json_encode(array(
			'filename' => urlencode($filename),
			'hash' => $hash,
			'ext' => $ext,
			'message' => $message,
		));
		exit;
	}

	default:
}

remove_old_images();


$nf['subcontent_template'] = 'image_resize';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs');
$nf->page_css = array('lightness');
include($nf->base_dir ."templates/admin/main.php");

