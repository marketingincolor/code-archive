<?php
include('../nf/init.php');
$nf = new nfFw(
	'customers',
	'customer_news news'
);

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Customer News Item";
$data_desc_plural = "Customer News";

switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf['outlet'] = $nf->news->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->news['name'] = "New $data_desc";

		$nf->news['customer_id'] = $_GET['customer_id'];

		break;
	}

	case 'delete': {
		$model = $nf->news;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'save': {
		$nf->news->save();
		$nf->news->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	default:
}


if (@$_GET['customer_id']) {
	$nf->customers->rows_all = $nf->customers->find('all', array(
		'order' => 'LOWER(last_name) ASC',
		'conditions' => array(
			'id' => $_GET['customer_id']
		)
	));
} else {
	$nf->customers->rows_all = $nf->customers->find('all', array(
		'order' => 'LOWER(last_name) ASC'
	));
}

foreach ($nf->customers->rows_all as $customer) {
	$customer['news'] = $nf->news->find('all', array(
		'conditions' => array(
			'customer_id' => $customer['id']
		),
		'order' => 'date DESC',
		'update_model_data' => false
	));
}


if ($nf->news['customer_id']) {
	$nf->customers->find('id', $nf->news['customer_id']);
}



$nf['subcontent_template'] = 'customer_news';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

