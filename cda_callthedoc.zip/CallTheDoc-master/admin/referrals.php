<?php
include('../nf/init.php');
$nf = new nfFw('referrals');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "referral";
$data_desc_plural = "referrals";

switch (@$_REQUEST['action']) {
	case 'delete': {
		$model = $nf->referrals;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'view': {
		$nf->referrals->find('id', @$_GET['id']);
		break;
	}


	default:
}


$nf->referrals->rows_all = $nf->referrals->find('all', array(
	'order' => 'date_added DESC, LOWER(name) ASC',
	'array_only' => true,
	'update_model_data' => false,
));



$nf['subcontent_template'] = 'referrals';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

