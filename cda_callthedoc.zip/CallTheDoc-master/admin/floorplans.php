<?php
include('../nf/init.php');
$nf = new nfFw(
	'floorplans',
	'floorplans_rooms rooms',
	'floorplans_facts facts'
);

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Floor Plan";
$data_desc_plural = "Floor plans";

switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf->floorplans->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->floorplans['name'] = "New $data_desc";
		break;
	}

	case 'delete': {
		$model = $nf->floorplans;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'save': {
		$nf->floorplans->save();


		// Remove blank rows
		foreach ($nf->rooms as $row) {
			if (!$row['name'] && !$row['sqfeet']) { $row->deleteRow(); }
		}

		$nf->rooms->delete(array('floorplan_id' => $nf->floorplans['id']));
		$nf->rooms->setColumn('floorplan_id', $nf->floorplans['id']);
		$nf->rooms->save();


		// Remove blank rows
		foreach ($nf->facts as $row) {
			if (!$row['fact']) { $row->deleteRow(); }
		}

		$nf->facts->delete(array('floorplan_id' => $nf->floorplans['id']));
		$nf->facts->setColumn('floorplan_id', $nf->floorplans['id']);
		$nf->facts->save();


		$nf->floorplans->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	case 'save_order': {
		$nf->floorplans->save();
		$nf->floorplans->clearData();
		nf::flash("$data_desc order has been saved.");
		break;
	}


	case 'reorder': {
		$nf['section'] = 'reorder';
		break;
	}

	default:
}

$nf->floorplans->rows_all = $nf->floorplans->find('all', array(
	'order' => 'row_order ASC, LOWER(name) ASC',
	'array_only' => true,
	'update_model_data' => false
));

if ($nf->floorplans->numRows() > 0) {
	$nf->rooms->find('all', array(
		'conditions' => array(
			'floorplan_id' => $nf->floorplans['id']
		),
		'order' => 'row_order ASC',
		'by_id' => true
	));

	$nf->facts->find('all', array(
		'conditions' => array(
			'floorplan_id' => $nf->floorplans['id']
		),
		'order' => 'row_order ASC',
		'by_id' => true
	));
}


$nf['subcontent_template'] = 'floorplans';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs', 'add_remove');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

