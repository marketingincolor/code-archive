<?php

#
# cron job syntax: (dependent on server config)
# php /CallTheDoc/admin/email_blast_cron.php?emails=100
#

include('../nf/init.php');
include('../nf/3rdparty/phpmailer.php');
$nf = new nfFw('email_blasts', 'email_blasts_contacts');

$number_emails = is_int($_GET['emails']) ? $_GET['emails'] : 50; # of default messages to send


$nf->email_blasts->rows_all = $nf->email_blasts->find('all', array(
    'where' => 'status != "sent" ',
	'order' => 'id ASC',
    'limit' => 1,
	'array_only' => true,
	'update_model_data' => false
));



# if there is an email blast to be sent
if ( $nf->email_blasts->rows_all ) {
	
	# Set email variables
	$mail = new PHPMailer(); // defaults to using php "mail()"
	$mail->AddReplyTo("webmaster@".$_SERVER['HTTP_HOST'], '');
	$mail->SetFrom("webmaster@".$_SERVER['HTTP_HOST'], '');
	$mail->Subject = $nf->email_blasts->rows_all[0]['subject'];
	$mail->MsgHTML($nf->email_blasts->rows_all[0]['body']);

	# query for contacts 
    $nf->email_blasts_contacts->rows_all = $nf->email_blasts_contacts->find('all', array(
        'where' => 'id >= '.$nf->email_blasts->rows_all[0]['status'],
    	'order' => 'id ASC',
        'limit' => $number_emails,
    	'array_only' => true,
    	'update_model_data' => false
    ));
    
	# query for the last contact's ID#
    $nf->email_blasts_contacts->last_row = $nf->email_blasts_contacts->find('last', array(
    	'order' => 'id DESC',
        'limit' => 1,
    	'array_only' => true,
    	'update_model_data' => false
    ));
    $nf->email_blasts->last_contact_id = $nf->email_blasts_contacts->last_rowl[0]['id'];
    
    # add addresses
    $i=0;
    foreach ((array)$nf->email_blasts_contacts->rows_all as $index => $row) {
        $i++;
        if($i <= $number_emails) { # send only max number of emails at a time
            $mail->AddAddress($row['address'], $row['name']);
            #$mail->AddBCC($row['address'], $row['name']); // smtp required for BCC
            if($row['id'] == $nf->email_blasts_contacts->last_row[0]['id']){
                # if reached the last email -- finish email blast and update table
                $db_query = $nf->db->quickQuery("UPDATE email_blasts SET status = 'sent' WHERE id = '".$nf->email_blasts->rows_all[0]['id']."' ");
            }
        }
    }

	# Send email
    if(!$mail->Send()) {
        echo "Mailer Error: " . $mail->ErrorInfo;
    } else {
        echo "Message sent!";
    }
}

?>
