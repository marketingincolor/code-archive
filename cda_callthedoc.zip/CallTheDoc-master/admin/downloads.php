<?php
include('../nf/init.php');
$nf = new nfFw('download_categories cats', 'downloads', 'attached_files attached');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Download";
$data_desc_plural = "Downloads";

switch (@$_REQUEST['action']) {
	case 'save_cat': {
		$nf->cats->save();
		$nf->cats->clearData();

		nf::flash("Category name has been changed.");
		break;
	}

	case 'edit': {
		$nf->downloads->find('first', array(
			'conditions' => array('downloads.id' => @$_GET['id']),
			'fields' => 'downloads.*, u.filename',
			'join' => array(
				'model' => 'uploads u',
				'type' => 'left',
				'clause' => 'u.id={self}.upload_id'
			),
		));
		break;
	}

	case 'new': {
		$nf->downloads['name'] = "New $data_desc";
		break;
	}

	case 'delete': {
		$model = $nf->downloads;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'save': {
		$nf->downloads->save();
		$nf->downloads->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	case 'save_order': {
		$nf->downloads->save();
		$nf->downloads->clearData();
		nf::flash("$data_desc order has been saved.");
		break;
	}


	case 'reorder': {
		$nf['section'] = 'reorder';
		break;
	}

	default:
}

$nf->cats->find('id', @$_REQUEST['cat_id']);

$nf->downloads->rows_all = $nf->downloads->find('all', array(
	'order' => 'row_order ASC, LOWER(name) ASC',
	'conditions' => array(
		'category_id' => $nf->cats['id']
	),
	'fields' => 'downloads.*, u.filename',
	'join' => array(
		'model' => 'uploads u',
		'type' => 'left',
		'clause' => 'u.id={self}.upload_id'
	),
	'array_only' => true,
	'update_model_data' => false
));



$nf['subcontent_template'] = 'downloads';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

