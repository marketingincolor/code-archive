<?php
include('../nf/init.php');
$nf = new nfFw(
	'realtors',
	'users'
);

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Realtor";
$data_desc_plural = "Realtors";


switch (@$_REQUEST['action']) {
	case 'ajax_username_test': {
		include($nf->base_dir .'custom/pieces/ajax_username_test.php');
	}

	case 'edit': {
		$nf->realtors->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->realtors['first_name'] = "New";
		$nf->realtors['last_name'] = "Realtor";
		break;
	}

	case 'delete': {
		$nf->realtors->find('id', @$_GET['id']);
		$user_id = $nf->realtors['user_id'];
		$model = $nf->realtors;
		$nf->realtors['name'] = $nf->realtors['first_name'] .' '. $nf->realtors['last_name'];
		include(dirname(__FILE__) .'/pieces/delete.php');

		$nf->users->delete(array(
			'id' => $user_id
		));
		break;
	}


	case 'save': {
		$nf->realtors->fields = $nf->realtors->fields_backend;
		$nf->realtors->buildFields();

		if (!$nf->realtors['password']) {
			unset($nf->realtors['password']);
		} else {
			$nf->realtors['password'] = md5($nf->realtors['password']);
		}

		$validates = $nf->realtors->validates();

		if (!$nf->realtors['id'] && !$nf->realtors['password']) {
			$nf->realtors->invalidate('password', 'The Realtor account cannot be created without a password');
		}

		if (!$validates) {
			nf::flash("Please fill in all fields colored in red, then press the Submit button again", "error");
			break;
		}

		$nf->realtors->save();

		/*** User */
		if ($nf->realtors['user_id']) {
			$nf->users->find('id', $nf->realtors['user_id']);

			$nf->users['username'] = $nf->realtors['email'];
			$nf->users['email'] = $nf->realtors['email'];
		} else {
			$nf->users->push(array(
				'username' => $nf->realtors['email'],
				'permissions' => 'user,realtor',
				'type' => 'realtor',
				'email' => $nf->realtors['email'],
				'foreign_id' => $nf->realtors['id'],
				'landing_page' => 'realtors'
			));
		}

		if ($nf->realtors['password']) {
			$nf->users['password'] = $nf->realtors['password'];
		}

		$nf->users->save();
		/***/

		$nf->realtors['user_id'] = $nf->users['id'];
		$nf->realtors->save();

		$nf->realtors->clearData();


		nf::flash("Changes have been saved.");
		break;
	}

	default:
}

$nf->realtors->rows_all = $nf->realtors->find('all', array(
	'order' => 'LOWER(last_name) DESC',
	'update_model_data' => false,
	'as_array' => true,
));



if ($nf->realtors->numRows() > 0) {
	$nf->realtors['password'] = null;
}


$nf['subcontent_template'] = 'realtors';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array();
$nf->page_css = array();
include($nf->base_dir ."templates/admin/main.php");

