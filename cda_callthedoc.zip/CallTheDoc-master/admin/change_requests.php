<?php
include('../nf/init.php');
$nf = new nfFw(
	'settings',
	'customers',
	'customer_change_requests req'
);

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = 'Change Request';

switch (@$_REQUEST['action']) {
	case 'quote_price': {
		$view = 'quote_price';
		break;
	}

	case 'save_quote_price': {
		$nf->req['status'] = 'quoted';
		$nf->req['date_updated'] = $nf->db->now();
		$nf->req['price'] = strtr($nf->req['price'], array(
			'$' => '',
			',' => ''
		));

		$nf->req->save();
		$nf->req->find('id', $nf->req['id']);

		$nf->customers->find('id', $nf->req['customer_id']);
		$nf->settings->find('first');

		ob_start();
		include($nf->base_dir .'templates/email/change_request_price_quote.php');
		$body = ob_get_clean();
		$rv = mail($nf->customers['email'], '['. $nf->settings['site_name'] .'] Price quote for your Change Request ', $body, 'From: '. $nf->settings['site_name'] .' <'. $nf->settings['from_email'] .'>');
		
		$nf->req->clearData();

		nf::flash("The Quoted Price has been submitted and Customer has been contacted.");
		$view = 'list';
		break;
	}

	case 'get_pdf': {
		$nf->req->find('id', @$_GET['id']);
		$nf->req->customer = $nf->customers->find('id', $nf->req['customer_id']);
		$pdf = $nf->req->asPDF("change_request_". $nf->req['index'] .".pdf");
		exit;
	}

	case 'cancel': {
		$nf->req->find('id', @$_GET['id']);
		$nf->req['status'] = 'admin_canceled';
		$nf->req->save();
		$view = 'list';
		break;
	}

	case 'complete': {
		$nf->req->find('id', @$_GET['id']);
		$nf->req['status'] = 'completed';
		$nf->req->save();
		$view = 'list';
		break;
	}

	case 'delete': {
		$model = $nf->req;
		include(dirname(__FILE__) .'/pieces/delete.php');
		$view = 'list';
		break;
	}


	case 'list':
	default:
		$view = 'list';
}




switch (@$view) {
	case 'quote_price': {
		$nf->req->find('id', @$_GET['id']);
		$nf->customers->find('id', $nf->req['customer_id']);
		break;
	}

	case 'list':
	default:
		$nf->req->rows_all = $nf->req->find('all', array(
			'fields' => array(
				'req.*',
				'(SELECT CONCAT_WS(" ",c.first_name,c.last_name) FROM customers c WHERE c.id=req.customer_id) customer_name'
			),
			'order' => 'status, date_updated DESC',
		));
}

$nf['subcontent_template'] = 'change_requests';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs', 'currency');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

