<?php
include('../nf/init.php');
$nf = new nfFw(
	'projects',
	'project_bids bids',
	'vendors',
	'vendor_categories',
	'attached_files attached'
);

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Project";
$data_desc_plural = "Projects";

switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf->projects->find('id', @$_GET['id']);
		$view = 'edit';

		$nf->projects['send_vendor_email'] = (($nf->projects['type'] == 'project') ? 'project_updated' : 'revision_updated');
		break;
	}

	case 'view_bids': {

		$view = 'view_bids';

		break;
	}

	case 'new': {
		$nf->projects['name'] = "New $data_desc";
		$nf->projects['send_vendor_email'] = 'project_new';
		$nf->projects['status'] = 'Open';
		$nf->projects['type'] = 'project';
		$view = 'edit';
		break;
	}

	case 'new_revision': {
		$nf->projects->parent = $nf->projects->find('id', @$_GET['parent_id'], array(
			'array_only' => true,
			'update_model_data' => false
		));
		if (!$nf->projects->parent['id']) {
			nf::flash("Parent project not found", 'error');
			nf::redirect('?');
		}

		$nf->projects['parent_id'] = $nf->projects->parent['id'];
		$nf->projects['name'] = "New Revision";
		$nf->projects['send_vendor_email'] = 'revision_new';
		$nf->projects['status'] = 'Open';
		$nf->projects['type'] = 'revision';
		$view = 'edit';
		break;
	}

	case 'delete': {
		$model = $nf->projects;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'save': {
		if (!$nf->projects['id']) {
			$nf->projects['date_added'] = $nf->db->now();
		}

		$nf->projects->save();
		$nf->attached->saveFromJSON('project', $nf->projects['id']);

		if ($nf->projects['send_vendor_email']) {
			$nf->projects->parent = $nf->projects->find('id', $nf->projects['parent_id'], array(
				'array_only' => true,
				'update_model_data' => false
			));
			$nf->projects->sendVendorEmail();
		}

		$nf->projects->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	case 'save_order': {
		$nf->projects->save();
		$nf->projects->clearData();
		nf::flash("$data_desc order has been saved.");
		break;
	}


	case 'reorder': {
		$view = 'reorder';
		break;
	}

	default:
}



switch ($view) {
	case 'view_bids': {
		$nf->projects->find('id', @$_GET['id']);

		$nf->vendor_categories->find('all', array(
			'order' => 'LOWER(name) ASC',
			'array_only' => true
		)); 

		$nf->bids->find('all', array(
			'fields' => array(
				'bids.*',
				'v.name vendor_name',
				'v.category'
			),
			'join' => array(
				'model' => 'vendors v',
				'type' => 'left',
				'clause' => 'v.id=bids.vendor_id',
			),
			'conditions' => array(
				'project_id' => $nf->projects['id'],
			),
			'order' => 'amount ASC',
		));

		$nf->bids->by_category = $nf->bids->sortByCategory();
		break;
	}


	case 'edit': {
		$nf->vendors->find('all', array(
			'order' => 'LOWER(vendors.name) DESC',
			'array_only' => true,
			'by_id' => true
		));
		$nf->vendor_categories->find('all', array(
			'order' => 'LOWER(name) ASC',
			'array_only' => true
		)); 
		break;
	}


	case 'reorder': {
		$nf->projects->rows_all = $nf->projects->find('all', array(
			'conditions' => array(
				'type' => 'project'
			),
			'order' => 'row_order ASC',
			'array_only' => true,
			'update_model_data' => false
		));

		break;
	}

	default: {
		$nf->attached->find('all', array(
			'order' => 'file_order ASC',
			'conditions' => array('type' => 'project', 'foreign_id' => $nf->projects['id']),
			'fields' => array('upload_id', 'description', 'u.orig_filename'),
			'join' => array('model' => 'uploads u', 'clause' => 'u.id = attached.upload_id')
		));

		$nf->projects->rows_all = $nf->projects->find('all', array(
			'fields' => array(
				'projects.*',
				new nfDbExpression('(SELECT COUNT(*) FROM project_bids pb WHERE pb.project_id = projects.id) bids')
			),
			'order' => 'row_order ASC, date_added ASC',
			'array_only' => true,
			'update_model_data' => false
		));

	}
}



$nf['subcontent_template'] = 'projects';
$nf['content_template'] = 'admin/admin_page';
$nf->page_css = array('jstree1_ltgray');
$nf->page_scripts = array('uploadify', 'jqueryui', 'js1.6', 'php_js', 'json', 'fck', 'nfFuncs', 'add_remove', 'jstree1');
include($nf->base_dir ."templates/admin/main.php");

