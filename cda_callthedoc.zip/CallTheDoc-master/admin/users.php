<?php
include('../nf/init.php');
$nf = new nfFw('users', 'attached_files attached');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "User Account";
$data_desc_plural = "User Accounts";


switch (@$_REQUEST['action']) {
	case 'ajax_username_test': {
		$count = $nf->users->find('count', array(
			'conditions' => ($a = array(
				'id !=' => @$_POST['id'],
				'username' => @$_POST['username']
			))
		));

		echo json_encode($count);
		exit;
	}

	case 'edit': {
		$nf->users->find('id', @$_GET['id']);
		unset($nf->users['password']);

		if (in_array($nf->users['username'], $nf->users->hidden_users)) {
			$nf->users->clearData();
		}
		break;
	}

	case 'new': {
		$nf->users['name'] = "New $data_desc";
		break;
	}

	case 'delete': {
		$nf->users->find('id', @$_GET['id']);
		if (in_array($nf->users['username'], $nf->users->hidden_users)) {
			$nf->users->clearData();
		}

		$model = $nf->users;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}


	case 'save': {
		$stashed_data = $nf->users->data;

		$nf->users->find('id', $nf->users['id']);
		if (in_array($nf->users['username'], $nf->users->hidden_users)) {
			$nf->users->clearData();
			nf::flash("Changes could not be saved.");
			break;
		}

		$nf->users->data = $stashed_data;

		if (!$nf->users['password']) {
			unset($nf->users['password']);
		} else {
			$nf->users['password'] = md5($nf->users['password']);
		}

		if (!$nf->users->validates()) {
			nf::flash("Please fill in all fields colored in red, then press the Submit button again", "error");
			break;
		}

		$nf->users['permissions'] = 'user,'. $nf->users['type'];
		$nf->users->save();
		$nf->users->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	default:
}

$nf->users->rows_all = $nf->users->find('all', array(
	'order' => 'name DESC',
	'update_model_data' => false,
	'as_array' => true,
	'conditions' => array(
		'username NOT IN ("'. implode('","', $nf->users->hidden_users) .'")'
	)
));



$nf['subcontent_template'] = 'users';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs', 'scrollto');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

