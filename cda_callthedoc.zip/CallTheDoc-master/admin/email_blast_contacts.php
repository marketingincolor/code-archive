<?php
include('../nf/init.php');
$nf = new nfFw('email_blasts_contacts');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Email Blast Contact";
$data_desc_plural = "Email Blast Contacts";

switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf->email_blasts_contacts->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->email_blasts_contacts['name'] = "New $data_desc";
		break;
	}

	case 'delete': {
		$model = $nf->email_blasts_contacts;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'save': {
		$id = @$nf->email_blasts_contacts['id'];
		$nf->email_blasts_contacts->save();
		$nf->email_blasts_contacts->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	default:
}

$nf->email_blasts_contacts->rows_all = $nf->email_blasts_contacts->find('all', array(
	'order' => 'id ASC',
	'array_only' => true,
	'update_model_data' => false
));



$nf['subcontent_template'] = 'email_blast_contacts';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

