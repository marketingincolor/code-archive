<?php
include('../nf/init.php');
$nf = new nfFw('galleries', 'attached_files attached');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Gallery";
$data_desc_plural = "Galleries";


switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf['gallery'] = $nf->galleries->find('id', nf::coalesce(@$_GET['id'], @$_GET['url']));
		break;
	}

	case 'new': {
		$nf->galleries['name'] = 'New Gallery';
		break;
	}

	case 'delete': {
		if (!@$_GET['id']) { nf::flash("Error: No $data_desc was specified"); break; }
		// Get the outlet so we have it's name to display
		$nf->galleries->find('id', @$_GET['id']);
		if (!$nf->galleries->data) { nf::flash("Error: The specified $data_desc couldn't be found"); break; }

		// Delete
		$nf->galleries->delete(array('id' => @$_GET['id']));

		nf::flash("$data_desc \"{$nf->galleries['name']}\" is deleted");
		$nf->galleries->clearData();
		break;
	}

	case 'save': {
		$nf->galleries->save();
		$nf->attached->saveFromJSON('gallery_photo', $nf->galleries['id']);
		nf::flash("Changes have been saved.");
		break;
	}

	case 'save_order': {
		$nf->galleries->save();
		$nf->galleries->clearData();
		nf::flash("Gallery order has been saved.");
		break;
	}

	case 'reorder': {
		$nf['section'] = 'reorder';
		break;
	}

	default:
}

$nf->galleries->rows_all = $nf->galleries->find('all', array(
	'order' => 'row_order ASC, LOWER(name) ASC',
	'array_only' => true,
	'update_model_data' => false
));

if ($nf->galleries['id']) {
	$nf->attached->find('all', array(
		'order' => 'file_order ASC',
		'conditions' => array('type' => 'gallery_photo', 'foreign_id' => $nf->galleries['id']),
		'fields' => array('upload_id', 'description', 'u.orig_filename'),
		'join' => array('model' => 'uploads u', 'clause' => 'u.id = attached.upload_id')
	));
}

$nf['subcontent_template'] = 'galleries';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs');
include($nf->base_dir ."templates/admin/main.php");

