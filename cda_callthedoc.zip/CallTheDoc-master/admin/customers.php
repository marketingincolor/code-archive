<?php
include('../nf/init.php');
$nf = new nfFw(
	'customers',
	'users',
	'attached_files attached',
	'attached_files attached_gallery'
);

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Customer";
$data_desc_plural = "Customers";


switch (@$_REQUEST['action']) {
	case 'ajax_username_test': {
		include($nf->base_dir .'custom/pieces/ajax_username_test.php');
	}

	case 'edit': {
		$nf->customers->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->customers['first_name'] = "New";
		$nf->customers['last_name'] = "Customer";
		break;
	}

	case 'delete': {
		$nf->customers->find('id', @$_GET['id']);
		$user_id = $nf->customers['user_id'];
		$model = $nf->customers;
		$nf->customers['name'] = $nf->customers['first_name'] .' '. $nf->customers['last_name'];
		include(dirname(__FILE__) .'/pieces/delete.php');

		$nf->users->delete(array(
			'id' => $user_id
		));
		break;
	}


	case 'save': {
		$nf->customers->fields = $nf->customers->fields_backend;
		$nf->customers->buildFields();

		if (!$nf->customers['password']) {
			unset($nf->customers['password']);
		} else {
			$nf->customers['password'] = md5($nf->customers['password']);
		}

		$validates = $nf->customers->validates();

		if (!$nf->customers['id'] && !$nf->customers['password']) {
			$nf->customers->invalidate('password', 'The customer account cannot be created without a password');
		}

		if (!$validates) {
			nf::flash("Please fill in all fields colored in red, then press the Submit button again", "error");
			break;
		}

		$nf->customers->save();

		$nf->attached->saveFromJSON('customer', $nf->customers['id']);
		$nf->attached_gallery->saveFromJSON('customer_gallery', $nf->customers['id']);

		/*** User */
		if ($nf->customers['user_id']) {
			$nf->users->find('id', $nf->customers['user_id']);

			$nf->users['username'] = $nf->customers['email'];
			$nf->users['email'] = $nf->customers['email'];
		} else {
			$nf->users->push(array(
				'username' => $nf->customers['email'],
				'permissions' => 'user,customer',
				'type' => 'customer',
				'email' => $nf->customers['email'],
				'foreign_id' => $nf->customers['id'],
				'landing_page' => 'customers'
			));
		}

		if ($nf->customers['password']) {
			$nf->users['password'] = $nf->customers['password'];
		}

		$nf->users->save();
		/***/

		$nf->customers['user_id'] = $nf->users['id'];
		$nf->customers->save();

		$nf->customers->clearData();


		nf::flash("Changes have been saved.");
		break;
	}

	default:
}

$nf->customers->rows_all = $nf->customers->find('all', array(
	'order' => 'LOWER(last_name) DESC',
	'update_model_data' => false,
	'as_array' => true,
));

$nf->attached->find('all', array(
	'order' => 'file_order ASC',
	'conditions' => array('type' => 'customer', 'foreign_id' => $nf->customers['id']),
	'fields' => array('upload_id', 'description', 'u.orig_filename'),
	'join' => array('model' => 'uploads u', 'clause' => 'u.id = attached.upload_id')
));
$nf->attached_gallery->find('all', array(
	'order' => 'file_order ASC',
	'conditions' => array('type' => 'customer_gallery', 'foreign_id' => $nf->customers['id']),
	'fields' => array('upload_id', 'description', 'u.orig_filename'),
	'join' => array('model' => 'uploads u', 'clause' => 'u.id = attached_gallery.upload_id')
));


if ($nf->customers->numRows() > 0) {
	$nf->customers['password'] = null;
}


$nf['subcontent_template'] = 'customers';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('uploadify', 'jqueryui', 'json');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

