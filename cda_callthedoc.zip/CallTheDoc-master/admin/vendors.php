<?php
include('../nf/init.php');
$nf = new nfFw(
	'vendors',
	'vendor_categories cats',
	'users',
	'log'
);

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Vendor";
$data_desc_plural = "Vendors";


switch (@$_REQUEST['action']) {
	case 'ajax_username_test': {
		include($nf->base_dir .'custom/pieces/ajax_username_test.php');
	}

	case 'edit': {
		$nf->vendors->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->vendors['name'] = "New $data_desc";
		break;
	}

	case 'delete': {
		$nf->vendors->find('id', @$_GET['id']);
		$user_id = $nf->vendors['user_id'];
		$model = $nf->vendors;
		include(dirname(__FILE__) .'/pieces/delete.php');

		$nf->users->delete(array(
			'id' => $user_id
		));
		break;
	}


	case 'save': {
		if (!$nf->vendors['password']) {
			unset($nf->vendors['password']);
		} else {
			$nf->vendors['password'] = md5($nf->vendors['password']);
		}

		$validates = $nf->vendors->validates();

		if (!$nf->vendors['id'] && !$nf->vendors['password']) {
			$nf->vendors->invalidate('password', 'The Vendor account cannot be created without a password');
		}

		if (!$validates) {
			nf::flash("Please fill in all fields colored in red, then press the Submit button again", "error");
			break;
		}

		$nf->vendors->save();

		/*** User */
		if ($nf->vendors['user_id']) {
			$nf->users->find('id', $nf->vendors['user_id']);

			$nf->users['username'] = $nf->vendors['email'];
			$nf->users['email'] = $nf->vendors['email'];
		} else {
			$nf->users->push(array(
				'username' => $nf->vendors['email'],
				'permissions' => 'user,vendor',
				'type' => 'vendor',
				'email' => $nf->vendors['email'],
				'foreign_id' => $nf->vendors['id'],
				'landing_page' => 'vendors'
			));
		}

		if ($nf->vendors['password']) {
			$nf->users['password'] = $nf->vendors['password'];
		}

		$nf->users->save();
		/***/

		$nf->vendors['user_id'] = $nf->users['id'];
		$nf->vendors->save();

		$nf->vendors->clearData();


		nf::flash("Changes have been saved.");
		break;
	}

	default:
}

$nf->vendors->rows_all = $nf->vendors->find('all', array(
	'order' => 'LOWER(name) DESC',
	'update_model_data' => false,
	'as_array' => true,
));

$nf->cats->rows_all = $nf->cats->find('all', array(
	'order' => 'LOWER(name) ASC',
	'array_only' => true,
	'by_id' => true
));


if ($nf->vendors->numRows() > 0) {
	$nf->vendors['password'] = null;

	$nf->log->find('all', array(
		'conditions' => array(
			'relation' => 'vendor',
			'foreign_id' => $nf->vendors['id']
		)
	));
}


$nf['subcontent_template'] = 'vendors';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array();
$nf->page_css = array();
include($nf->base_dir ."templates/admin/main.php");

