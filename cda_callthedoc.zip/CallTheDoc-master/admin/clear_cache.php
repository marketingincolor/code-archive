<?php
include('../nf/init.php');
$nf = new nfFw();

$nf->auth->secure();
$nf->auth->checkAuthorized();

$cached_images = glob($nf->upload->options['upload_dir'] .'cache/*{png,gif,jpg}', GLOB_BRACE);
foreach ($cached_images as $file) {
	unlink($file);
}

nf::flash("Image cache is now cleared");
nf::redirect('index.php');
