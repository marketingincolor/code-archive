<?php
include('../nf/init.php');
$nf = new nfFw('users', 'generic');

switch (@$_REQUEST['action']) {
	case 'logout': {
		$nf->auth->setLogout();
		nf::flash('Logged out.');
		nf::redirect('?');
		break;
	}

	case 'submit_login': {
		$nf->auth->authorizeLogin($nf->generic['username'], $nf->generic['password']);

		if ($nf->auth->loggedIn()) {
			// If we got here, then there was no redirect in $_SESSION
			nf::redirect('index.php');
		} else {
			nf::flash("Please enter the correct username and password");
		}

		break;
	}

	default:
}


$content = 'admin/login';
include($nf->base_dir ."templates/admin/main.php");

