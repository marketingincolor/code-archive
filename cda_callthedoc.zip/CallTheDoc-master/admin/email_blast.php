<?php
include('../nf/init.php');
$nf = new nfFw('email_blasts');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Email Blast";
$data_desc_plural = "Email Blasts";

switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf->email_blasts->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->email_blasts['name'] = "New $data_desc";
		break;
	}

	case 'delete': {
		$model = $nf->email_blasts;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'save': {
		$id = @$nf->email_blasts['id'];
		$nf->email_blasts->save();
		$nf->email_blasts->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	default:
}

$nf->email_blasts->rows_all = $nf->email_blasts->find('all', array(
	'order' => 'id ASC',
	'array_only' => true,
	'update_model_data' => false
));



$nf['subcontent_template'] = 'email_blast';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

