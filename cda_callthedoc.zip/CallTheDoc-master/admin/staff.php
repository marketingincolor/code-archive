<?php
include('../nf/init.php');
$nf = new nfFw('staff');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Staff Member";
$data_desc_plural = "Staff Members";

switch (@$_REQUEST['action']) {
	case 'edit': {
		$nf->staff->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->staff['name'] = "New $data_desc";
		break;
	}

	case 'delete': {
		$model = $nf->staff;
		include(dirname(__FILE__) .'/pieces/delete.php');
		break;
	}

	case 'save': {
		$nf->staff['franchisee_id'] = (int)@$_SESSION['editing_franchisee']['id'];
		$nf->staff->save();
		$nf->staff->clearData();

		nf::flash("Changes have been saved.");
		break;
	}

	case 'save_order': {
		$nf->staff->save();
		$nf->staff->clearData();
		nf::flash("$data_desc order has been saved.");
		break;
	}


	case 'reorder': {
		$nf['section'] = 'reorder';
		break;
	}

	default:
}

$nf->staff->rows_all = $nf->staff->find('all', array(
	'order' => 'row_order ASC, LOWER(name) ASC',
	'conditions' => array('franchisee_id' => (int)@$_SESSION['editing_franchisee']['id']),
	'array_only' => true,
	'update_model_data' => false
));



$nf['subcontent_template'] = 'staff';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('jqueryui', 'json', 'uploadify', 'fck', 'nffuncs');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

