<?php
include('../nf/init.php');
$nf = new nfFw('nav', 'pages pages_all', 'null_table nt', 'news', 'events', 'case_studies', 'users');

$nf->auth->secure();
$nf->auth->checkAuthorized();

$nf->nav->nav_name = nf::coalesce(@$_GET['nav_name'], 'primary');

switch (@$_REQUEST['action']) {
	case 'save': {
		$nf->nav->save();
		nf::flash('Changes have been saved');
		break;
	}

	default:
}

$nf->nav->load();

$nf->pages_all->find('all', array('order' => 'LOWER(name) ASC'));
$nf->news->find('all', array('order' => 'date DESC, LOWER(name) ASC'));
$nf->events->find('all', array('order' => 'date DESC, LOWER(name) ASC'));
$nf->case_studies->find('all', array('order' => 'row_order ASC, LOWER(name) ASC'));

$nf['subcontent_template'] = 'nav';
$nf['content_template'] = 'admin/admin_page';
$nf->page_css = array('jstree');
$nf->page_scripts = array('nffuncs', 'simplemodal', 'json', 'jstree');
include($nf->base_dir ."templates/admin/main.php");

