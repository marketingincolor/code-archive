<?php
include_once(dirname(__FILE__) .'/../nf/init.php');
$nf = new nfFw();

$nf->auth->checkAuthorized();

$nf['subcontent_template'] = 'index';
$nf['content_template'] = 'admin/admin_page';
include($nf->base_dir ."templates/admin/main.php");
