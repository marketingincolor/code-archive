<?php
include('../nf/init.php');
$nf = new nfFw(
	'members',
	'users',
	'attached_files attached',
	'attached_files attached_gallery'
);

$nf->auth->secure();
$nf->auth->checkAuthorized();

$data_desc = "Member";
$data_desc_plural = "Members";


switch (@$_REQUEST['action']) {
	case 'ajax_username_test': {
		include($nf->base_dir .'custom/pieces/ajax_username_test.php');
	}

	case 'edit': {
		$nf->members->find('id', @$_GET['id']);
		break;
	}

	case 'new': {
		$nf->members['first_name'] = "New";
		$nf->members['last_name'] = "Member";
		break;
	}

	case 'delete': {
		$nf->members->find('id', @$_GET['id']);
		$user_id = $nf->members['user_id'];
		$model = $nf->members;
		$nf->members['name'] = $nf->members['first_name'] .' '. $nf->members['last_name'];
		include(dirname(__FILE__) .'/pieces/delete.php');

		$nf->users->delete(array(
			'id' => $user_id
		));
		break;
	}


	case 'save': {
		$nf->members->fields = $nf->members->fields_backend;
		$nf->members->buildFields();

		if (!$nf->members['password']) {
			unset($nf->members['password']);
		} else {
			$nf->members['password'] = md5($nf->members['password']);
		}

		$validates = $nf->members->validates();

		if (!$nf->members['id'] && !$nf->members['password']) {
			$nf->members->invalidate('password', 'The member account cannot be created without a password');
		}

		if (!$validates) {
			nf::flash("Please fill in all fields colored in red, then press the Submit button again", "error");
			break;
		}

		$nf->members->save();

		$nf->attached->saveFromJSON('member', $nf->members['id']);
		//$nf->attached_gallery->saveFromJSON('customer_gallery', $nf->members['id']);

		/*** User */
		if ($nf->members['user_id']) {
			$nf->users->find('id', $nf->members['user_id']);

			$nf->users['username'] = $nf->members['email'];
			$nf->users['email'] = $nf->members['email'];
		} else {
			$nf->users->push(array(
				'username' => $nf->members['email'],
				'permissions' => 'user,member',
				'type' => 'member',
				'email' => $nf->members['email'],
				'foreign_id' => $nf->members['id'],
				'landing_page' => 'member-landing'
			));
		}

		if ($nf->members['password']) {
			$nf->users['password'] = $nf->members['password'];
		}

		$nf->users->save();
		/***/

		$nf->members['user_id'] = $nf->users['id'];
		$nf->members->save();

		$nf->members->clearData();


		nf::flash("Changes have been saved.");
		break;
	}

	case 'membership_card': {

		/*** generate pdf */
		require_once($nf->base_dir ."includes/tcpdf/tcpdf.php");
		require_once($nf->base_dir ."includes/fpdi/fpdi.php");
		
		class PDF extends FPDI {
		    var $_tplIdx;
		    function Header() {
		        if (is_null($this->_tplIdx)) {
		            $this->setSourceFile('../templates/postscript/membership_card.pdf');
		            $this->_tplIdx = $this->importPage(1);
		        }
		        $this->useTemplate($this->_tplIdx);
		    }
		    function Footer() {}
		}
		
		// initiate PDF
		$pdf = new PDF('L','mm', array(77.5,108.5));
		$pdf->setFontSubsetting(false);
		
		$pdf->AddPage();
		
        $pdf->SetFont('freesans', 'B', 9);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetXY(20, 48);
        $pdf->Cell(0, 8.6, $_GET['user_id']);
		
		$pdf->Output('member_'.$_GET['user_id'].'.pdf', 'D');


		/*
		// initiate FPDI
		$pdf =& new FPDI();
		// add a page
		$pdf->AddPage();
		// set the sourcefile
		$pdf->setSourceFile($nf->base_dir .'templates/postscript/membership_card.pdf');
		// import page 1
		$tplIdx = $pdf->importPage(1);
		// use the imported page and place it at point 10,10 with a width of 100 mm
		$pdf->useTemplate($tplIdx, 0, 0);
		
		// now write some text above the imported page
		$pdf->SetFont('MyriadPro-Regular');
		$pdf->SetTextColor(0,0,0);
		$pdf->SetXY(26, 56);
		$pdf->Write(0, $_GET['user_id']);
		
		$pdf->Output('member_'.$_GET['user_id'].'.pdf', 'D');
		*/
		break;

	}

	default:
}

$nf->members->rows_all = $nf->members->find('all', array(
	'order' => 'LOWER(last_name) DESC',
	'update_model_data' => false,
	'as_array' => true,
));

$nf->attached->find('all', array(
	'order' => 'file_order ASC',
	'conditions' => array('type' => 'customer', 'foreign_id' => $nf->members['id']),
	'fields' => array('upload_id', 'description', 'u.orig_filename'),
	'join' => array('model' => 'uploads u', 'clause' => 'u.id = attached.upload_id')
));
//$nf->attached_gallery->find('all', array(
//	'order' => 'file_order ASC',
//	'conditions' => array('type' => 'customer_gallery', 'foreign_id' => $nf->members['id']),
//	'fields' => array('upload_id', 'description', 'u.orig_filename'),
//	'join' => array('model' => 'uploads u', 'clause' => 'u.id = attached_gallery.upload_id')
//));


if ($nf->members->numRows() > 0) {
	$nf->members['password'] = null;
}


$nf['subcontent_template'] = 'members';
$nf['content_template'] = 'admin/admin_page';
$nf->page_scripts = array('uploadify', 'jqueryui', 'json');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/admin/main.php");

