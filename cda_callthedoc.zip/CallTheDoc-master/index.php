<?php
include_once(dirname(__FILE__) .'/nf/init.php');
$nf = new nfFw('pages', 'home_page', 'settings', 'news', 'pages areas', 'attached_files attached', 'contacts', 'features');

$nf->settings->find('first');
$nf->home_page->find('first');

$nf->news->find('all', array(
	'order' => 'date DESC',
	'limit' => 3
));

$nf->attached->find('all', array(
	'conditions' => array('type' => 'home_page'),
	'order' => 'file_order ASC',
));

for ($i=1; $i<=4; $i++) {
	$nf["featured_story$i"] = $nf->features->find('id', $nf->home_page["featured_story$i"]);
}


$nf['title'] = $nf->settings['site_title'] . $nf->home_page['title'];
$nf['meta_desc'] = $nf->home_page['meta_desc'];
$nf['meta_keywords'] = $nf->home_page['meta_keywords'];

$nf['current_url'] = array('{BASE_URL}', '/');

$nf['content_template'] = 'home';
$nf['body_class'] = 'home wetheppl';
// Main layout template
$nf->page_scripts = array('jquery', 'crossSlide', 'jqueryui', 'scrollto');
$nf->page_css = array('smoothness');
include($nf->base_dir ."templates/main.php");

