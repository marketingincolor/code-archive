<?php
require_once '_inc.php';

$head_title = array();
$head_title[] = 'Post a New Job';

$output = '<h2>Post a New Job</h2>';

if($user->isAuthorized())
{
	
	$job_category_module = MK_RecordModuleManager::getFromType('job_category');
	$job_type_module = MK_RecordModuleManager::getFromType('job_type');
	$job_module = MK_RecordModuleManager::getFromType('job');

	try
	{
		if( $current_job = MK_Request::getQuery('job') )
		{
			$current_job = MK_RecordManager::getFromId( $job_module->getId(), $current_job );
			$output = '<h2>Edit Job</h2>';
			if($current_job->getPostedBy() != $user->getId())
			{
				throw new MK_Exception("You can't edit this job");	
			}
		}
		else
		{
			throw new MK_Exception("Invalid job");	
		}
	}
	catch(Exception $e)
	{
		$current_job = null;
	}
	
	$settings = array(
		'attributes' => array(
			'class' => 'clear-fix titled standard'
		)
	);

	$structure = array(
		'title' => array(
			'label' => 'Job Title',
			'validation' => array(
				'instance' => array()
			)
		),
		'employer_name' => array(
			'label' => 'Employer Name'
		),
		'employer_website' => array(
			'label' => 'Employer Website',
			'validation' => array(
				'url' => array()
			)
		),
		'type' => array(
			'label' => 'Type',
			'type' => 'select',
			'options' => array(),
			'validation' => array(
				'integer_not_zero' => array()
			)
		),
		'category' => array(
			'label' => 'Category',
			'type' => 'select',
			'options' => array(),
			'validation' => array(
				'integer_not_zero' => array()
			)
		),
		'contact_email' => array(
			'label' => 'Contact Email',
			'value' => $user->getEmail(),
			'tooltip' => 'This is only used to inform you of applications for this role. It will never be displayed on the site.',
			'validation' => array(
				'instance' => array(),
				'email' => array()
			)
		),
		'tags' => array(
			'label' => 'Tags',
			'tooltip' => "Seperate with comma - ','."
		),
		'description' => array(
			'label' => 'Job Description',
			'type' => 'rich_text',
			'attributes' => array(
				'class' => 'input-textarea-small'
			),
			'validation' => array(
				'instance' => array()
			)
		),
		'submit' => array(
			'type' => 'submit',
			'attributes' => array(
				'value' => 'Post Job'
			)
		)
	);
	
	if(!empty($current_job))
	{
		$structure['title']['value'] = $current_job->getTitle();
		$structure['employer_name']['value'] = $current_job->getEmployerName();
		$structure['employer_website']['value'] = $current_job->getEmployerWebsite();
		$structure['type']['value'] = $current_job->getType();
		$structure['category']['value'] = $current_job->getCategory();
		$structure['contact_email']['value'] = $current_job->getEmployerEmail();
		$structure['tags']['value'] = $current_job->getTags();
		$structure['description']['value'] = $current_job->getDescription();
		$structure['submit']['attributes']['value'] = 'Save Changes';
	}

	$job_categories = $job_category_module->getRecords();
	$job_types = $job_type_module->getRecords();

	// Type list
	if(count($job_types) > 0)
	{
		$structure['type']['options'][0] = 'Please select...';
		foreach($job_types as $job_type)
		{
			$structure['type']['options'][$job_type->getId()] = $job_type->getTitle();
		}
	}
	else
	{
		unset($structure['type']);
	}

	// Category list
	if(count($job_categories) > 0)
	{
		$structure['category']['options'][0] = 'Please select...';
		foreach($job_categories as $job_category)
		{
			$text_indent = '';
			for($i = 0; $i < $job_category->getNestedLevel(); $i++){
				$text_indent.='&nbsp;&nbsp;&nbsp;';
			}
			$structure['category']['options'][$job_category->getId()] = ($text_indent ? $text_indent.'&#8627;&nbsp;' : '' ).$job_category->getTitle();
		}
	}
	else
	{
		$structure['category'] = array(
			'label' => 'Category',
			'type' => 'static',
			'value' => 0,
		);
	}

	$form = new MK_Form($structure, $settings);
	
	if($form->isSuccessful())
	{
		
		if(empty($current_job))
		{
			$current_job = MK_RecordManager::getNewRecord($job_module->getId());
			$current_job->isPublished( false );
			$output .= '<p class="alert success">Your new job has been submitted successfully and must be reviewed by a member of staff before appearing on the site.</p>';
			$new_job = true;
		}
		else
		{
			$output .= '<p class="alert success">Your job has been updated. <a href="index.php?job='.$current_job->getId().'">Click here to view it</a>.</p>';
			$new_job = false;
		}

		$current_job
			->setTitle( $form->getField('title')->getValue() )
			->setEmployerName( $form->getField('employer_name')->getValue() )
			->setEmployerWebsite( $form->getField('employer_website')->getValue() )
			->setType( $form->getField('type')->getValue() )
			->setCategory( $form->getField('category')->getValue() )
			->setEmployerEmail( $form->getField('contact_email')->getValue() )
			->setTags( $form->getField('tags')->getValue() )
			->setPostedBy( $user->getId() )
			->setDescription( MK_Utility::stripTags( $form->getField('description')->getValue(), array('p', 'div', 'strong', 'b', 'em', 'i', 'u', 's', 'strike', 'ul', 'ol', 'li', 'ol', 'blockquote') ) )
			->save();

		if($new_job === true)
		{
			$email_notification = new MK_BrandedEmail();
			$email_notification
				->setSubject('New Job Posted ('.$current_job->getTitle().')')
				->setMessage('A new job has been submitted by <strong>'.$user->getDisplayName().'</strong>.<br /><br /><a href="'.$config->site->url.'admin/?module_path=jobs/index/method/edit/id/'.$current_job->getId().'">Visit the admin panel</a> to publish this job on the homepage.')
				->send($config->site->email);
		}
	}
	else
	{
		$output.=$form->render();
	}
}
else
{
	$output .= '<p class="alert information">Please <a href="login.php">log in</a> or <a href="register.php">register</a> to post a new job!</p>';
}

require_once '_header.php';
print $output;
require_once '_footer.php';

?>