<?php
require_once '_inc.php';

$head_title = array();
$head_title[] = 'Jobs You\'ve Posted';

$output = '<h2>Jobs You\'ve Posted</h2>';

if($user->isAuthorized())
{
	$job_category_module = MK_RecordModuleManager::getFromType('job_category');
	$job_type_module = MK_RecordModuleManager::getFromType('job_type');
	$job_module = MK_RecordModuleManager::getFromType('job');
	$user_module = MK_RecordModuleManager::getFromType('user');
	
	try
	{
		if( $current_job = MK_Request::getQuery('job') )
		{
			$current_job = MK_RecordManager::getFromId( $job_module->getId(), $current_job );
			if($current_job->getPostedBy() != $user->getId())
			{
				throw new MK_Exception("You can't edit this job");	
			}
		}
		else
		{
			throw new MK_Exception("Invalid job");	
		}
	}
	catch(Exception $e)
	{
		$current_job = null;
	}
	
	if($current_job)
	{
		$job_application_module = MK_RecordModuleManager::getFromType('job_application');
		
		$search_criteria = array(
			array('field' => 'job', 'value' => $current_job->getId())
		);
		
		$paginator = new MK_Paginator();
		$paginator
			->setPerPage(20)
			->setPage( MK_Request::getQuery('page', 1) );

		$applications = $job_application_module->searchRecords($search_criteria, $paginator);

		$head_title[] = 'View Applicants';
		$output = '<h2><a href="your-jobs.php">Jobs You\'ve Posted</a> / View Applicants</h2>';
		$output .= '<p class="subtitle">Viewing applicants for the job, <span>'.$current_job->getTitle().'</span></p>';

		if($applications)
		{
			$output.= '<table class="list-view job-listing-view job-applicant-view" cellpadding="0" cellspacing="0" border="0">';
			$output.= '<thead><tr>';
			$output.= '<th style="width:30%;">Applicant / Covering Letter</th>';
			$output.= '<th style="width:30%;">Application Date</th>';
			$output.= '<th style="width:15%; text-align:center;">CV / Resume</th>';
			$output.= '</tr></thead>';
			$output.= '<tbody>';
			$counter = 0;
			foreach($applications as $application)
			{
				$counter++;
				try
				{
					$user = MK_RecordManager::getFromId($user_module->getId(), $application->getUser());
				}
				catch(Exception $e)
				{
					continue;
				}
				$output.= '<tr class="cv-title'.(is_int($counter / 2) ? ' highlight' : '').'">';
				$output.= '<td><span>'.$user->getDisplayName().'</span> (<a href="mailto:'.$user->getEmail().'">'.$user->getEmail().'</a>)</td>';
				$output.= '<td>'.$application->renderDatePosted().'</td>';
				$output.= '<td style="text-align:center;"><a href="'.$application->getCv().'">Download</a></td>';
				$output.= '</tr>';
				$output.= '<tr class="cv-message'.(is_int($counter / 2) ? ' highlight' : '').'">';
				$output.= '<td colspan="3">'.($application->getMessage() ? $application->getMessage() : 'None submitted').'</td>';
				$output.= '</tr>';
			}
			$output.= '</tbody>';
			$output.= '</table>';
			
			// Show pagination
			$output.= '<div class="clear-fix paginator">'.$paginator->render('your-jobs.php?page={page}&job='.$current_job->getId()).'</div>';
		}
		else
		{
			$output .= '<p class="alert information">There have been no applications for this job.</p>';
		}
		
	}
	else
	{
	
		$search_criteria = array(
			array('field' => 'posted_by', 'value' => $user->getId()),
			array('field' => 'published', 'value' => 1)
		);
	
		$paginator = new MK_Paginator();
		$paginator
			->setPerPage(20)
			->setPage( MK_Request::getQuery('page', 1) );
	
		$jobs = $job_module->searchRecords($search_criteria, $paginator);
	
		if($jobs)
		{
			$output.= '<table class="list-view job-listing-view" cellpadding="0" cellspacing="0" border="0">';
			$output.= '<thead><tr>';
			$output.= '<th style="width:75%;">Title / Employer / Location</th>';
			$output.= '<th style="width:25%; text-align:center;">&nbsp;</th>';
			$output.= '</tr></thead>';
			$output.= '<tbody>';
			foreach($jobs as $job)
			{
				$output.= '<tr>';
				$output.= '<td>';
				try
				{
					$job_type = MK_RecordManager::getFromId( $job_type_module->getId(), $job->getType() );
					$output .= '<span>'.$job_type->getTitle().'</span> ';
				}catch(Exception $e){}
	
				$output.= '<strong><a href="index.php?job='.$job->getId().'">'.$job->getTitle().'</a></strong>';
	
				if($employer_name = $job->getEmployerName())
				{
					if($employer_website = $job->getEmployerWebsite())
					{
						$output .= ' at <span><a target="_blank" href="'.$employer_website.'">'.$employer_name.'</a></span>';
					}
					else
					{
						$output .= ' at <span>'.$employer_name.'</span>';
					}
				}
				if($location = $job->getLocation())
				{
						$output .= ' in <span>'.$location.'</span>';
				}
				$output.= ($job->getEmployerName() ? '' : '');
				$output.= '</td>';
				$output.= '<td style="text-align:center;"><a href="post-job.php?job='.$job->getId().'">Edit</a> | <a href="your-jobs.php?job='.$job->getId().'">View Applications</a></td>';
				$output.= '</tr>';
			}
			$output.= '</tbody>';
			$output.= '</table>';
			
			// Show pagination
			$output.= '<div class="clear-fix paginator">'.$paginator->render('your-jobs.php?page={page}').'</div>';
		}
		else
		{
			$output .= '<p class="alert information">You haven\'t posted any jobs. <a href="post-job.php">Why not create one</a>?</p>';
		}
		
	}

}
else
{
	$output .= '<p class="alert information">Please <a href="login.php">log in</a> or <a href="register.php">register</a> to post a new job!</p>';
}

require_once '_header.php';
print $output;
require_once '_footer.php';

?>