<?php

ob_start();

$tank_you_url = 'http://www.compasshrm.com/thankyou.html';

$to = 'clientservices@compasshrm.com';
   
       
        $name = $_POST['NAME'];
        $phone = $_POST['PHONE'];
		$email = $_POST['EMAIL'];
		$company = $_POST['COMPANY'];
        $message = $_POST['MESSAGE'];
     
		
		
        $mailBody .= "NAME: ".$name."\n";
		$mailBody .= "PHONE: ".$phone."\n";
        $mailBody .= "EMAIL: ".$email."\n";
		$mailBody .= "COMPANY: ".$company."\n";
        $mailBody .= "MESSAGE: ".$message."\n";
     
    
	
		
      

		
		
	
		
        $subject = "Contact Form Submission";
        $message = $mailBody;
        $from_name = $name;
        $from = $email;
        
		//echo($mailBody);
		
		
		
        
    $headers = 'From: '.$from_name .'<'.$from.'>'. "\r\n" . 'Reply-To:'. $from . "\r\n" . 'X-Mailer: PHP/' . phpversion();
      if(mail($to, $subject, $message, $headers))
      {
         header("Location: ".$tank_you_url);exit;
       }
    

?>