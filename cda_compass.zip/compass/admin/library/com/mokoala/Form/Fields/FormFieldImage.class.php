<?php

class MK_Form_Field_Image extends MK_Form_Field_Submit{


}

?>