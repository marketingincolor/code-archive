<?php

class MK_InputException extends MK_Exception{
	
}

?>