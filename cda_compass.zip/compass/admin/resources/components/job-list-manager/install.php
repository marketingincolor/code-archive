<?php

$config = MK_Config::getInstance();

// Get Module Types
$module_type = MK_RecordModuleManager::getFromType('module');
$module_field_type = MK_RecordModuleManager::getFromType('module_field');
$module_field_validation_type = MK_RecordModuleManager::getFromType('module_field_validation');

// Jobs
$job_module = MK_RecordManager::getNewRecord( $module_type->getId() );
$job_module
	->setName('Jobs')
	->setTable('jobs')
	->setSlug('jobs')
	->setParentModuleId(0)
	->setFieldUid(0)
	->setFieldSlug(0)
	->setFieldParent(0)
	->setFieldOrderby(0)
	->setOrderbyDirection('DESC')
	->setManagementWidth('20%')
	->setType('job')
	->setLocked(0)
	->setLockRecords(0)
	->setCoreModule(0)
	->save();


$job_module_title = MK_RecordManager::getNewRecord( $module_field_type->getId() );
$job_module_title
	->setOrder(2)
	->setModuleId( $job_module->getId() )
	->setName('title')
	->setLabel('Title')
	->setType('')
	->setEditable(1)
	->setDisplayWidth('20%')
	->setTooltip('')
	->setFieldset('')
	->setSpecificSearch(0)
	->save();

$job_module_title_validation = MK_RecordManager::getNewRecord( $module_field_validation_type->getId() );
$job_module_title_validation
	->setName('instance')
	->setFieldId($job_module_title->getId())
	->save();

$job_module_date_posted = MK_RecordManager::getNewRecord( $module_field_type->getId() );
$job_module_date_posted
	->setOrder(3)
	->setModuleId( $job_module->getId() )
	->setName('date_posted')
	->setLabel('Date Posted')
	->setType('datetime_now')
	->setEditable(1)
	->setDisplayWidth('30%')
	->setTooltip('')
	->setFieldset('')
	->setSpecificSearch(0)
	->save();

$job_module_employer_name = MK_RecordManager::getNewRecord( $module_field_type->getId() );
$job_module_employer_name
	->setOrder(4)
	->setModuleId( $job_module->getId() )
	->setName('employer_name')
	->setLabel('Employer name')
	->setType('')
	->setEditable(1)
	->setDisplayWidth('')
	->setTooltip('')
	->setFieldset('')
	->setSpecificSearch(0)
	->save();

$job_module_employer_website = MK_RecordManager::getNewRecord( $module_field_type->getId() );
$job_module_employer_website
	->setOrder(5)
	->setModuleId( $job_module->getId() )
	->setName('employer_website')
	->setLabel('Employer website')
	->setType('')
	->setEditable(1)
	->setDisplayWidth('')
	->setTooltip('')
	->setFieldset('')
	->setSpecificSearch(0)
	->save();

$job_module_description = MK_RecordManager::getNewRecord( $module_field_type->getId() );
$job_module_description
	->setOrder(10)
	->setModuleId( $job_module->getId() )
	->setName('description')
	->setLabel('Description')
	->setType('rich_text_large')
	->setEditable(1)
	->setDisplayWidth('')
	->setTooltip('')
	->setFieldset('')
	->setSpecificSearch(0)
	->save();

$job_module_category = MK_RecordManager::getNewRecord( $module_field_type->getId() );
$job_module_category
	->setOrder(7)
	->setModuleId( $job_module->getId() )
	->setName('category')
	->setLabel('Category')
	->setType('job_category')
	->setEditable(1)
	->setDisplayWidth('')
	->setTooltip('')
	->setFieldset('')
	->setSpecificSearch(0)
	->save();

$job_module_type = MK_RecordManager::getNewRecord( $module_field_type->getId() );
$job_module_type
	->setOrder(8)
	->setModuleId( $job_module->getId() )
	->setName('type')
	->setLabel('Type')
	->setType('job_type')
	->setEditable(1)
	->setDisplayWidth('')
	->setTooltip('')
	->setFieldset('')
	->setSpecificSearch(0)
	->save();

$job_module_tags = MK_RecordManager::getNewRecord( $module_field_type->getId() );
$job_module_tags
	->setOrder(9)
	->setModuleId( $job_module->getId() )
	->setName('tags')
	->setLabel('Tags')
	->setType('')
	->setEditable(1)
	->setDisplayWidth('')
	->setTooltip('Seperate with comma - \',\'.')
	->setFieldset('')
	->setSpecificSearch(0)
	->save();

$job_module_published = MK_RecordManager::getNewRecord( $module_field_type->getId() );
$job_module_published
	->setOrder(3)
	->setModuleId( $job_module->getId() )
	->setName('published')
	->setLabel('Published')
	->setType('yes_no')
	->setEditable(1)
	->setDisplayWidth('20%')
	->setTooltip('')
	->setFieldset('')
	->setSpecificSearch(0)
	->save();

$job_module_employer_email = MK_RecordManager::getNewRecord( $module_field_type->getId() );
$job_module_employer_email
	->setOrder(5)
	->setModuleId( $job_module->getId() )
	->setName('employer_email')
	->setLabel('Employer email')
	->setType('')
	->setEditable(1)
	->setDisplayWidth('')
	->setTooltip('')
	->setFieldset('')
	->setSpecificSearch(0)
	->save();

$job_module_location = MK_RecordManager::getNewRecord( $module_field_type->getId() );
$job_module_location
	->setOrder(6)
	->setModuleId( $job_module->getId() )
	->setName('location')
	->setLabel('Location')
	->setType('')
	->setEditable(1)
	->setDisplayWidth('')
	->setTooltip('')
	->setFieldset('')
	->setSpecificSearch(0)
	->save();

$job_module_posted_by = MK_RecordManager::getNewRecord( $module_field_type->getId() );
$job_module_posted_by
	->setOrder(3)
	->setModuleId( $job_module->getId() )
	->setName('posted_by')
	->setLabel('Posted By')
	->setType('user')
	->setEditable(1)
	->setDisplayWidth('')
	->setTooltip('')
	->setFieldset('')
	->setSpecificSearch(0)
	->save();

// Job Types
$job_type_module = MK_RecordManager::getNewRecord( $module_type->getId() );
$job_type_module
	->setName('Types')
	->setTable('jobs_types')
	->setSlug('types')
	->setParentModuleId( $job_module->getId() )
	->setFieldUid(0)
	->setFieldSlug(0)
	->setFieldParent(0)
	->setFieldOrderby(0)
	->setOrderbyDirection('ASC')
	->setManagementWidth('20%')
	->setType('job_type')
	->setLocked(0)
	->setLockRecords(0)
	->setCoreModule(0)
	->save();

$job_type_module_title = MK_RecordManager::getNewRecord( $module_field_type->getId() );
$job_type_module_title
	->setOrder(2)
	->setModuleId( $job_type_module->getId() )
	->setName('title')
	->setLabel('Title')
	->setType('')
	->setEditable(1)
	->setDisplayWidth('70%')
	->setTooltip('')
	->setFieldset('')
	->setSpecificSearch(0)
	->save();

$job_type_module_title_validation = MK_RecordManager::getNewRecord( $module_field_validation_type->getId() );
$job_type_module_title_validation
	->setName('unique')
	->setFieldId($job_type_module_title->getId())
	->save();

// Job Catgories
$job_category_module = MK_RecordManager::getNewRecord( $module_type->getId() );
$job_category_module
	->setName('Categories')
	->setTable('jobs_categories')
	->setSlug('categories')
	->setParentModuleId( $job_module->getId() )
	->setFieldUid(0)
	->setFieldSlug(0)
	->setFieldParent(0)
	->setFieldOrderby(0)
	->setOrderbyDirection('ASC')
	->setManagementWidth('20%')
	->setType('job_category')
	->setLocked(0)
	->setLockRecords(0)
	->setCoreModule(0)
	->save();

$job_category_module_title = MK_RecordManager::getNewRecord( $module_field_type->getId() );
$job_category_module_title
	->setOrder(2)
	->setModuleId( $job_category_module->getId() )
	->setName('title')
	->setLabel('Title')
	->setType('')
	->setEditable(1)
	->setDisplayWidth('70%')
	->setTooltip('')
	->setFieldset('')
	->setSpecificSearch(0)
	->save();

$job_category_module_title_validation = MK_RecordManager::getNewRecord( $module_field_validation_type->getId() );
$job_category_module_title_validation
	->setName('unique')
	->setFieldId($job_category_module_title->getId())
	->save();

$job_category_module_parent_cateogry = MK_RecordManager::getNewRecord( $module_field_type->getId() );
$job_category_module_parent_cateogry
	->setOrder(3)
	->setModuleId( $job_category_module->getId() )
	->setName('parent_category')
	->setLabel('Parent Category')
	->setType('job_category')
	->setEditable(1)
	->setDisplayWidth('')
	->setTooltip('')
	->setFieldset('')
	->setSpecificSearch(0)
	->save();

// Job Applications
$job_application_module = MK_RecordManager::getNewRecord( $module_type->getId() );
$job_application_module
	->setName('Applications')
	->setTable('jobs_applications')
	->setSlug('applications')
	->setParentModuleId( $job_module->getId() )
	->setFieldUid(0)
	->setFieldSlug(0)
	->setFieldParent(0)
	->setFieldOrderby(0)
	->setOrderbyDirection('DESC')
	->setManagementWidth('20%')
	->setType('job_application')
	->setLocked(0)
	->setLockRecords(0)
	->setCoreModule(0)
	->save();

$job_application_module_cv = MK_RecordManager::getNewRecord( $module_field_type->getId() );
$job_application_module_cv
	->setOrder(2)
	->setModuleId( $job_application_module->getId() )
	->setName('cv')
	->setLabel('CV')
	->setType('file_standard')
	->setEditable(1)
	->setDisplayWidth('')
	->setTooltip('')
	->setFieldset('')
	->setSpecificSearch(0)
	->save();

$job_application_module_cv_validation = MK_RecordManager::getNewRecord( $module_field_validation_type->getId() );
$job_application_module_cv_validation
	->setName('unique')
	->setFieldId($job_application_module_cv->getId())
	->save();

$job_application_module_user = MK_RecordManager::getNewRecord( $module_field_type->getId() );
$job_application_module_user
	->setOrder(3)
	->setModuleId( $job_application_module->getId() )
	->setName('user')
	->setLabel('Applicant')
	->setType('user')
	->setEditable(1)
	->setDisplayWidth('20%')
	->setTooltip('')
	->setFieldset('')
	->setSpecificSearch(1)
	->save();

$job_application_module_job = MK_RecordManager::getNewRecord( $module_field_type->getId() );
$job_application_module_job
	->setOrder(4)
	->setModuleId( $job_application_module->getId() )
	->setName('job')
	->setLabel('Job')
	->setType('job')
	->setEditable(1)
	->setDisplayWidth('')
	->setTooltip('')
	->setFieldset('')
	->setSpecificSearch(1)
	->save();

$job_application_module_message = MK_RecordManager::getNewRecord( $module_field_type->getId() );
$job_application_module_message
	->setOrder(6)
	->setModuleId( $job_application_module->getId() )
	->setName('message')
	->setLabel('Covering Letter')
	->setType('textarea_large')
	->setEditable(1)
	->setDisplayWidth('')
	->setTooltip('')
	->setFieldset('')
	->setSpecificSearch(0)
	->save();

$job_application_module_date_posted = MK_RecordManager::getNewRecord( $module_field_type->getId() );
$job_application_module_date_posted
	->setOrder(5)
	->setModuleId( $job_application_module->getId() )
	->setName('date_posted')
	->setLabel('Date Posted')
	->setType('datetime_now')
	->setEditable(1)
	->setDisplayWidth('')
	->setTooltip('')
	->setFieldset('')
	->setSpecificSearch(0)
	->save();

// Update based on inserts
$job_module
	->setFieldSlug($job_module_title->getId())
	->setFieldOrderby($job_module_date_posted->getId())
	->save();

$job_type_module
	->setFieldSlug($job_module_title->getId())
	->setFieldOrderby($job_module_title->getId())
	->save();

$job_category_module
	->setFieldSlug($job_category_module_title->getId())
	->setFieldOrderby($job_category_module_title->getId())
	->setFieldParent($job_category_module_parent_cateogry->getId())
	->save();

$job_application_module
	->setFieldSlug($job_application_module_date_posted->getId())
	->setFieldOrderby($job_application_module_date_posted->getId())
	->save();

$new_job_type = MK_RecordManager::getNewRecord( $job_type_module->getId() );
$new_job_type
	->setTitle('Full Time')
	->save();

$new_job_type = MK_RecordManager::getNewRecord( $job_type_module->getId() );
$new_job_type
	->setTitle('Part Time')
	->save();

$new_job_type = MK_RecordManager::getNewRecord( $job_type_module->getId() );
$new_job_type
	->setTitle('Freelance')
	->save();

?>