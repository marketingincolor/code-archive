<?php
class MK_RecordJob extends MK_Record
{

	public function save($update_meta = true)
	{
		$config = MK_Config::getInstance();

		$tags = explode(',', $this->getTags());
		$tags = array_map('trim', $tags);
		$tags = array_filter($tags);
		$tags = array_unique($tags);
		sort($tags);
		$tags = implode(', ', $tags);
		$this->setTags($tags);
		
		parent::save($update_meta);
		
	}

}

?>