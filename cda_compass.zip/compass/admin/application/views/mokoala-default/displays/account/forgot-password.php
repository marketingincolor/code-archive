<div class="block">
	<h2>Forgot Password</h2>
<?php print $this->password_reset_form; ?>
</div>