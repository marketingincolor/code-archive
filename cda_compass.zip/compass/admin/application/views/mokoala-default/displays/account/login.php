<div class="block">
	<h2>Login</h2>
    <p>Please enter your credentials, below, to login to the CMS!</p>
	<?php print $this->login_form; ?>
</div>