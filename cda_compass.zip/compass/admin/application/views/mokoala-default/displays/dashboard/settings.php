
<div class="block">
    <h2>Dashboard / Settings</h3>
<?php
	print $this->form;
?>
</div>