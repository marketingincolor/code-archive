<div class="block">
<h2>Installation</h2>
    <h3>Step 2: Site Details</h3>
    <p>Now that we've got the database connected let's configure your site..!</p>
	<?php print $this->install_form; ?>
</div>

