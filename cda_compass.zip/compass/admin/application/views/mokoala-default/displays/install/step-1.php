<div class="block">
    <h2>Installation</h2>
    <h3>Step 1: Database</h3>
    <p>Please enter the login details for the database that <strong><?php print $this->getCoreName(); ?></strong> will use.</p>
<?php print $this->install_form; ?>
</div>