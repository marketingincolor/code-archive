<div class="block">
    <h2>Error</h2>
    <p class="simple-message simple-message-error"><?php print $this->error; ?></p>
    <p class="simple-message simple-message-information"><?php print $this->error_trace; ?></p>
</div>
