<?php
require 'conn.php';
session_start();
$app_no = $_SESSION['APPLICATIONID'];
$email = $_SESSION['EMAILID'];

$app_no = $_GET['id'];

$app_no = '';

require 'dompdf/dompdf_config.inc.php';


if (strlen($app_no) < 1)

	$sql = "Select id, app_no from pageone order by id desc limit 1";
	$result = mysql_query($sql);
	$members = mysql_fetch_array($result,MYSQL_ASSOC);
   
	$app_no= $members['app_no'];
	
// generating the pdf and saving it
$html = file_get_contents('http://www.compasshrm.com/employment/template.php?app_no='.$app_no);

$dompdf = new DOMPDF();
$dompdf->load_html($html);
$dompdf->render();
//$dompdf->stream("sample.pdf");
$pdfoutput = $dompdf->output();
$filename = "app_pdf/".$app_no.".pdf";
$fp = fopen($filename, "w");
fwrite($fp, $pdfoutput);
fclose($fp); 

//echo "File Created!";

/****************************************************************
// mailing the pdf as attachment
$file = "app_pdf/".$app_no.".pdf";
$file_size = filesize($file);
$handle = fopen($file, "r");
$content = fread($handle, $file_size);
fclose($handle);
$content = chunk_split(base64_encode($content));
$name = basename($file);
$mail_to = $email;
$from_mail = "ashif@care.fm";
$from_name = "Ashif Iqbal";
//$reply_to = "noreply@agranibank.org";
$subject = "Your Application Attached! Ref - ".$app_no;
$message = "<html><body><p>Dear Sir,</p><p>Please find herewith your job application.</p><p>All the best !</p><br />Human Resources Department<br />The Villages<br /></body></html>";
// Set the email header ...
// Generate a boundary
$boundary = md5(uniqid(time()));

// Email header
$header = "From: ".$from_name." <".$from_mail.">\r\n";
//$header .= "Reply-To: ".$reply_to."\r\n";
//$header .= "CC: "."ashifiqbal@yahoo.com"."\r\n";
$header .= "MIME-Version: 1.0\r\n";

// Multipart wraps the Email Content and Attachment
$header .= "Content-Type: multipart/mixed; boundary=\"".$boundary."\"\r\n";
$header .= "This is a multi-part message in MIME format.\r\n";
$header .= "--".$boundary."\r\n";
$header .= "Content-type:text/html; charset=UTF-8\r\n";
$header .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
$header .= $message."\r\n\r\n";
$header .= "--".$boundary."\r\n";
$header .= "Content-Type: application/pdf; name=\"".$file."\"\r\n"; // use different content types here
$header .= "Content-Transfer-Encoding: base64\r\n";
$header .= "Content-Disposition: attachment; filename=\"".$app_no.".pdf"."\"\r\n\r\n";
$header .= $content."\r\n\r\n";
$header .= "--".$boundary."\r\n";

// Email content
// Content-type can be text/plain or text/html

// Send email
if (mail($mail_to, $subject, "", $header))
{
	echo "Your Application is Received, Thank You !";
	echo "Mail Sending ... OK";
	
}
else
{
	echo "Mail Sending ... Error";
}

*******************************************************/


$downloadpath = "http://www.compasshrm.com/employment/app_pdf/".$app_no.".pdf";
$subject = "New Employment Application Submitted.";
$message = "\n\nDownload the submitted job application <a href='".$downloadpath."'>here.</a>\n\nHuman Resources Department\nCompass HRM";
$tank_you_url = "http://www.compasshrm.com/employment/thanks.htm";

$headers = 'From: employment@compasshrm.com' . "\r\n" .
			'CC: employment@compasshrm.com' . "\r\n" .
			'Content-type: text/html; charset=iso-8859-1' . "\r\n" .
			'X-Mailer: PHP/' . phpversion();

if (mail($email, $subject, $message, $headers))
{
	header("Location: ".$tank_you_url);exit;
}
else
{
	echo "There was an error sending this application, please contact technical support...(Mail Sending ... Error)";
}
?>