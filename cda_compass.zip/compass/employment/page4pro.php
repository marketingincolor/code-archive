<?php
session_start();
require 'conn.php';

$app_no = $_POST['app_no'];

if (strlen($app_no) < 1)
{
	$sql = "Select id, app_no from pageone order by id desc limit 1";
	$result = mysql_query($sql);
	$members = mysql_fetch_array($result,MYSQL_ASSOC);
   
	$app_no= $members['app_no'];
}


$ifmilitary = $_POST['ifmilitary'];
$militarybr = $_POST['militarybr'];
$militarybegin = $_POST['militarybegin'];

$depdt = explode("/",$militarybegin);
$militarybegin = $depdt[2]."-".$depdt[0]."-".$depdt[1];

$militaryend = $_POST['militaryend'];

$depdt = explode("/",$militaryend);
$militaryend = $depdt[2]."-".$depdt[0]."-".$depdt[1];

$militarydchrg = $_POST['militarydchrg'];

$depdt = explode("/",$militarydchrg);
$militarydchrg = $depdt[2]."-".$depdt[0]."-".$depdt[1];

$term1 = $_POST['term1'];
$term2 = $_POST['term2'];





$sql = "insert into pagefour (app_no, ifmilitary, militarybr, militarybegin, militaryend, militarydchrg, term1, term2) values ('$app_no', '$ifmilitary', '$militarybr', '$militarybegin', '$militaryend', '$militarydchrg', '$term1', '$term2')";
$res = mysql_query($sql);

if($res)
{
	$url = "location: page5.php?id=" . $_POST['app_no'];
	header($url);
}
else
{
	echo "<b><font color='red'>There was a problem</font></b>";
}

?>