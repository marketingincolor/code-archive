<?php
session_start();
$app_no = $_SESSION['APPLICATIONID'];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>The Villages - Apply Online</title>

<script type="text/javascript">
    var textfield=document.createElement("input")
    textfield.setAttribute("type", "text")
    if (textfield.type!="text"){ //if browser doesn't support input type="text", load files for jQuery UI text Picker
        document.write('<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css" />\n')
        document.write('<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"><\/script>\n')
        document.write('<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"><\/script>\n')
    }
	$("#textpicker").formattext('mm/dd/yyyy');
</script>



<style>
body {
	font-family:Arial, Helvetica, sans-serif;
	font-size:11px;
	
}
</style>

</head>

<body>
<div id="data" name="data" style="margin-left:auto;margin-right:auto; width:954px; height:331px">


<form action="page2pro.php" method="post">
<font style="font-size: 18px;"><strong>PAGE 2</strong></font><BR /><BR />
<b>ALL FORMER EMPLOYERS: </b>(List most recent job first) Account for all the periods including <b>unemployment, self-employment and military service.</b><BR /><BR /><BR /><hr />



<table border="0" width="100%">
	<tr>
		<td width="52%" colspan="2"><strong>Employer</strong>:		  <input type="text" name="employer1" id="employer1" size="56" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td width="27%"><strong>From</strong>:
<input type="date" style="width: 123;height:21; background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;" id="emp1_from" name="emp1_from" onBlur="validateDate('emp1_from')" /></td>
		<td width="20%"><strong>To</strong>:
<input type="date" style="width: 122;height:21; background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;" id="emp1_to" name="emp1_to" onBlur="validateDate('emp1_to')"/></td>
	</tr>
	<tr>
		<td width="28%"><strong>Address</strong>:
<input type="text" name="emp1_address" id="emp1_address" size="26" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td width="23%"><strong>City</strong>:
<input type="text" name="emp1_city" id="emp1_city" size="21" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td width="27%"><strong>State</strong>:
<input type="text" name="emp1_state" id="emp1_state" size="23" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td width="20%"><strong>Zip</strong>:
<input type="text" name="emp1_zip" id="emp1_zip" size="22" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
	</tr>
	<tr>
		<td colspan="2"><strong>Job Title</strong>:
<input type="text" name="emp1_title" id="emp1_title" size="57" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td width="47%" colspan="2"><strong>Salary</strong>:
<input type="text" name="emp1_salary" id="emp1_salary" size="22" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
	</tr>
	<tr>
		<td width="52%" colspan="2"><strong>Immediate Supervisor</strong>:
<input type="text" name="emp1_boss" id="emp1_boss" size="41" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td width="47%" colspan="2"><strong>Telephone Number</strong>:		  <input type="text" name="emp1_phone" id="emp1_phone" size="34" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
	</tr>
	<tr>
		<td width="52%" colspan="2"><strong>Principal Duties</strong>:
<input type="text" name="emp1_duties" id="emp1_duties" size="48" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td width="47%" colspan="2"><strong>Reason for Leaving</strong>:
<input type="text" name="emp1_reason" id="emp1_reason" size="33" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
	</tr>
</table>
<hr />
<p></p>
<table border="0" width="100%">
	<tr>
		<td width="52%" colspan="2"><strong>Employer</strong>:		  <input type="text" name="employer2" id="employer2" size="56" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td width="26%"><strong>From</strong>:
<input type="date" style="width: 118;height:21; background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;" id="emp2_from" name="emp2_from" onBlur="validateDate('emp2_from')"/></td>
		<td width="20%"><strong>To</strong>:
<input type="date" style="width: 122;height:21; background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;" id="emp2_to" name="emp2_to" onBlur="validateDate('emp2_to')"/></td>
	</tr>
	<tr>
		<td width="28%"><strong>Address</strong>:
<input type="text" name="emp2_address" id="emp2_address" size="25" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td width="23%"><strong>City</strong>:
<input type="text" name="emp2_city" id="emp2_city" size="21" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td width="26%"><strong>State</strong>:
<input type="text" name="emp2_state" id="emp2_state" size="23" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td width="20%"><strong>Zip</strong>:
<input type="text" name="emp2_zip" id="emp2_zip" size="22" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
	</tr>
	<tr>
		<td colspan="2"><strong>Job Title</strong>:
<input type="text" name="emp2_title" id="emp2_title" size="56" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td width="47%" colspan="2"><strong>Salary</strong>:
<input type="text" name="emp2_salary" id="emp2_salary" size="22" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
	</tr>
	<tr>
		<td width="52%" colspan="2"><strong>Immediate Supervisor</strong>:
<input type="text" name="emp2_boss" id="emp2_boss" size="40" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td width="47%" colspan="2"><strong>Telephone Number</strong>:		  <input type="text" name="emp2_phone" id="emp2_phone" size="33" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
	</tr>
	<tr>
		<td width="52%" colspan="2"><strong>Principal Duties</strong>:
<input type="text" name="emp2_duties" id="emp2_duties" size="48" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td width="47%" colspan="2"><strong>Reason for Leaving</strong>:
<input type="text" name="emp2_reason" id="emp2_reason" size="32" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
	</tr>
</table>
<hr />
<p></p>
<table border="0" width="100%">
	<tr>
		<td width="52%" colspan="2"><strong>Employer</strong>:		  <input type="text" name="employer3" id="employer3" size="56" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td width="26%"><strong>From</strong>:
<input type="date" style="width: 114;height:21; background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;" id="emp3_from" name="emp3_from" onBlur="validateDate('emp3_from')"/></td>
		<td width="20%"><strong>To</strong>:
<input type="date" style="width: 122;height:21; background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;" id="emp3_to" name="emp3_to" onBlur="validateDate('emp3_to')"/></td>
	</tr>
	<tr>
		<td width="28%"><strong>Address</strong>:
<input type="text" name="emp3_address" id="emp3_address" size="25" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td width="23%"><strong>City</strong>:
<input type="text" name="emp3_city" id="emp3_city" size="21" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td width="26%"><strong>State</strong>:
<input type="text" name="emp3_state" id="emp3_state" size="22" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td width="20%"><strong>Zip</strong>:
<input type="text" name="emp3_zip" id="emp3_zip" size="22" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
	</tr>
	<tr>
		<td colspan="2"><strong>Job Title</strong>:
<input type="text" name="emp3_title" id="emp3_title" size="56" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td width="47%" colspan="2"><strong>Salary</strong>:
<input type="text" name="emp3_salary" id="emp3_salary" size="21" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
	</tr>
	<tr>
		<td width="52%" colspan="2"><strong>Immediate Supervisor</strong>:
<input type="text" name="emp3_boss" id="emp3_boss" size="40" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td width="47%" colspan="2"><strong>Telephone Number</strong>:		  <input type="text" name="emp3_phone" id="emp3_phone" size="34" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
	</tr>
	<tr>
		<td width="52%" colspan="2"><strong>Principal Duties</strong>:
<input type="text" name="emp3_duties" id="emp3_duties" size="48" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td width="47%" colspan="2"><strong>Reason for Leaving</strong>:
<input type="text" name="emp3_reason" id="emp3_reason" size="33" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
	</tr>
</table>
<p></p>
<hr />
<p align="justify">List any professional license, registration or certification you posses:</p>
<table border="0" width="100%">
	<tr>
		<td align="center" width="219"><strong>Type</strong></td>
		<td align="center" width="234"><strong>State Issued</strong></td>
		<td align="center" width="215"><strong>Expiration text</strong></td>
		<td align="center"><strong>Number</strong></td>
	</tr>
	<tr>
		<td align="center" width="219">
		

		
		<input type="text" name="pro_type1" id="pro_type1" size="26" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;" ></td>
		<td align="center" width="234">
		
		<input type="text" name="pro_state1" id="pro_state1" size="22" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td align="center" width="215">
		<input type="date" name="pro_expiry1" id="pro_expiry1" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td align="center">

		<input name="pro_num1" id="pro_num1" size="34" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;" ></td>
	</tr>
	<tr>
		<td align="center" width="219">
		

		
		<input type="text" name="pro_type2" id="pro_type2" size="26" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td align="center" width="234">
		
		<input type="text" name="pro_state2" id="pro_state2" size="22" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td align="center" width="215">
		<input type="date" name="pro_expiry2" id="pro_expiry2" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td align="center">
		<input name="pro_num2" id="pro_num2" size="34" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
	</tr>
	<tr>
		<td align="center" width="219">
		
	
		
		<input type ="text" name="pro_type3" id="pro_type3" size="26" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td align="center" width="234">
		
		<input type="text" name="pro_state3" id="pro_state3" size="22" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td align="center" width="215">
		<input type="date" name="pro_expiry3" id="pro_expiry3" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td align="center">
		<input name="pro_num3" id="pro_num3" size="34" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
	</tr>
	<tr>
		<td align="center" width="219">
		
		<input type="text" name="pro_type4" id="pro_type4" size="26" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td align="center" width="234">
	
		<input type="text" name="pro_state4" id="pro_state4" size="23" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td align="center" width="215">
		<input type="date" name="pro_expiry4" id="pro_expiry4" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
		<td align="center">
		<input name="pro_num4" id="pro_num4" size="34" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"></td>
	</tr>
</table>
<input type="hidden" name="app_no" id="app_no" value="<?php echo $app_no; ?>" />
<p align="right"><input type="image" src="images/NextButton.gif" /></p>

</form>
</div>
</body>

</html>