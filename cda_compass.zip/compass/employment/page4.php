<?php
session_start();
$app_no = $_SESSION['APPLICATIONID'];

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
<script type="text/javascript" src="http://jqueryjs.googlecode.com/files/jquery-1.3.2.min.js"></script>
<script type="text/javascript">
function showImage(){
$("#loadingImage").toggle();
$("#loadingImage2").toggle();
}

</script>

<SCRIPT type=text/javascript>
//This function is used to validate date in the format dd/mm/yyyy (U.K. style)
//dtControl is the client id of the control which contains the date

function validateDate(dtControl)
{
    var input = document.getElementById(dtControl)
    var validformat=/^\d{1,2}\/\d{1,2}\/\d{4}$/ //Basic check for format validity
    var returnval=false
    if (!validformat.test(input.value))
    alert('Invalid Date Format. Correct Format is MM/DD/YYYY.')
    else{ //Detailed check for valid date ranges
    var dayfield=input.value.split("/")[0]
    var monthfield=input.value.split("/")[1]
    var yearfield=input.value.split("/")[2]
   
    var dayobj = new Date(yearfield, monthfield-1, dayfield)
    if ((dayobj.getMonth()+1!=monthfield)||(dayobj.getDate()!=dayfield)||(dayobj.getFullYear()!=yearfield))
		returnval=true
    else
    {
        returnval=true
    }
    }
    if (returnval==false) input.focus()
    return returnval
}
</SCRIPT>

<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>The Villages - Apply Online</title>

<script type="text/javascript">
    var datefield=document.createElement("input")
    datefield.setAttribute("type", "date")
    if (datefield.type!="date"){ //if browser doesn't support input type="date", load files for jQuery UI Date Picker
        document.write('<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css" />\n')
        document.write('<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"><\/script>\n')
        document.write('<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"><\/script>\n')
    }
</script>
<link rel="stylesheet" href="css/validationEngine.jquery.css" type="text/css"/>


<script src="js/jquery/jquery-1.6.min.js" type="text/javascript"></script>
<!--script src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.js" type="text/javascript"></script-->
<script src="js/jquery/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8"></script> 
<script src="js/jquery/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>

<script>
$(document).ready(function(){
	$("#pagefour").validationEngine();
   });
</script>

<style>
body {
	font-family:Arial, Helvetica, sans-serif;
	font-size:11px;
	
}
</style>

</head>

<body>
<div id="data" name="data" style="margin-left:auto;margin-right:auto; width:954px; height:331px">


<form id="pagefour" action="page4pro.php" method="post">
<font style="font-size: 18px;"><strong>PAGE 4</strong></font> Last page in the application process.<? echo $app_no; ?><BR /><BR />

Are you a veteran of the U.S. Military Services? 
<input type="radio" name="ifmilitary" value="yes" />Yes <input type="radio" name="ifmilitary" value="no" />No
<p>If yes, what branch of Service?  
<input type="text" id="militarybr" name="militarybr" size="60" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;" /> </p>
<p>If yes, beginning date:  
<input type="text" id="militarybegin" name="militarybegin" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;" />
 Ending date of active duty: <input type="text" onBlur="validateDate('militaryend')" id="militaryend" name="militaryend" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/> </p>

<p>Date of discharge from Military Service:  
<input type="text" onBlur="validateDate('militarydchrg')" id="militarydchrg" name="militarydchrg" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/> </p>
<hr />
<p><b>NOTICE TO APPLICANTS:</b></p>
<p>This employer complies with the Americans With Disabilities Act of 1990. During the interview process, you will be asked questions concerning your ability to perform job-related functions. If you are given a conditional offer of employment, you may be required to complete a post-job offer medical history questionnaire and/or undergo examination. If required, all entering employees in the same job category will be subject to the same medical questionnaire and/or examination and all information will be kept confidential and in separate files.</p>
<p><i><b>IMPORTANT:</b> We are glad you are interested in joining The Villages 
family. Please read the following statements carefully before you sign and 
return your application:</i></p>
<p>The Villages, in considering my application for employment, you may verify the 
information set forth on this application and obtain additional information 
relating to my background, driving and criminal history records, I authorize all 
persons, school, companies, corporations, credit bureaus, and law enforcement 
agencies to supply any information concerning my background. This includes 
authorizing the release of information about non-judicial punishment that might 
have occurred in the Air Force, Army, Navy, Marine, National Guard, or any other 
branch of the Military Service.</p>
<p><input type="checkbox" class="validate[required]" name="term1" id="term1" value="yes" checked> I have read, understand, and agree to this statement.</p>
<p><b>I certify that the information on this application is correct and understand 
that any misrepresentation or omission of any information will result in my 
disqualification from consideration for employemnt or, if employed, my 
dismissal.</b> I understand that this application is not a contract, offer, or 
promise of employment and that if hired, I will be able to resign at any time 
for any reason. Likewise, The Villages can terminate my employment at any time 
with or without cause.</p>
<p><input type="checkbox" class="validate[required]" name="term2" id="term2" value="yes" checked>I have read, understand, and agree to this statement.
</p>
<p>I understand that this application is good for only 60 days from today&#39;s 
date. If I still desire a position with the company after this application 
expires, it will be my responsibility to reactivate my application and file it 
with the company. Otherwise the company will not consider me for employment 
after this application expires.</p>
<p>I also understand that if I recieve a preliminary offer of employment, I will 
be required to complete the application process by attending an additional 
un-paid 90 minute session (approximate) before I am eligible to become an 
employee. During this session, company benefits and philosophy are reviewed and 
related documents signed.</p>
<hr />
<p>This Employer is an equal employment opportunity employer. We also adhere to 
a policy of making employment decisions without regard to race, color, age, sex, 
religion, national origin, handicap, or martial status. We assure you that your 
opportunity for employment with this employer depends solely upon your 
qualification.</p>
<hr />
<BR /><BR />
<strong>Do not hit the back button for any reason until the form has been successfully completed. Thank you!</strong>

<input type="hidden" name="app_no" id="app_no" value="<?php echo $app_no; ?>" />
<p align="right"><input id="loadingImage2" type="image" src="images/submit.gif" onclick="showImage();"/><img id="loadingImage" src="ajax-loader.gif" style="display:none;"/></p>
<br/>
<br/>
<br/>
</form>
</div>
</body>

</html>