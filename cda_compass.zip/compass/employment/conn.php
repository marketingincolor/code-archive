<?php
	define('DB_HOST', 'compemploy.db.6590535.hostedresource.com');
    define('DB_USER', 'compemploy');
    define('DB_PASSWORD', 'Hill90210');
    define('DB_DATABASE', 'compemploy');
	
	//Connect to mysql server
	$link = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
	if(!$link) {
		die('Failed to connect to server: ' . mysql_error());
	}
	
	//Select database
	$db = mysql_select_db(DB_DATABASE);
	if(!$db) {
		die("Unable to select database");
	}
?>