<?php
$msg = $_GET['msg'];

if ($msg = "exists")
{
	echo "<b><font color='red'>The email address is already used !</font></b>";
}

?>