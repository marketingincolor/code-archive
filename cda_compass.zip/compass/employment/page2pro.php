<?php
session_start();
require 'conn.php';
require 'conn.php';

$app_no = $_SESSION['id'];

if (strlen($app_no) < 1)
{
	$sql = "Select id, app_no from pageone order by id desc limit 1";
	$result = mysql_query($sql);
	$members = mysql_fetch_array($result,MYSQL_ASSOC);
   
	$app_no= $members['app_no'];
}



$employer1 = $_POST['employer1'];
$emp1_from = $_POST['emp1_from'];

$depdt = explode("/",$emp1_from);
$emp1_from = $depdt[2]."-".$depdt[0]."-".$depdt[1];

$emp1_to = $_POST['emp1_to'];

$depdt = explode("/",$emp1_to);
$emp1_to = $depdt[2]."-".$depdt[0]."-".$depdt[1];

$emp1_address = $_POST['emp1_address'];
$emp1_city = $_POST['emp1_city'];
$emp1_state = $_POST['emp1_state'];
$emp1_zip = $_POST['emp1_zip'];
$emp1_title = $_POST['emp1_title'];
$emp1_salary = $_POST['emp1_salary'];
$emp1_boss = $_POST['emp1_boss'];
$emp1_phone = $_POST['emp1_phone'];
$emp1_duties = $_POST['emp1_duties'];
$emp1_reason = $_POST['emp1_reason'];

$employer2 = $_POST['employer2'];
$emp2_from = $_POST['emp2_from'];

$depdt = explode("/",$emp2_from);
$emp2_from = $depdt[2]."-".$depdt[0]."-".$depdt[1];

$emp2_to = $_POST['emp2_to'];

$depdt = explode("/",$emp2_to);
$emp2_to = $depdt[2]."-".$depdt[0]."-".$depdt[1];

$emp2_address = $_POST['emp2_address'];
$emp2_city = $_POST['emp2_city'];
$emp2_state = $_POST['emp2_state'];
$emp2_zip = $_POST['emp2_zip'];
$emp2_title = $_POST['emp2_title'];
$emp2_salary = $_POST['emp2_salary'];
$emp2_boss = $_POST['emp2_boss'];
$emp2_phone = $_POST['emp2_phone'];
$emp2_duties = $_POST['emp2_duties'];
$emp2_reason = $_POST['emp2_reason'];

$employer3 = $_POST['employer3'];
$emp3_from = $_POST['emp3_from'];

$depdt = explode("/",$emp3_from);
$emp3_from = $depdt[2]."-".$depdt[0]."-".$depdt[1];

$emp3_to = $_POST['emp3_to'];

$depdt = explode("/",$emp3_to);
$emp3_to = $depdt[2]."-".$depdt[0]."-".$depdt[1];

$emp3_address = $_POST['emp3_address'];
$emp3_city = $_POST['emp3_city'];
$emp3_state = $_POST['emp3_state'];
$emp3_zip = $_POST['emp3_zip'];
$emp3_title = $_POST['emp3_title'];
$emp3_salary = $_POST['emp3_salary'];
$emp3_boss = $_POST['emp3_boss'];
$emp3_phone = $_POST['emp3_phone'];
$emp3_duties = $_POST['emp3_duties'];
$emp3_reason = $_POST['emp3_reason'];

$pro_type1 = $_POST['pro_type1'];
$pro_state1 = $_POST['pro_state1'];
$pro_expiry1 = $_POST['pro_expiry1'];

$depdt = explode("/",$pro_expiry1);
$pro_expiry1 = $depdt[2]."-".$depdt[0]."-".$depdt[1];

$pro_num1 = $_POST['pro_num1'];

$pro_type2 = $_POST['pro_type2'];
$pro_state2 = $_POST['pro_state2'];
$pro_expiry2 = $_POST['pro_expiry2'];

$depdt = explode("/",$pro_expiry2);
$pro_expiry2 = $depdt[2]."-".$depdt[0]."-".$depdt[1];

$pro_num2 = $_POST['pro_num2'];

$pro_type3 = $_POST['pro_type3'];
$pro_state3 = $_POST['pro_state3'];
$pro_expiry3 = $_POST['pro_expiry3'];

$depdt = explode("/",$pro_expiry3);
$pro_expiry3 = $depdt[2]."-".$depdt[0]."-".$depdt[1];

$pro_num3 = $_POST['pro_num3'];

$pro_type4 = $_POST['pro_type4'];
$pro_state4 = $_POST['pro_state4'];
$pro_expiry4 = $_POST['pro_expiry4'];

$depdt = explode("/",$pro_expiry4);
$pro_expiry4 = $depdt[2]."-".$depdt[0]."-".$depdt[1];

$pro_num4 = $_POST['pro_num4'];


$sql = "insert into pagetwo (app_no, employer1, emp1_from, emp1_to, emp1_address, emp1_city, emp1_state, emp1_zip, emp1_title, emp1_salary, emp1_boss, emp1_phone, emp1_duties, emp1_reason, employer2, emp2_from, emp2_to, emp2_address, emp2_city, emp2_state, emp2_zip, emp2_title, emp2_salary, emp2_boss, emp2_phone, emp2_duties, emp2_reason, employer3, emp3_from, emp3_to, emp3_address, emp3_city, emp3_state, emp3_zip, emp3_title, emp3_salary, emp3_boss, emp3_phone, emp3_duties, emp3_reason, pro_type1, pro_state1, pro_expiry1, pro_num1, pro_type2, pro_state2, pro_expiry2, pro_num2, pro_type3, pro_state3, pro_expiry3, pro_num3, pro_type4, pro_state4, pro_expiry4, pro_num4) values ('$app_no', '$employer1', '$emp1_from', '$emp1_to', '$emp1_address', '$emp1_city', '$emp1_state', '$emp1_zip', '$emp1_title', '$emp1_salary', '$emp1_boss', '$emp1_phone', '$emp1_duties', '$emp1_reason', '$employer2', '$emp2_from', '$emp2_to', '$emp2_address', '$emp2_city', '$emp2_state', '$emp2_zip', '$emp2_title', '$emp2_salary', '$emp2_boss', '$emp2_phone', '$emp2_duties', '$emp2_reason', '$employer3', '$emp3_from', '$emp3_to', '$emp3_address', '$emp3_city', '$emp3_state', '$emp3_zip', '$emp3_title', '$emp3_salary', '$emp3_boss', '$emp3_phone', '$emp3_duties', '$emp3_reason', '$pro_type1', '$pro_state1', '$pro_expiry1', '$pro_num1', '$pro_type2', '$pro_state2', '$pro_expiry2', '$pro_num2', '$pro_type3', '$pro_state3', '$pro_expiry3', '$pro_num3', '$pro_type4', '$pro_state4', '$pro_expiry4', '$pro_num4')";
$res = mysql_query($sql);

if($res)
{
	$url = "location: page3.php?id=" . $app_no;
	header($url);
}
else
{
	echo "<b><font color='red'>There was a problem</font></b>";
}

function StripDate( $string ) {
	$string = str_replace('-', '', $string);
	$string = substr( $string, 0, 4);
}

?>