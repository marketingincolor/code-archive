
<?php

$link = mysql_connect('compemploy.db.6590535.hostedresource.com', 'compemploy', 'Hill90210');
if (!$link) {
  die('Not connected : ' . mysql_error());
}

// make foo the current db
$db_selected = mysql_select_db('compemploy', $link);
if (!$db_selected) {
  die ('Cannot use foo : ' . mysql_error());
}
?>