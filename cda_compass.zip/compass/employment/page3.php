<?php
session_start();
$app_no = $_SESSION['APPLICATIONID'];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>The Villages - Apply Online</title>

<script type="text/javascript">
    var datefield=document.createElement("input")
    datefield.setAttribute("type", "date")
    if (datefield.type!="date"){ //if browser doesn't support input type="date", load files for jQuery UI Date Picker
        document.write('<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css" />\n')
        document.write('<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"><\/script>\n')
        document.write('<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"><\/script>\n')
    }
</script>



<style>
body {
	font-family:Arial, Helvetica, sans-serif;
	font-size:11px;
	
}
</style>
</head>

<body>
<div id="data" name="data" style="margin-left:auto;margin-right:auto; width:954px; height:331px">


<form action="page3pro.php" method="post">

<font style="font-size: 18px;"><strong>PAGE 3</strong></font><BR /><BR />

Have you ever been dismissed or forced to resign from any employment ? 
<input type="radio" name="forceretire" value="yes" />Yes <input type="radio" name="forceretire" value="no" />No

<p>If yes, please explain: 
<input type="text" id="forcereason" name="forcereason" size="90" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/> </p>
<p>IN CASE OF EMERGENCY, NOTIFY:</p>
<table border="0" width="100%">
	<tr>
		<td width="28%"><strong>Name</strong>:
<input type="text" id="emergencyname" name="emergencyname" size="29" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></td>
		<td width="38%"><strong>Day Phone Number</strong>:
<input type="text" id="emergencyphone" name="emergencyphone" size="27" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></td>
		<td width="32%"><strong>Relationship</strong>:
<input type="text" id="emergencyrelation" name="emergencyrelation" size="27" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></td>
	</tr>
	<tr>
		<td colspan="2"><strong>Physical Address</strong>:
<input type="text" id="emergencyaddress" name="emergencyaddress" size="62" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;" /></td>
		<td width="32%"><strong>City / State</strong>:		  <input type="text" id="emergencycity" name="emergencycity" size="27" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;" /></td>
	</tr>
</table>




<p>Have you ever been convicted of any felonies? <input type="radio" name="felonies" value="yes"/>Yes <input type="radio" name="felonies" value="no"/>No <br /> If Yes, give city, state, dates, penalty imposed, and explain. A conviction will not necessarily disqualify you from employment:
</p>
<input type="text" id="felonyexp" name="felonyexp" size="140"  style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/>

<p>Have you ever been convicted of any type of theft or fraud or a violent 
crime? <input type="radio" name="violent" value="yes" />Yes <input type="radio" name="violent" value="no"/>No &nbsp; &nbsp; If Yes, give type of action and disposition of case:
</p>

<input type="text" id="violentexp" name="violentexp" size="140" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;" />
<hr />

<p>Do you have any friends or relatives who work in The Villages? 
<input type="radio" name="relativecol" value="yes"/>Yes <input type="radio" name="relativecol" value="no"/>No</p>
<table border="0" width="100%">
	<tr>
		<td><strong>Name</strong>:
<input type="text" id="relativecolname1" name="relativecolname1"  style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></td>
		<td><strong>Relationship</strong>:
<input type="text" id="relativecolrel1" name="relativecolrel1"  style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></td>
		<td><strong>Dept.</strong>:
<input type="text" id="relativecoldept1" name="relativecoldept1"  style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></td>
	</tr>
	<tr>
		<td><strong>Name</strong>:
<input type="text" id="relativecolname2" name="relativecolname2"  style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></td>
<td><strong>Relationship</strong>:
<input type="text" id="relativecolrel2" name="relativecolrel2"  style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></td>
		<td><strong>Dept.</strong>:
<input type="text" id="relativecoldept2" name="relativecoldept2"  style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></td>

	</tr>
</table>
<p>Are you now employed? 
<input type="radio" name="ifemp" value="yes"/>Yes <input type="radio" name="ifemp" value="no" />No</p>
<p>Are you on layoff? 
<input type="radio" name="iflay" value="yes" />Yes <input type="radio" name="iflay" value="no" />No</p>
<p>Are you subject to recall? 
<input type="radio" name="ifrecall" value="yes" />Yes <input type="radio" name="ifrecall" value="no" />No</p>
<p>May we contact your present employer? 
<input type="radio" name="ifcontact" value="yes" />Yes <input type="radio" name="ifcontact" value="no" />No</p>
<p>May we contact your previous employer? 
<input type="radio" name="ifcontactprev" value="yes" />Yes <input type="radio" name="ifcontactprev" value="no" />No</p>
<p>Please identify any exceptions and reasons for not contacting prior employers: 
<input type="text" name="contactres" id="contactres" size="49" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;" /></p>
<p>List three persons not related to you <b>who have supervised you.</b></p>

<table border="0" width="100%">
	<tr>
		<td align="center"><strong>Name</strong></td>
		<td align="center"><strong>Address</strong></td>
		<td align="center"><strong>Telephone</strong></td>
		<td align="center"><strong>Occupation</strong></td>
	</tr>
	<tr>
		<td align="center"><input type="text" id="refname1" name="refname1" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></td>
		<td align="center"><input type="text" id="refadd1" name="refadd1" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></td>
		<td align="center"><input type="text" id="refph1" name="refph1" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></td>
		<td align="center"><input type="text" id="refocu1" name="refocu1" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></td>
	</tr>
	<tr>
		<td align="center"><input type="text" id="refname2" name="refname2" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></td>
		<td align="center"><input type="text" id="refadd2" name="refadd2" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></td>
		<td align="center"><input type="text" id="refph2" name="refph2" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></td>
		<td align="center"><input type="text" id="refocu2" name="refocu2" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></td>
	</tr>
	<tr>
		<td align="center"><input type="text" id="refname3" name="refname3" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></td>
		<td align="center"><input type="text" id="refadd3" name="refadd3" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></td>
		<td align="center"><input type="text" id="refph3" name="refph3" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></td>
		<td align="center"><input type="text" id="refocu3" name="refocu3" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></td>
	</tr>
</table>
<p>List below any other information or remarks that you wish to have considered as a part of your application for employment:</p>
<textarea name="inforemark" id="inforemark" rows="2" cols="79" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; font-family:Arial, Helvetica, sans-serif; letter-spacing: normal; font-size:11px;"></textarea>
<p>Have you ever filed an application with any part of The Villages before? <input type="radio" name="appbefore" value="yes" />Yes <input type="radio" name="appbefore" value="no"/>No</p>
<p>Location: <input type="text" id="appbeforeloc" name="appbeforeloc" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;" /> &nbsp; If Yes, give Date: <input type="text" onBlur="validateDate('appbeforedate')" id="appbeforedate" name="appbeforedate" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></p>

<p>Have you ever been employed by any part of The Villages before? <input type="radio" name="appbeforepart" value="yes"/>Yes <input type="radio" name="appbeforepart" value="no"/>No</p>
<p>Location: <input type="text" id="appbeforepartloc" name="appbeforepartloc" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/> &nbsp; If Yes, give Date: <input type="text" onBlur="validateDate('appbeforepartdate')" id="appbeforepartdate" name="appbeforepartdate" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; outline: none; color: #000000; letter-spacing: normal;"/></p>
<p>Reason for leaving:</p>
<textarea name="leavingreason" id="leavingreason" cols="41" rows="2" style="background-color: #f8f8f8; border-radius: 5px; -webkit-border-radius: 5px; -moz-border-radius:5px; border:2px solid #d4d4d4; margin: 0 0 10px 0; padding: 7px; font-family:Arial, Helvetica, sans-serif; font-size:11px; outline: none; color: #000000; letter-spacing: normal;"></textarea>




<input type="hidden" name="app_no" id="app_no" value="<?php echo $app_no; ?>" />

<p align="right"><input type="image" src="images/NextButton.gif" /></p>

</form>
</div>
</body>

</html>