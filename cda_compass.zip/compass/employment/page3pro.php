<?php
session_start();
require 'conn.php';

$app_no = $_POST['app_no'];


if (strlen($app_no) < 1)
{
	$sql = "Select id, app_no from pageone order by id desc limit 1";
	$result = mysql_query($sql);
	$members = mysql_fetch_array($result,MYSQL_ASSOC);
   
	$app_no= $members['app_no'];
}


$forceretire = $_POST['forceretire'];
$forcereason = $_POST['forcereason'];
$emergencyname = $_POST['emergencyname'];
$emergencyphone = $_POST['emergencyphone'];
$emergencyrelation = $_POST['emergencyrelation'];
$emergencyaddress = $_POST['emergencyaddress'];
$emergencycity = $_POST['emergencycity'];
$felonies = $_POST['felonies'];
$felonyexp = $_POST['felonyexp'];
$violent = $_POST['violent'];
$violentexp = $_POST['violentexp'];
$relativecol = $_POST['relativecol'];
$relativecolname1 = $_POST['relativecolname1'];
$relativecolrel1 = $_POST['relativecolrel1'];
$relativecoldept1 = $_POST['relativecoldept1'];
$relativecolname2 = $_POST['relativecolname2'];
$relativecolrel2 = $_POST['relativecolrel2'];
$relativecoldept2 = $_POST['relativecoldept2'];
$ifemp = $_POST['ifemp'];
$iflay = $_POST['iflay'];
$ifrecall = $_POST['ifrecall'];
$ifcontact = $_POST['ifcontact'];
$ifcontactprev = $_POST['ifcontactprev'];
$contactres = $_POST['contactres'];
$refname1 = $_POST['refname1'];
$refadd1 = $_POST['refadd1'];
$refph1 = $_POST['refph1'];
$refocu1 = $_POST['refocu1'];
$refname2 = $_POST['refname2'];
$refadd2 = $_POST['refadd2'];
$refph2 = $_POST['refph2'];
$refocu2 = $_POST['refocu2'];
$refname3 = $_POST['refname3'];
$refadd3 = $_POST['refadd3'];
$refph3 = $_POST['refph3'];
$refocu3 = $_POST['refocu3'];
$inforemark = $_POST['inforemark'];
$appbefore = $_POST['appbefore'];
$appbeforeloc = $_POST['appbeforeloc'];
$appbeforedate = $_POST['appbeforedate'];

$depdt = explode("/",$appbeforedate);
$appbeforedate = $depdt[2]."-".$depdt[0]."-".$depdt[1];

$appbeforepart = $_POST['appbeforepart'];
$appbeforepartloc = $_POST['appbeforepartloc'];
$appbeforepartdate = $_POST['appbeforepartdate'];

$depdt = explode("/",$appbeforepartdate);
$appbeforepartdate = $depdt[2]."-".$depdt[0]."-".$depdt[1];

$leavingreason = $_POST['leavingreason'];


$sql = "insert into pagethree (app_no, forceretire, forcereason, emergencyname, emergencyphone, emergencyrelation, emergencyaddress, emergencycity, felonies, felonyexp, violent, violentexp, relativecol, relativecolname1, relativecolrel1, relativecoldept1, relativecolname2, relativecolrel2, relativecoldept2, ifemp, iflay, ifrecall, ifcontact, ifcontactprev, contactres, refname1, refadd1, refph1, refocu1, refname2, refadd2, refph2, refocu2, refname3, refadd3, refph3, refocu3, inforemark, appbefore, appbeforeloc, appbeforedate, appbeforepart, appbeforepartloc, appbeforepartdate, leavingreason) values ('$app_no', '$forceretire', '$forcereason', '$emergencyname', '$emergencyphone', '$emergencyrelation', '$emergencyaddress', '$emergencycity', '$felonies', '$felonyexp', '$violent', '$violentexp', '$relativecol', '$relativecolname1', '$relativecolrel1', '$relativecoldept1', '$relativecolname2', '$relativecolrel2', '$relativecoldept2', '$ifemp', '$iflay', '$ifrecall', '$ifcontact', '$ifcontactprev', '$contactres', '$refname1', '$refadd1', '$refph1', '$refocu1', '$refname2', '$refadd2', '$refph2', '$refocu2', '$refname3', '$refadd3', '$refph3', '$refocu3', '$inforemark', '$appbefore', '$appbeforeloc', '$appbeforedate', '$appbeforepart', '$appbeforepartloc', '$appbeforepartdate', '$leavingreason')";
$res = mysql_query($sql);

if($res)
{
	header("location: page4.php");
}
else
{
	echo "<b><font color='red'>There was a problem</font></b>";
}

?>