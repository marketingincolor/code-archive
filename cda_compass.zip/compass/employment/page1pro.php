<?php
session_set_cookie_params(0, '/', '.compasshrm.com');
session_start();
require 'conn.php';
$position = $_POST['position'];
$emp_type = $_POST['emp_type'];
$req_num = $_POST['reqnum'];
$emp_type_data = "";
foreach ($emp_type as $f)
{
	//echo $f;
	if ($emp_type_data)
	{
		$emp_type_data = $emp_type_data.", ".$f;
	}
	else
	{
		$emp_type_data = $f;
	}
}
$lname = $_POST['lname'];
$fname = $_POST['fname'];
$mname = $_POST['mname'];
$ssn = $_POST['ssn'];
$paddress = $_POST['paddress'];
$pcity = $_POST['pcity'];
$pcounty = $_POST['pcounty'];
$pstate = $_POST['pstate'];
$pzip = $_POST['pzip'];
$maddress = $_POST['maddress'];
$mcity = $_POST['mcity'];
$mcounty = $_POST['mcounty'];
$mstate = $_POST['mstate'];
$mzip = $_POST['mzip'];
$dphone = $_POST['dphone'];
$ephone = $_POST['ephone'];
$email = $_POST['email'];
$wpermit = $_POST['wpermit'];
$transport = $_POST['transport'];

$days = $_POST['days'];
$days_data ="";
foreach ($days as $f)
{
	if ($days_data)
	{
		$days_data = $days_data.", ".$f;
	}
	else
	{
		$days_data = $f;
	}
}

$shifts = $_POST['shifts'];
$shifts_data ="";
foreach ($shifts as $f)
{
	if ($shifts_data)
	{
		$shifts_data = $shifts_data.", ".$f;
	}
	else
	{
		$shifts_data = $f;
	}
}

$drvstate = $_POST['drvstate'];
$drvlicense = $_POST['drvlicense'];
$drvtype = $_POST['drvtype'];
$age = $_POST['age'];
$high_edu_add = $_POST['high_edu_add'];
$high_edu_degree = $_POST['high_edu_degree'];
$high_edu_date = $_POST['high_edu_date'];

$depdt = explode("/",$high_edu_date);
$high_edu_date = $depdt[2]."-".$depdt[0]."-".$depdt[1];

$high_edu_major = $_POST['high_edu_major'];
$col_edu_add = $_POST['col_edu_add'];
$col_edu_degree = $_POST['col_edu_degree'];
$col_edu_date = $_POST['col_edu_date'];

$depdt = explode("/",$col_edu_date);
$col_edu_date = $depdt[2]."-".$depdt[0]."-".$depdt[1];

$col_edu_major = $_POST['col_edu_major'];
$other_edu_add = $_POST['other_edu_add'];
$other_edu_degree = $_POST['other_edu_degree'];
$other_edu_date = $_POST['other_edu_date'];

$depdt = explode("/",$other_edu_date);
$other_edu_date = $depdt[2]."-".$depdt[0]."-".$depdt[1];

$other_edu_major = $_POST['other_edu_major'];
$speed = $_POST['speed'];
$prevname = $_POST['prevname'];
$prevparticular = $_POST['prevparticular'];
$prevdate = $_POST['prevdate'];

$depdt = explode("/",$prevdate);
$prevdate = $depdt[2]."-".$depdt[0]."-".$depdt[1];

/*
$duplicate = "select * from pageone where email='$email'";
$resdupli = mysql_query($duplicate);

if(mysql_num_rows($resdupli) >= 1)
{
	header("location: error.php?msg=exists");
}
else
{
*/
// inserting data into the database
$app_time = date("Y-m-d H:i:s");
$app_no = $email.$app_time;
$app_no = md5($app_no);
session_regenerate_id();
$_SESSION['APPLICATIONID'] = $app_no;
$_SESSION['EMAILID'] = $email;
session_write_close();
$sql = "insert into pageone (req_num, app_no, position, emp_type_data, lname, fname, mname, ssn, paddress, pcity, pcounty, pstate, pzip, maddress, mcity, mcounty, mstate, mzip, dphone, ephone, email, wpermit, transport, days_data, shifts_data, drvstate, drvlicense, drvtype, age, high_edu_add, high_edu_degree, high_edu_date, high_edu_major, col_edu_add, col_edu_degree, col_edu_date, col_edu_major, other_edu_add, other_edu_degree, other_edu_date, other_edu_major, speed, prevname, prevparticular, prevdate) values ('$req_num', '$app_no', '$position', '$emp_type_data', '$lname', '$fname', '$mname', '$ssn', '$paddress', '$pcity', '$pcounty', '$pstate', '$pzip', '$maddress', '$mcity', '$mcounty', '$mstate', '$mzip', '$dphone', '$ephone', '$email', '$wpermit', '$transport', '$days_data', '$shifts_data', '$drvstate', '$drvlicense', '$drvtype', '$age', '$high_edu_add', '$high_edu_degree', '$high_edu_date', '$high_edu_major', '$col_edu_add', '$col_edu_degree', '$col_edu_date', '$col_edu_major', '$other_edu_add', '$other_edu_degree', '$other_edu_date', '$other_edu_major', '$speed', '$prevname', '$prevparticular', '$prevdate')";


$res = mysql_query($sql);

if($res)
{
	$url = "location: page2.php?app_no=" . $app_no;
	$_SESSION['id']=$app_no;
	header($url);
}
else
{
	echo "<b><font color='red'>There was a problem</font></b>";
}
/*
}
*/
?>