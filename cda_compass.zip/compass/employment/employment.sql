-- phpMyAdmin SQL Dump
-- version 3.3.2deb1ubuntu1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 04, 2012 at 04:12 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.2-1ubuntu4.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `employment`
--

-- --------------------------------------------------------

--
-- Table structure for table `pagefour`
--

CREATE TABLE IF NOT EXISTS `pagefour` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_no` varchar(40) NOT NULL,
  `ifmilitary` varchar(255) NOT NULL,
  `militarybr` varchar(255) NOT NULL,
  `militarybegin` date NOT NULL,
  `militaryend` date NOT NULL,
  `militarydchrg` date NOT NULL,
  `term1` varchar(255) NOT NULL,
  `term2` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `pagefour`
--

INSERT INTO `pagefour` (`id`, `app_no`, `ifmilitary`, `militarybr`, `militarybegin`, `militaryend`, `militarydchrg`, `term1`, `term2`) VALUES
(3, 'f42a21776ea759d738c478eb336aa25a', 'yes', 'ffir', '2011-02-01', '2011-12-31', '2012-01-01', 'yes', 'yes'),
(2, 'fb03b1016a4a24f38981713460d7e280', 'no', 'dhaka', '2012-02-01', '2012-02-02', '2012-02-03', 'yes', 'yes'),
(4, '4c8ba35e96ca2bd5fa60616cf604286a', 'no', '', '0000-00-00', '0000-00-00', '0000-00-00', 'yes', ''),
(5, 'b76350b94a20437ec3bd606adb3cab20', 'no', '', '0000-00-00', '0000-00-00', '0000-00-00', 'yes', 'yes'),
(6, '32095c22f49d43b7f581e039350048c7', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '', ''),
(7, '99f48a0ec14cbf1c57d2f390ffa4f7ba', 'yes', 'explanation', '2012-02-13', '2012-02-07', '2012-02-15', 'yes', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `pageone`
--

CREATE TABLE IF NOT EXISTS `pageone` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_no` varchar(40) NOT NULL,
  `position` varchar(255) NOT NULL,
  `emp_type_data` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `mname` varchar(20) NOT NULL,
  `ssn` varchar(100) NOT NULL,
  `paddress` varchar(100) NOT NULL,
  `pcity` varchar(100) NOT NULL,
  `pcounty` varchar(100) NOT NULL,
  `pstate` varchar(100) NOT NULL,
  `pzip` varchar(10) NOT NULL,
  `maddress` varchar(100) NOT NULL,
  `mcity` varchar(100) NOT NULL,
  `mcounty` varchar(100) NOT NULL,
  `mstate` varchar(100) NOT NULL,
  `mzip` varchar(10) NOT NULL,
  `dphone` varchar(20) NOT NULL,
  `ephone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `wpermit` varchar(10) NOT NULL,
  `transport` varchar(10) NOT NULL,
  `days_data` varchar(255) NOT NULL,
  `shifts_data` varchar(255) NOT NULL,
  `drvstate` varchar(100) NOT NULL,
  `drvlicense` varchar(100) NOT NULL,
  `drvtype` varchar(100) NOT NULL,
  `age` varchar(10) NOT NULL,
  `high_edu_add` varchar(255) NOT NULL,
  `high_edu_degree` varchar(255) NOT NULL,
  `high_edu_date` date NOT NULL,
  `high_edu_major` varchar(255) NOT NULL,
  `col_edu_add` varchar(255) NOT NULL,
  `col_edu_degree` varchar(255) NOT NULL,
  `col_edu_date` date NOT NULL,
  `col_edu_major` varchar(255) NOT NULL,
  `other_edu_add` varchar(255) NOT NULL,
  `other_edu_degree` varchar(255) NOT NULL,
  `other_edu_date` date NOT NULL,
  `other_edu_major` varchar(255) NOT NULL,
  `speed` int(3) NOT NULL,
  `prevname` varchar(10) NOT NULL,
  `prevparticular` varchar(255) NOT NULL,
  `prevdate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `pageone`
--

INSERT INTO `pageone` (`id`, `app_no`, `position`, `emp_type_data`, `lname`, `fname`, `mname`, `ssn`, `paddress`, `pcity`, `pcounty`, `pstate`, `pzip`, `maddress`, `mcity`, `mcounty`, `mstate`, `mzip`, `dphone`, `ephone`, `email`, `wpermit`, `transport`, `days_data`, `shifts_data`, `drvstate`, `drvlicense`, `drvtype`, `age`, `high_edu_add`, `high_edu_degree`, `high_edu_date`, `high_edu_major`, `col_edu_add`, `col_edu_degree`, `col_edu_date`, `col_edu_major`, `other_edu_add`, `other_edu_degree`, `other_edu_date`, `other_edu_major`, `speed`, `prevname`, `prevparticular`, `prevdate`) VALUES
(5, '4c8ba35e96ca2bd5fa60616cf604286a', 'Engineer', 'Part Time, Full Time, Temporary', 'T', 'Velans', 'Dha', '9909', ' 77 may road', 'col', 'SL', 'Col', '13', '77/3 wasala road', 'col', 'sL', 'col', '03', '333111', '333555', 'dhanu_thomas@yahoo.com', 'yes', 'no', 'monday, tuesday, wednesday, thursday, saturday', 'evenings, nights', 'ny', 'lo25', 'all', 'yes', '', '', '0000-00-00', '', 'UNI', 'bSC', '2011-02-15', 'maths', '', '', '0000-00-00', '', 0, 'no', '', '0000-00-00'),
(4, 'f42a21776ea759d738c478eb336aa25a', 'QA', 'Full Time, Temporary', 'T', 'vel', 'D', '999', '7efg r', 'hij', 'kl', 'm', 'n', '8 rst u', 'v', 'w', 'x', 'yz', '3311', '3355', 'dhanu9@gmail.com', 'yes', 'no', 'saturday, sunday', 'days, evenings, nights', 'opq', 'rrs', 'uuu', 'yes', 'SBC', 'A/L', '2008-02-26', 'maths', 'NYU', 'B.E', '2011-05-10', 'maths', 'abc', 'bec', '2012-01-02', 'Computer', 67, 'yes', 'Vela D T', '2012-01-01'),
(3, 'fb03b1016a4a24f38981713460d7e280', 'test position', 'Part Time, Temporary', 'Ashif', 'Iqbal', 'none', '123456789', 'dhaka', 'dhaka', 'dhaka', 'dhaka', '1234', 'dhaka', 'dhaka', 'dhaka', 'dhaka', '1234', '1213456', '10223254', 'ashifiqbal@yahoo.com', 'yes', 'yes', 'monday, tuesday, thursday, sunday', 'days, evenings, nights', 'dhaka', 'light vehicle', 'car ike', 'yes', '', '', '0000-00-00', '', '', '', '0000-00-00', '', '', '', '0000-00-00', '', 0, '', '', '0000-00-00'),
(6, 'b76350b94a20437ec3bd606adb3cab20', 'arbitratry position', 'Part Time, Temporary', 'last', 'first', 'middle', '123456789', 'present', 'pcity', 'pcounty', 'pstate', '1234', 'madd', 'mcity', 'mcounty', 'mstate', '4321', '1234567', '7654321', 'ashifiqbal@yahoo.com', 'yes', 'yes', 'monday, wednesday, thursday, friday', 'evenings, nights', 'dhaka', 'light', 'car', 'yes', '', '', '0000-00-00', '', '', '', '0000-00-00', '', '', '', '0000-00-00', '', 0, 'no', '', '0000-00-00'),
(7, '32095c22f49d43b7f581e039350048c7', 'Accountant', 'Part Time', 'smith', 'Vela', 'v', '4', '5', '1', 'i', 'i', '12345678', '1', '5', '5', 'New York', '7', '123123', '3355', 'dhanu9@gmail.com', 'yes', 'yes', 'monday, tuesday', 'evenings, nights', 'i', '789', 'ooooo', 'yes', 'HSS', 'A/L', '2007-01-31', 'Maths', '', '', '0000-00-00', '', '', '', '0000-00-00', '', 0, 'no', '', '0000-00-00'),
(8, '99f48a0ec14cbf1c57d2f390ffa4f7ba', 'last check', 'Part Time, Temporary', 'lname', 'fname', 'mname', '123456', 'padd', 'pcit', 'pcou', 'psta', 'pzi', 'madd', 'mcit', 'mcou', 'msta', 'mzi', '123456', '789456', 'ashifiqbal@yahoo.com', 'yes', 'yes', 'monday, thursday, friday', 'days, evenings, nights', 'dhaka', 'light', 'car', 'yes', '1', '', '0000-00-00', '', '2', '', '0000-00-00', '', '3', '', '0000-00-00', '', 50, 'yes', 'prev name', '2012-02-01');

-- --------------------------------------------------------

--
-- Table structure for table `pagethree`
--

CREATE TABLE IF NOT EXISTS `pagethree` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_no` varchar(40) NOT NULL,
  `forceretire` varchar(255) NOT NULL,
  `forcereason` varchar(255) NOT NULL,
  `emergencyname` varchar(255) NOT NULL,
  `emergencyphone` varchar(255) NOT NULL,
  `emergencyrelation` varchar(255) NOT NULL,
  `emergencyaddress` varchar(255) NOT NULL,
  `emergencycity` varchar(255) NOT NULL,
  `felonies` varchar(255) NOT NULL,
  `felonyexp` varchar(255) NOT NULL,
  `violent` varchar(255) NOT NULL,
  `violentexp` varchar(255) NOT NULL,
  `relativecol` varchar(255) NOT NULL,
  `relativecolname1` varchar(255) NOT NULL,
  `relativecolrel1` varchar(255) NOT NULL,
  `relativecoldept1` varchar(255) NOT NULL,
  `relativecolname2` varchar(255) NOT NULL,
  `relativecolrel2` varchar(255) NOT NULL,
  `relativecoldept2` varchar(255) NOT NULL,
  `ifemp` varchar(255) NOT NULL,
  `iflay` varchar(255) NOT NULL,
  `ifrecall` varchar(255) NOT NULL,
  `ifcontact` varchar(255) NOT NULL,
  `ifcontactprev` varchar(255) NOT NULL,
  `contactres` varchar(255) NOT NULL,
  `refname1` varchar(255) NOT NULL,
  `refadd1` varchar(255) NOT NULL,
  `refph1` varchar(255) NOT NULL,
  `refocu1` varchar(255) NOT NULL,
  `refname2` varchar(255) NOT NULL,
  `refadd2` varchar(255) NOT NULL,
  `refph2` varchar(255) NOT NULL,
  `refocu2` varchar(255) NOT NULL,
  `refname3` varchar(255) NOT NULL,
  `refadd3` varchar(255) NOT NULL,
  `refph3` varchar(255) NOT NULL,
  `refocu3` varchar(255) NOT NULL,
  `inforemark` varchar(255) NOT NULL,
  `appbefore` varchar(255) NOT NULL,
  `appbeforeloc` varchar(255) NOT NULL,
  `appbeforedate` date NOT NULL,
  `appbeforepart` varchar(255) NOT NULL,
  `appbeforepartloc` varchar(255) NOT NULL,
  `appbeforepartdate` date NOT NULL,
  `leavingreason` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `pagethree`
--

INSERT INTO `pagethree` (`id`, `app_no`, `forceretire`, `forcereason`, `emergencyname`, `emergencyphone`, `emergencyrelation`, `emergencyaddress`, `emergencycity`, `felonies`, `felonyexp`, `violent`, `violentexp`, `relativecol`, `relativecolname1`, `relativecolrel1`, `relativecoldept1`, `relativecolname2`, `relativecolrel2`, `relativecoldept2`, `ifemp`, `iflay`, `ifrecall`, `ifcontact`, `ifcontactprev`, `contactres`, `refname1`, `refadd1`, `refph1`, `refocu1`, `refname2`, `refadd2`, `refph2`, `refocu2`, `refname3`, `refadd3`, `refph3`, `refocu3`, `inforemark`, `appbefore`, `appbeforeloc`, `appbeforedate`, `appbeforepart`, `appbeforepartloc`, `appbeforepartdate`, `leavingreason`) VALUES
(3, 'f42a21776ea759d738c478eb336aa25a', 'no', '', 'Maya', '8899', 'Mother', '78 uiop tyu', 'New york', 'no', '', 'yes', 'opppp', 'yes', 'SSE', 'oop', 'it', '', '', '', 'yes', 'no', 'no', 'yes', 'no', 'iiooo', 'uuuuuuii', 'yyy', '7744', 'ytr', 'pp', 'rr', 'uu', 'vv', 'qq', 'ss', '88', '', 'tuiiiiiiii', 'yes', 'op', '2011-01-31', 'no', '', '0000-00-00', ''),
(2, 'fb03b1016a4a24f38981713460d7e280', 'no', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '2', '', '', '', '3', '', '', '', '', 'no', '', '0000-00-00', 'no', '', '0000-00-00', 'space for reason for leaving'),
(4, '4c8ba35e96ca2bd5fa60616cf604286a', 'yes', 'bbbbbb', 'vvv', 'bb', 'g', 'bb', 'b', 'yes', 'fffssgg', 'yes', 'bbbbbgf ghhh hjjj78', 'no', '', '', '', '', '', '', 'yes', 'yes', 'no', 'no', 'no', 'g iuott endk', '', '', '', '', '', '', '', '', 'uijh', 'dfg44 ttt', '4365', 'ngjjjj hhh', 'gggg uu kkkk gr', 'no', '', '0000-00-00', 'yes', 'bbbbb', '2011-01-31', 'bbbbfg iiiiii'),
(5, 'b76350b94a20437ec3bd606adb3cab20', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '0000-00-00', ''),
(6, '32095c22f49d43b7f581e039350048c7', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '0000-00-00', ''),
(7, '99f48a0ec14cbf1c57d2f390ffa4f7ba', 'yes', 'explanation', 'my bro', '', 'bro', 'dhaka', 'dhaka', '', 'explanation', 'yes', 'not known', '', '1', '', 'nn', '2', '', 'mm', 'yes', 'no', 'yes', 'no', 'yes', 'explanation', '1', '', '', '', '2', '', '', '', '3', '', '', '', 'explanation', 'yes', 'new york', '2012-02-28', '', 'boston', '2012-02-27', 'explanation');

-- --------------------------------------------------------

--
-- Table structure for table `pagetwo`
--

CREATE TABLE IF NOT EXISTS `pagetwo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_no` varchar(40) NOT NULL,
  `employer1` varchar(255) NOT NULL,
  `emp1_from` date NOT NULL,
  `emp1_to` date NOT NULL,
  `emp1_address` varchar(255) NOT NULL,
  `emp1_city` varchar(255) NOT NULL,
  `emp1_state` varchar(255) NOT NULL,
  `emp1_zip` varchar(255) NOT NULL,
  `emp1_title` varchar(255) NOT NULL,
  `emp1_salary` int(11) NOT NULL,
  `emp1_boss` varchar(255) NOT NULL,
  `emp1_phone` int(11) NOT NULL,
  `emp1_duties` varchar(255) NOT NULL,
  `emp1_reason` varchar(255) NOT NULL,
  `employer2` varchar(255) NOT NULL,
  `emp2_from` date NOT NULL,
  `emp2_to` date NOT NULL,
  `emp2_address` varchar(255) NOT NULL,
  `emp2_city` varchar(255) NOT NULL,
  `emp2_state` varchar(255) NOT NULL,
  `emp2_zip` varchar(255) NOT NULL,
  `emp2_title` varchar(255) NOT NULL,
  `emp2_salary` int(11) NOT NULL,
  `emp2_boss` varchar(255) NOT NULL,
  `emp2_phone` int(11) NOT NULL,
  `emp2_duties` varchar(255) NOT NULL,
  `emp2_reason` varchar(255) NOT NULL,
  `employer3` varchar(255) NOT NULL,
  `emp3_from` date NOT NULL,
  `emp3_to` date NOT NULL,
  `emp3_address` varchar(255) NOT NULL,
  `emp3_city` varchar(255) NOT NULL,
  `emp3_state` varchar(255) NOT NULL,
  `emp3_zip` varchar(255) NOT NULL,
  `emp3_title` varchar(255) NOT NULL,
  `emp3_salary` int(11) NOT NULL,
  `emp3_boss` varchar(255) NOT NULL,
  `emp3_phone` int(11) NOT NULL,
  `emp3_duties` varchar(255) NOT NULL,
  `emp3_reason` varchar(255) NOT NULL,
  `pro_type1` varchar(255) NOT NULL,
  `pro_state1` varchar(255) NOT NULL,
  `pro_expiry1` date NOT NULL,
  `pro_num1` varchar(255) NOT NULL,
  `pro_type2` varchar(255) NOT NULL,
  `pro_state2` varchar(255) NOT NULL,
  `pro_expiry2` date NOT NULL,
  `pro_num2` varchar(255) NOT NULL,
  `pro_type3` varchar(255) NOT NULL,
  `pro_state3` varchar(255) NOT NULL,
  `pro_expiry3` date NOT NULL,
  `pro_num3` varchar(255) NOT NULL,
  `pro_type4` varchar(255) NOT NULL,
  `pro_state4` varchar(255) NOT NULL,
  `pro_expiry4` date NOT NULL,
  `pro_num4` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `pagetwo`
--

INSERT INTO `pagetwo` (`id`, `app_no`, `employer1`, `emp1_from`, `emp1_to`, `emp1_address`, `emp1_city`, `emp1_state`, `emp1_zip`, `emp1_title`, `emp1_salary`, `emp1_boss`, `emp1_phone`, `emp1_duties`, `emp1_reason`, `employer2`, `emp2_from`, `emp2_to`, `emp2_address`, `emp2_city`, `emp2_state`, `emp2_zip`, `emp2_title`, `emp2_salary`, `emp2_boss`, `emp2_phone`, `emp2_duties`, `emp2_reason`, `employer3`, `emp3_from`, `emp3_to`, `emp3_address`, `emp3_city`, `emp3_state`, `emp3_zip`, `emp3_title`, `emp3_salary`, `emp3_boss`, `emp3_phone`, `emp3_duties`, `emp3_reason`, `pro_type1`, `pro_state1`, `pro_expiry1`, `pro_num1`, `pro_type2`, `pro_state2`, `pro_expiry2`, `pro_num2`, `pro_type3`, `pro_state3`, `pro_expiry3`, `pro_num3`, `pro_type4`, `pro_state4`, `pro_expiry4`, `pro_num4`) VALUES
(3, 'f42a21776ea759d738c478eb336aa25a', 'AABB', '2011-02-01', '2012-02-01', '55opp', 'qqr', 'rrs', '87t', 'Engineer', 20000, 'xyz', 852, 'check', '321', 'CCDD', '2010-01-01', '2011-02-01', '67jui op', 'dfg', 'uui', '56210', 'QA', 15000, 'pqr', 889, 'uut', 'mmn', '', '0000-00-00', '0000-00-00', '', '', '', '', '', 0, '', 0, '', '', 'uu', 'ii', '0000-00-00', '678800', '', '', '0000-00-00', '', '', '', '0000-00-00', '', '', '', '0000-00-00', ''),
(2, 'fb03b1016a4a24f38981713460d7e280', '', '0000-00-00', '0000-00-00', '', '', '', '', '', 0, '', 0, '', '', '', '0000-00-00', '0000-00-00', '', '', '', '', '', 0, '', 0, '', '', '', '0000-00-00', '0000-00-00', '', '', '', '', '', 0, '', 0, '', '', '1', '', '2012-02-01', '', '2', '', '2012-02-02', '', '3', '', '2012-02-03', '', '4', '', '2012-02-04', ''),
(4, '4c8ba35e96ca2bd5fa60616cf604286a', 'eer', '2011-02-01', '2012-02-03', 's2ffgg th jjj', 'ff', 'ny', '996', 'hjk ukk', 0, 'ddd c', 41, 'df ht hhj', 'iopppppp', '', '0000-00-00', '0000-00-00', '', '', '', '', '', 0, '', 0, '', '', '', '0000-00-00', '0000-00-00', '', '', '', '', '', 0, '', 0, '', '', 'uiiiioo yu', 'ny', '2012-02-01', '788', '', '', '0000-00-00', '', '', '', '0000-00-00', '', '', '', '0000-00-00', ''),
(5, 'b76350b94a20437ec3bd606adb3cab20', '', '0000-00-00', '0000-00-00', '', '', '', '', '', 0, '', 0, '', '', '', '0000-00-00', '0000-00-00', '', '', '', '', '', 0, '', 0, '', '', '', '0000-00-00', '0000-00-00', '', '', '', '', '', 0, '', 0, '', '', '1', '', '2013-03-31', '', '2', '', '2014-03-19', '', '3', '', '2015-03-12', '', '4', '', '2012-10-23', ''),
(6, '32095c22f49d43b7f581e039350048c7', '', '0000-00-00', '0000-00-00', '', '', '', '', '', 0, '', 0, '', '', '', '0000-00-00', '0000-00-00', '', '', '', '', '', 0, '', 0, '', '', '', '0000-00-00', '0000-00-00', '', '', '', '', '', 0, '', 0, '', '', 'u', 'uu', '2013-03-31', 'pp', 'p', '', '2012-02-29', '', '', '', '0000-00-00', '', '', '', '0000-00-00', ''),
(7, '99f48a0ec14cbf1c57d2f390ffa4f7ba', '1', '0000-00-00', '0000-00-00', '', '', '', '', '', 0, '', 0, '', '', '2', '0000-00-00', '0000-00-00', '', '', '', '', '', 0, '', 0, '', '', '3', '0000-00-00', '0000-00-00', '', '', '', '', '', 0, '', 0, '', '', '1', '', '0000-00-00', '', '2', '', '0000-00-00', '', '3', '', '0000-00-00', '', '4', '', '0000-00-00', '');
