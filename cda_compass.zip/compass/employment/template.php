<?php
require 'conn.php';

$app_no=$_GET['app_no'];
$sql = "select * from pageone where app_no = '$app_no'";
$result = mysql_query($sql);
$members = mysql_fetch_array($result,MYSQL_ASSOC);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title>The Villages - Apply Online</title>

</head>

<body>
<div id="data" style="margin-left:auto;margin-right:auto; width:95%">

<p align="center"><img border="0" src="images/logo.jpg" alt="logo" width="282" height="118"></p>
<p align="center"><b><font size="4">Build Your Future - Join Our Team!</font></b></p>
<hr>

<p align="justify">To be considered for employment you must indicate the job 
vacancy position title.</p>
<p align="justify">Position applying for: <b><font color="blue"><?php echo ucwords($members['position']);?></font></b></p>
<p align="justify">Requisition Number: <b><font color="blue"><?php echo ucwords($members['req_num']);?></font></b></p>
<p align="justify">Type of employment you are seeking: <b><font color="blue"><?php echo ucwords($members['emp_type_data']);?></font></b>
 </p>
<p align="justify">Please answer all question. Resumes or &quot;see resumes&quot; 
responses are not accepted in lieu of completion of this application. Incomplete 
applications are not considered.</p>
<p align="justify">Last Name: <b><font color="blue"><?php echo ucwords($members['lname']);?></font></b>
First Name: <b><font color="blue"><?php echo ucwords($members['fname']);?></font></b>
Middile Name: <b><font color="blue"><?php echo ucwords($members['mname']);?></font></b>
Social Security Number: <b><font color="blue"><?php echo ucwords($members['ssn']);?></font></b></p>
<p align="justify">Present Physical Address: <b><font color="blue"><?php echo ucwords($members['paddress']);?></font></b>
City: <b><font color="blue"><?php echo ucwords($members['pcity']);?></font></b>
County: <b><font color="blue"><?php echo ucwords($members['pcounty']);?></font></b>
State: <b><font color="blue"><?php echo ucwords($members['pstate']);?></font></b>
Zip: <b><font color="blue"><?php echo ucwords($members['pzip']);?></font></b></p>
<p align="justify">Present Mailing Address: <b><font color="blue"><?php echo ucwords($members['maddress']);?></font></b>
City: <b><font color="blue"><?php echo ucwords($members['mcity']);?></font></b>
County: <b><font color="blue"><?php echo ucwords($members['mcounty']);?></font></b>
State: <b><font color="blue"><?php echo ucwords($members['mstate']);?></font></b>
Zip: <b><font color="blue"><?php echo ucwords($members['mzip']);?></font></b></p>
<p align="justify">Day Telephone: <b><font color="blue"><?php echo ucwords($members['dphone']);?></font></b>
Evening Telephone: <b><font color="blue"><?php echo ucwords($members['ephone']);?></font></b>
Email: <b><font color="blue"><?php echo strtolower($members['email']);?></font></b></p>
<p align="justify">Only U.S. citizens or aliens who have the legal right to work 
in the U.S. are eligible for employment. Can you, upon employment, submit 
documentation verifying your legal right to work in the U.S. and your identity? <b><font color="blue"><?php echo ucwords($members['wpermit']);?></font></b></p>
<p align="justify">Do you have transportation to work? <b><font color="blue"><?php echo ucwords($members['transport']);?></font></b></p>
<p align="justify">Availability: To help us consider you for a job that matches 
your availability, please check if you are able to work: <b><font color="blue"><?php echo ucwords($members['days_data'])."; ";?> &nbsp; <?php echo " ".ucwords($members['shifts_data']);?></font></b></p>
<p>If the position you are applying for requires a drivers license, please 
submit the following:</p>
<p>State: <b><font color="blue"><?php echo ucwords($members['drvstate']);?></font></b>
License: <b><font color="blue"><?php echo ucwords($members['drvlicense']);?></font></b>
Type: <b><font color="blue"><?php echo ucwords($members['drvtype']);?></font></b>
</p>
<p>Are you 18 years of age? <b><font color="blue"><?php echo ucwords($members['age']);?></font></b></p>
<hr>
<table border="0" width="100%">
	<!--tr>
		<td colspan="5">
		<p align="center">Education</td>
	</tr-->
	<tr>
		<td width="18%">School</td>
		<td width="31%" align="center">
		Name, Number & Street, City, State and Zip Code</td>
		<td width="18%" align="center">
		Degree</td>
		<td width="13%" align="center" style="visibility: hidden"><!--Date Graduated--></td>
		<td width="18%" align="center">Major Course of Study</td>
	</tr>
	<tr>
		<td width="18%"></td>
		<td width="31%" align="center">
		
		<b><font color="blue"></font></b>
</td>
		<td width="18%" align="center">
		<b><font color="blue"></font></b>
</td>
		<td width="13%" align="center">
		<b><font color="blue"></font></b>
</td>
		<td width="18%" align="center">
		<b><font color="blue"></font></b>
</td>
	</tr>
	<tr>
		<td width="18%">High School</td>
		<td width="31%" align="center">
		
		<b><font color="blue"><?php echo ucwords($members['high_edu_add']);?></font></b>
</td>
		<td width="18%" align="center">
		<b><font color="blue"><?php echo ucwords($members['high_edu_degree']);?></font></b>
</td>
		<td width="13%" align="center">
		<!--<b><font color="blue" style="visibility: hidden"><?php echo ucwords($members['high_edu_date']);?></font></b>-->
</td>
		<td width="18%" align="center">
		<b><font color="blue"><?php echo ucwords($members['high_edu_major']);?></font></b>
</td>
	</tr>
	<tr>
		<td width="18%">College</td>
		<td width="31%" align="center">
		
		<b><font color="blue"><?php echo ucwords($members['col_edu_add']);?></font></b>
</td>
		<td width="18%" align="center">
		<b><font color="blue"><?php echo ucwords($members['col_edu_degree']);?></font></b>
</td>
		<td width="13%" align="center">
		<!--<b><font color="blue" style="visibility: hidden"><?php echo ucwords($members['col_edu_date']);?></font></b>-->
</td>
		<td width="18%" align="center">
		<b><font color="blue"><?php echo ucwords($members['col_edu_major']);?></font></b>
</td>
	</tr>
	<tr>
		<td width="18%">Other</td>
		<td width="31%" align="center">
		
		<b><font color="blue"><?php echo ucwords($members['other_edu_add']);?></font></b>
</td>
		<td width="18%" align="center">
		<b><font color="blue"><?php echo ucwords($members['other_edu_degree']);?></font></b>
</td>
		<td width="13%" align="center">
		<!--<b><font color="blue" style="visibility: hidden"><?php echo ucwords($members['other_edu_date']);?></font></b>-->
</td>
		<td width="18%" align="center">
		<b><font color="blue"><?php echo ucwords($members['other_edu_major']);?></font></b>
</td>
	</tr>
</table>
<hr>
<p>Other Skills/Honors: List any other job-related skills or qualifications that 
support your application, e.g. Heavy equipment, computers, construction, etc. If 
applying for secretarial / clerical positions, please indicate keyboarding 
speed: <b><font color="blue"><?php echo ucwords($members['speed']);?></font></b> wpm</p>

<hr>

<p>In order to permit a check of your work and educational records, should we be 
made aware of any changes of your name or assumed name that you previously used? <b><font color="blue"><?php echo ucwords($members['prevname']);?></font></b></p>
<p>If Yes, identify name: <b><font color="blue"><?php echo ucwords($members['prevparticular']);?></font></b>
relevant date: <b><font color="blue"><?php echo ucwords($members['prevdate']);?></font></b></p>

<hr>
<!-- Page One Ends -->

<?php
$sql = "select * from pagetwo where app_no = '$app_no'";
$result = mysql_query($sql);
$members = mysql_fetch_array($result,MYSQL_ASSOC);
?>

<p align="center"><b>Employment Experience</b></p>
<hr>
<b>ALL FORMER EMPLOYERS: </b>(List most recent job first) Account for all the periods including <b>unemployment, self-employment and military service.</b>

<table border="0" width="100%">
	<tr>
		<td width="52%" colspan="2">Employer: <b><font color="blue"><?php echo ucwords($members['employer1']);?></font></b>
</td>
		<td width="27%">From: <b><font color="blue"><?php echo ucwords($members['emp1_from']);?></font></b>
</td>
		<td width="20%">To: <b><font color="blue"><?php echo ucwords($members['emp1_to']);?></font></b>
</td>
	</tr>
	<tr>
		<td width="28%">Address: <b><font color="blue"><?php echo ucwords($members['emp1_address']);?></font></b>
</td>
		<td width="23%">City: <b><font color="blue"><?php echo ucwords($members['emp1_city']);?></font></b>
</td>
		<td width="27%">State: <b><font color="blue"><?php echo ucwords($members['emp1_state']);?></font></b>
</td>
		<td width="20%">Zip: <b><font color="blue"><?php echo ucwords($members['emp1_zip']);?></font></b>
</td>
	</tr>
	<tr>
		<td colspan="2">Job Title: <b><font color="blue"><?php echo ucwords($members['emp1_title']);?></font></b>
</td>
		<td width="47%" colspan="2">Salary: <b><font color="blue"><?php echo ucwords($members['emp1_salary']);?></font></b>
</td>
	</tr>
	<tr>
		<td width="52%" colspan="2">Immediate Supervisor: <b><font color="blue"><?php echo ucwords($members['emp1_boss']);?></font></b>
</td>
		<td width="47%" colspan="2">Telephone Number: <b><font color="blue"><?php echo ucwords($members['emp1_phone']);?></font></b>
</td>
	</tr>
	<tr>
		<td width="52%" colspan="2">Principal Duties: <b><font color="blue"><?php echo ucwords($members['emp1_duties']);?></font></b>
</td>
		<td width="47%" colspan="2">Reason for Leaving: <b><font color="blue"><?php echo ucwords($members['emp1_reason']);?></font></b>
</td>
	</tr>
</table>
<p></p>
<table border="0" width="100%">
	<tr>
		<td width="52%" colspan="2">Employer: <b><font color="blue"><?php echo ucwords($members['employer2']);?></font></b>
</td>
		<td width="26%">From: <b><font color="blue"><?php echo ucwords($members['emp2_from']);?></font></b>
</td>
		<td width="20%">To: <b><font color="blue"><?php echo ucwords($members['emp2_to']);?></font></b>
</td>
	</tr>
	<tr>
		<td width="28%">Address: <b><font color="blue"><?php echo ucwords($members['emp2_address']);?></font></b>
</td>
		<td width="23%">City: <b><font color="blue"><?php echo ucwords($members['emp2_city']);?></font></b>
</td>
		<td width="26%">State: <b><font color="blue"><?php echo ucwords($members['emp2_state']);?></font></b>
</td>
		<td width="20%">Zip: <b><font color="blue"><?php echo ucwords($members['emp2_zip']);?></font></b>
</td>
	</tr>
	<tr>
		<td colspan="2">Job Title: <b><font color="blue"><?php echo ucwords($members['emp2_title']);?></font></b>
</td>
		<td width="47%" colspan="2">Salary: <b><font color="blue"><?php echo ucwords($members['emp2_salary']);?></font></b>
</td>
	</tr>
	<tr>
		<td width="52%" colspan="2">Immediate Supervisor: <b><font color="blue"><?php echo ucwords($members['emp2_boss']);?></font></b>
</td>
		<td width="47%" colspan="2">Telephone Number: <b><font color="blue"><?php echo ucwords($members['emp2_phone']);?></font></b>
</td>
	</tr>
	<tr>
		<td width="52%" colspan="2">Principal Duties: <b><font color="blue"><?php echo ucwords($members['emp2_duties']);?></font></b>
</td>
		<td width="47%" colspan="2">Reason for Leaving: <b><font color="blue"><?php echo ucwords($members['emp2_reason']);?></font></b>
</td>
	</tr>
</table>

<p></p>
<table border="0" width="100%">
	<tr>
		<td width="52%" colspan="2">Employer: <b><font color="blue"><?php echo ucwords($members['employer3']);?></font></b>
</td>
		<td width="26%">From: <b><font color="blue"><?php echo ucwords($members['emp3_from']);?></font></b>
</td>
		<td width="20%">To: <b><font color="blue"><?php echo ucwords($members['emp3_to']);?></font></b>
</td>
	</tr>
	<tr>
		<td width="28%">Address: <b><font color="blue"><?php echo ucwords($members['emp3_address']);?></font></b>
</td>
		<td width="23%">City: <b><font color="blue"><?php echo ucwords($members['emp3_city']);?></font></b>
</td>
		<td width="26%">State: <b><font color="blue"><?php echo ucwords($members['emp3_state']);?></font></b>
</td>
		<td width="20%">Zip: <b><font color="blue"><?php echo ucwords($members['emp3_zip']);?></font></b>
</td>
	</tr>
	<tr>
		<td colspan="2">Job Title: <b><font color="blue"><?php echo ucwords($members['emp3_title']);?></font></b>
</td>
		<td width="47%" colspan="2">Salary: <b><font color="blue"><?php echo ucwords($members['emp3_salary']);?></font></b>
</td>
	</tr>
	<tr>
		<td width="52%" colspan="2">Immediate Supervisor: <b><font color="blue"><?php echo ucwords($members['emp3_boss']);?></font></b>
</td>
		<td width="47%" colspan="2">Telephone Number: <b><font color="blue"><?php echo ucwords($members['emp3_phone']);?></font></b>
</td>
	</tr>
	<tr>
		<td width="52%" colspan="2">Principal Duties: <b><font color="blue"><?php echo ucwords($members['emp3_duties']);?></font></b>
</td>
		<td width="47%" colspan="2">Reason for Leaving: <b><font color="blue"><?php echo ucwords($members['emp3_reason']);?></font></b>
</td>
	</tr>
</table>
<p></p>
<hr>
<p align="justify">List any professional license, registration or certification you possess:</p>
<p></p>
<table border="0" width="70%">
	<tr>
		<td align="center" width="25%">Type</td>
		<td align="center" width="25%">State Issued</td>
		<td align="center" width="25%">Expiration Date</td>
		<td align="center" width="25%">Number</td>
	</tr>
	<tr>
		<td align="center">
		

		
		<b><font color="blue"><?php echo ucwords($members['pro_type1']);?></font></b>
</td>
		<td align="center">
		
		<b><font color="blue"><?php echo ucwords($members['pro_state1']);?></font></b>
</td>
		<td align="center">
		<b><font color="blue"><?php echo ucwords($members['pro_expiry1']);?></font></b>
</td>
		<td align="center">

		<b><font color="blue"><?php echo ucwords($members['pro_num1']);?></font></b>
</td>
	</tr>
	<tr>
		<td align="center" >
		

		
		<b><font color="blue"><?php echo ucwords($members['pro_type2']);?></font></b>
</td>
		<td align="center" >
		
		<b><font color="blue"><?php echo ucwords($members['pro_state2']);?></font></b>
</td>
		<td align="center" >
		<b><font color="blue"><?php echo ucwords($members['pro_expiry2']);?></font></b>
</td>
		<td align="center">
		<b><font color="blue"><?php echo ucwords($members['pro_num2']);?></font></b>
</td>
	</tr>
	<tr>
		<td align="center">
		
	
		
		<b><font color="blue"><?php echo ucwords($members['pro_type3']);?></font></b>
</td>
		<td align="center">
		
		<b><font color="blue"><?php echo ucwords($members['pro_state3']);?></font></b>
</td>
		<td align="center">
		<b><font color="blue"><?php echo ucwords($members['pro_expiry3']);?></font></b>
</td>
		<td align="center">
		<b><font color="blue"><?php echo ucwords($members['pro_num3']);?></font></b>
</td>
	</tr>
	<tr>
		<td align="center">
		
		<b><font color="blue"><?php echo ucwords($members['pro_type4']);?></font></b>
</td>
		<td align="center">
	
		<b><font color="blue"><?php echo ucwords($members['pro_state4']);?></font></b>
</td>
		<td align="center">
		<b><font color="blue"><?php echo ucwords($members['pro_expiry4']);?></font></b>
</td>
		<td align="center">
		<b><font color="blue"><?php echo ucwords($members['pro_num4']);?></font></b>
</td>
	</tr>
</table>
<p></p>
<hr>

<!-- Page Two Ends -->
<?php
$sql = "select * from pagethree where app_no = '$app_no'";
$result = mysql_query($sql);
$members = mysql_fetch_array($result,MYSQL_ASSOC);
?>
<p>Have you ever been dismissed or forced to resign from any employment? <b><font color="blue"><?php echo ucwords($members['forceretire']);?></font></b></p>
<p>If yes, please explain: <b><font color="blue"><?php echo ucwords($members['forcereason']);?></font></b></p>
<p>IN CASE OF EMERGENCY, NOTIFY:</p>
<p></p>
<table border="0" width="100%">
	<tr>
		<td width="28%">Name: <b><font color="blue"><?php echo ucwords($members['emergencyname']);?></font></b>
</td>
		<td width="38%">Day Phone Number: <b><font color="blue"><?php echo ucwords($members['emergencyphone']);?></font></b>
</td>
		<td width="32%">Relationship: <b><font color="blue"><?php echo ucwords($members['emergencyrelation']);?></font></b>
</td>
	</tr>
	<tr>
		<td colspan="2">Physical Address: <b><font color="blue"><?php echo ucwords($members['emergencyaddress']);?></font></b>
</td>
		<td width="32%">City / State: <b><font color="blue"><?php echo ucwords($members['emergencycity']);?></font></b>
</td>
	</tr>
</table>
<p></p>
<p>Have you ever been convicted of any felonies? <b><font color="blue"><?php echo ucwords($members['felonies']);?></font></b></p>
<p>If Yes, give City, State, dates, penalty imposed, and explain. A conviction will not necessarily disqualify you from employment. <b><font color="blue"><?php echo ucwords($members['felonyexp']);?></font></b></p>
<p>Have you ever been convicted of any type of theft or fraud or a violent crime? <b><font color="blue"><?php echo ucwords($members['violent']);?></font></b> &nbsp; If Yes, give type of action and disposition of case <b><font color="blue"><?php echo ucwords($members['violentexp']);?></font></b></p>

<hr>

<p>Do you have any friends or relatives who work in The Villages? <b><font color="blue"><?php echo ucwords($members['relativecol']);?></font></b></p>
<p></p>
<table border="0" width="100%">
	<tr>
		<td>Name: <b><font color="blue"><?php echo ucwords($members['relativecolname1']);?></font></b>
</td>
		<td>Relationship: <b><font color="blue"><?php echo ucwords($members['relativecolrel1']);?></font></b>
</td>
		<td>Dept.: <b><font color="blue"><?php echo ucwords($members['relativecoldept1']);?></font></b>
</td>
	</tr>
	<tr>
		<td>Name: <b><font color="blue"><?php echo ucwords($members['relativecolname2']);?></font></b>
</td>
<td>Relationship: <b><font color="blue"><?php echo ucwords($members['relativecolrel2']);?></font></b>
</td>
		<td>Dept.: <b><font color="blue"><?php echo ucwords($members['relativecoldept2']);?></font></b>
</td>

	</tr>
</table>
<p></p>
<p>Are you now employed? <b><font color="blue"><?php echo ucwords($members['ifemp']);?></font></b></p>
<p>Are you on layoff? <b><font color="blue"><?php echo ucwords($members['iflay']);?></font></b></p>
<p>Are you subject to recall? <b><font color="blue"><?php echo ucwords($members['ifrecall']);?></font></b></p>
<p>May we contact your present employer? <b><font color="blue"><?php echo ucwords($members['ifcontact']);?></font></b></p>
<p>May we contact your previous employer? <b><font color="blue"><?php echo ucwords($members['ifcontactprev']);?></font></b></p>
<p>Please identify any exceptions and reasons for not contacting prior employers: <b><font color="blue"><?php echo ucwords($members['contactres']);?></font></b></p>
<p>List three persons not related to you <b>who have supervised you.</b></p>

<p></p>
<table border="0" width="90%">
	<tr>
		<td width="25%" align="center">Name</td>
		<td width="25%" align="center">Address</td>
		<td width="25%" align="center">Telephone</td>
		<td width="25%" align="center">Occupation</td>
	</tr>
	<tr>
		<td width="25%" align="center" ><b><font color="blue"><?php echo ucwords($members['refname1']);?></font></b>
</td>
		<td width="25%" align="center"><b><font color="blue"><?php echo ucwords($members['refadd1']);?></font></b>
</td>
		<td width="25%" align="center"><b><font color="blue"><?php echo ucwords($members['refph1']);?></font></b>
</td>
		<td width="25%" align="center"><b><font color="blue"><?php echo ucwords($members['refocu1']);?></font></b>
</td>
	</tr>
	<tr>
		<td width="25%" align="center"><b><font color="blue"><?php echo ucwords($members['refname2']);?></font></b>
</td>
		<td width="25%" align="center"><b><font color="blue"><?php echo ucwords($members['refadd2']);?></font></b>
</td>
		<td width="25%" align="center"><b><font color="blue"><?php echo ucwords($members['refph2']);?></font></b>
</td>
		<td width="25%" align="center"><b><font color="blue"><?php echo ucwords($members['refocu2']);?></font></b>
</td>
	</tr>
	<tr>
		<td width="25%" align="center"><b><font color="blue"><?php echo ucwords($members['refname3']);?></font></b>
</td>
		<td width="25%" align="center"><b><font color="blue"><?php echo ucwords($members['refadd3']);?></font></b>
</td>
		<td width="25%" align="center"><b><font color="blue"><?php echo ucwords($members['refph3']);?></font></b>
</td>
		<td width="25%" align="center"><b><font color="blue"><?php echo ucwords($members['refocu3']);?></font></b>
</td>
	</tr>
</table>
<p></p>

<p>List below any other information or remarks that you wish to have considered as a part of your application for employment.</p> <b><font color="blue"><?php echo ucwords($members['inforemark']);?></font></b>
<p>Have you ever filed an application with any part of The Villages before? <b><font color="blue"><?php echo ucwords($members['appbefore']);?></font></b></p>
<p>Location: <b><font color="blue"><?php echo ucwords($members['appbeforeloc']);?></font></b> &nbsp; If Yes, give Date: <b><font color="blue"><?php echo ucwords($members['appbeforedate']);?></font></b></p>

<p>Have you ever been employed by any part of The Villages before?<b><font color="blue"><?php echo ucwords($members['appbeforepart']);?></font></b></p>
<p>Location: <b><font color="blue"><?php echo ucwords($members['appbeforepartloc']);?></font></b> &nbsp; If Yes, give Date: <b><font color="blue"><?php echo ucwords($members['appbeforepartdate']);?></font></b></p>
<p>Reason for leaving: <b><font color="blue"><?php echo ucwords($members['leavingreason']);?></font></b></p>

<hr>

<!-- Page Three Ends -->

<?php
$sql = "select * from pagefour where app_no = '$app_no'";
$result = mysql_query($sql);
$members = mysql_fetch_array($result,MYSQL_ASSOC);
?>

<p>Are you a veteran of the U.S. Military Services? <b><font color="blue"><?php echo ucwords($members['ifmilitary']);?></font></b></p>
<p>If yes, what branch of Service?  <b><font color="blue"><?php echo ucwords($members['militarybr']);?></font></b></p>
<p>If yes, beginning date: <b><font color="blue"><?php echo ucwords($members['militarybegin']);?></font></b> ending date of active duty: <b><font color="blue"><?php echo ucwords($members['militaryend']);?></font></b></p>
<p>Date of discharge from Military Service: <b><font color="blue"><?php echo ucwords($members['militarydchrg']);?></font></b></p>
<hr>
<p><b>NOTICE TO APPLICANTS:</b></p>
<p align="justify">This employer complies with the Americans With Disabilities Act of 1990. During the interview process, you will be asked questions concerning your ability to perform job-related functions. If you are given a conditional offer of employment, you may be required to complete a post-job offer medical history questionnaire and/or undergo examination. If required, all entering employees in the same job category will be subject to the same medical questionnaire and/or examination and all information will be kept confidential and in separate files.</p>
<p align="justify"><i><b>IMPORTANT:</b> We are glad you are interested in joining The Villages 
family. Please read the following statements carefully before you sign and 
return your application:</i></p>
<p align="justify">The Villages, in considering my application for employment, may verify the 
information set forth on this application and obtain additional information 
relating to my background, driving and criminal history records, I authorize all 
persons, school, companies, corporations, credit bureaus, and law enforcement 
agencies to supply any information concerning my background. This includes 
authorizing the release of information about non-judicial punishment that might 
have occurred in the Air Force, Army, Navy, Marine, National Guard, or any other 
branch of the military service.</p>
<p><b><font color="blue"><?php echo ucwords($members['term1']).", ";?></font></b> I have read, understand, and agree to this statement.</p>
<p align="justify"><b>I certify that the information on this application is correct and understand 
that any misrepresentation or omission of any information will result in my 
disqualification from consideration for employemnt or, if employed, my 
dismissal.</b> I understand that this application is not a contract, offer, or 
promise of employment and that if hired, I will be able to resign at any time 
for any reason. Likewise, The Villages can terminate my employment at any time 
with or without cause.</p>
<p><b><font color="blue"><?php echo ucwords($members['term2']).", ";?></font></b> I have read, understand, and agree to this statement.
</p>
<p align="justify">I understand that this application is good for only 60 days from today&#39;s 
date. If I still desire a position with the company after this application 
expires, it will be my responsibility to reactivate my application and file it 
with the company. Otherwise the company will not consider me for employment 
after this application expires.</p>
<p align="justify">I also understand that if I recieve a preliminary offer of employment, I will 
be required to complete the application process by attending an additional 
un-paid 90 minute session (approximate) before I am eligible to become an 
employee. During this session, company benefits and philosophy are reviewed and 
related documents signed.</p>
<hr >
<p align="justify">This Employer is an equal employment opportunity employer. We also adhere to 
a policy of making employment decisions without regard to race, color, age, sex, 
religion, national origin, handicap, or martial status. We assure you that your 
opportunity for employment with this employer depends solely upon your 
qualification.</p>
<hr>
</div>
</body>

</html>