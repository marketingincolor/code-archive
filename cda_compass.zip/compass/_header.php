<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
		<base href="<?php print $config->site->url; ?>" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title><?php print ( !empty($head_title) ? implode(' / ', array_reverse($head_title)).' - ' : '' ) . $config->site->name; ?></title>
		<link href="tpl/css/reset.css" type="text/css" rel="stylesheet" media="screen" />
		<link href="tpl/css/screen.css" type="text/css" rel="stylesheet" media="screen" />
		<link href="tpl/js/jquery.wysiwyg/jquery.wysiwyg.css" type="text/css" rel="stylesheet" media="screen" />
		<link href="tpl/css/job-list-manager.css" type="text/css" rel="stylesheet" media="screen" />
        <link rel="shortcut icon" type="image/x-icon" href="tpl/img/icon.ico">
        <script src="tpl/js/jquery.js" type="text/javascript" language="javascript"></script>
        <script src="tpl/js/jquery.wysiwyg/jquery.wysiwyg.js" type="text/javascript" language="javascript"></script>
        <script src="tpl/js/main.js" type="text/javascript" language="javascript"></script>
        <script type="text/javascript">
$(document).ready(function(){ 
	
	$("ul#nav li a").css({"opacity" : 0}).hover(function(){
		$(this).stop().animate({"opacity" : 1}, 200); //Change fade-in speed
	
		}, function(){
		$(this).stop().animate({"opacity" : 0}, 200);//Change fade-out speed
	
	});
	$("a[href^='http://compasshrm.tgsnapshot.com']").attr('target', '_blank');
	
});
</script>
    </head>
    
    <body>
    
    	<div id="header">
            <div class="inner clear-fix">
            <a href="http://www.compasshrm.com/index.php"><img src="test/images/villagesc.png" style="margin: 0px 0 0 0; z-index: 50; position: relative;" /></a>
                
                   
<?php
	if($user->isAuthorized()){
?>
<li class="last"><a<?php print (($avatar = $user->getAvatar()) ? ' class="image" style="background-image:url(library/thumb.php?f='.$avatar.'&w=20&h=20&method=crop);"' : ''); ?> href="members.php?profile=<?php print $user->getId(); ?>">My Account <span class="special">&#9662;</span></a>
	<ul>
    	<li><a href="edit-profile.php">Edit Profile</a></li>
        <?php print $user->getType() === MK_RecordUser::TYPE_CORE ? '<li><a href="change-password.php">Change Password</a></li>' : '' ?>
        <li><a href="logout.php">Logout</a></li>
        <?php print $user->getGroup()->isAdmin() ? '<li><a href="admin">Admin</a></li>' : '' ?>
    </ul>
</li>
<?php
	}else{
?>
					
                   
<?php
	}
?>
                </ul>
<?php
	$settings = array(
		'attributes' => array(
			'class' => 'clear-fix'
		)
	);

	$structure = array(
		'keywords' => array(
			'label' => 'Keywords',
			'attributes' => array(
				'title' => 'Search jobs',
			)
		),
		'submit' => array(
			'type' => 'submit',
			'attributes' => array(
				'value' => '&raquo;'
			)
		)
	);

	$form = new MK_Form($structure, $settings);
	print $form->render();
?>
            </div>
        </div>
    	<div id="wrapper" class="clear-fix">

