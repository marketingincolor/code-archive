<?php
require_once '_inc.php';

$head_title = array();

// Get the jobs & job category modules
$job_module = MK_RecordModuleManager::getFromType('job');
$job_category_module = MK_RecordModuleManager::getFromType('job_category');
$job_type_module = MK_RecordModuleManager::getFromType('job_type');

// See if job is set
try
{
	$current_job = MK_Request::getQuery('job');
	$current_job = MK_RecordManager::getFromId( $job_module->getId(), $current_job );
}catch(Exception $e){
	$current_job = null;
}

// See if category is set
try
{
	$current_job_category = MK_Request::getQuery('job_category', 0);
	$current_job_category = MK_RecordManager::getFromId( $job_category_module->getId(), $current_job_category );
}catch(Exception $e){
	$current_job_category = null;
}

// See if job type is set
try
{
	$current_job_type = MK_Request::getQuery('job_type', 0);
	$current_job_type = MK_RecordManager::getFromId( $job_type_module->getId(), $current_job_type );
}catch(Exception $e){
	$current_job_type = null;
}

$jobs = array();

$output = '';

if($current_job)
{
	$head_title[] = $current_job->getTitle();

	$output .= '<h2>'.$current_job->getTitle().'</h2>';
	$output .= '<p class="subtitle">';

	try
	{
		$job_type = MK_RecordManager::getFromId( $job_type_module->getId(), $current_job->getType() );
		$output .= '<span>'.$job_type->getTitle().'</span>';
	}catch(Exception $e){}

	if($employer_name = $current_job->getEmployerName())
	{
		if($employer_website = $current_job->getEmployerWebsite())
		{
			$output .= ' at <span><a target="_blank" href="'.$employer_website.'">'.$employer_name.'</a></span>';
		}
		else
		{
			$output .= ' at <span>'.$employer_name.'</span>';
		}
	}
	if($location = $current_job->getLocation())
	{
			$output .= ' in <span>'.$location.'</span>';
	}
	$output .= '</p>';
	
	$output.=$current_job->getDescription();

	//$output .= '<h2>Apply Now</h2>';
	
	if($user->isAuthorized())
	{
		$settings = array(
			'attributes' => array(
				'class' => 'clear-fix titled standard',
				'id' => 'apply-now',
				'action' => 'index.php?job='.$current_job->getId().'#apply-now'
			)
		);
	
		$structure = array(
			'name' => array(
				'label' => 'Your name',
				'type' => 'static',
				'value' => $user->getDisplayName(),
				'validation' => array(
					'instance' => array()
				)
			),
			'cv' => array(
				'label' => 'CV / Resume',
				'type' => 'file',
				'upload_path' => $config->site->upload_path,
				'tooltip' => 'Must be: PDF, DOC, DOCX, TXT or RTF',
				'valid_extensions' => array('docx', 'doc', 'pdf', 'rtf', 'txt'),
				'validation' => array(
					'instance' => array()
				)
			),
			'message' => array(
				'label' => 'Message / Covering letter',
				'type' => 'textarea'
			),
			'submit' => array(
				'type' => 'submit',
				'attributes' => array(
					'value' => 'Submit Application'
				)
			)
		);
	
		$form = new MK_Form($structure, $settings);
		$job_application_module = MK_RecordModuleManager::getFromType('job_application');
		$application_search_criteria = array(
			array('field' => 'user', 'value' => $user->getId()),
			array('field' => 'job', 'value' => $current_job->getId())
		);
		
		$already_applied = $job_application_module->searchRecords($application_search_criteria);

		if(count($already_applied) > 0)
		{
			$output .= '<p class="alert information">You\'ve already applied for this job!</p>';
		}
		elseif($current_job->getPostedBy() == $user->getId())
		{
			$output .= '<p class="alert information">You can\'t apply for your own job!</p>';
		}
		else
		{
			if($form->isSuccessful())
			{
				$job_application_module = MK_RecordModuleManager::getFromType('job_application');
				$new_application = MK_RecordManager::getNewRecord( $job_application_module->getId() );
				$new_application
					->setJob( $current_job->getId() )
					->setUser( $user->getId() )
					->setMessage( $form->getField('message')->getValue() )
					->setCv( $form->getField('cv')->getValue() )
					->save();
				$output .= '<p class="alert information">Your application has been submitted! Best of luck.</p>';
				
				if($contact_email = $current_job->getEmployerEmail())
				{
					$email_notification = new MK_BrandedEmail();
					$email_notification
						->setSubject('New Job Application ('.$current_job->getTitle().')')
						->setMessage('<strong>'.$user->getDisplayName().'</strong> has applied for the job, <strong>'.$current_job->getTitle().'</strong>. <a href="'.$config->site->url.'your-jobs.php?job='.$current_job->getId().'">View this application</a>.')
						->send($config->site->email);
				}
				
			}
			else
			{
				$output.=$form->render();
			}
		}
	}
	else
	{
		/*$output .= ' <ul id="nav">
<li class="btmbtn"><a href="http://www.compasshrm.com/blank.html" target="_blank"></a></li>
</ul>';*/
		$output .= 'If you have already started your career history form, goto <a href="https://compasshrm.tgsnapshot.com" target="_blank">https://compasshrm.tgsnapshot.com</a> to continue your application process.';
	}

}
else
{
	$job_category_search_criteria = array();
	$job_search_criteria = array(
		array('field' => 'published', 'value' => '1')
	);

	$search_keywords = MK_Request::getParam('keywords');
	$search_keywords = MK_Utility::cleanString($search_keywords);

	// Keyword search
	if( $search_keywords )
	{
		$search_keywords_list = explode(' ', $search_keywords);
		$search_criteria_list = array();
		
		foreach($search_keywords_list as $keyword)
		{
			$search_criteria_list[] = "`tags` LIKE '%".mysql_real_escape_string($keyword, $config->db->con)."%'";
			$search_criteria_list[] = "`title` LIKE '%".mysql_real_escape_string($keyword, $config->db->con)."%'";
			$search_criteria_list[] = "`description` LIKE '%".mysql_real_escape_string($keyword, $config->db->con)."%'";
		}
		
		if($current_job_type)
		{
			$head_title_text = 'Searching for "'.$search_keywords.'" '.$current_job_type->getTitle().' Jobs';
			$title = 'Searching for <em>"'.$search_keywords.'"</em><sup><a href="index.php?'.($current_job_category ? '&job_category='.$current_job_category->getId() : '').($current_job_type ? '&job_type='.$current_job_type->getId() : '').'" title="Remove this filter">[x]</a></sup> <em>'.$current_job_type->getTitle().'</em><sup><a href="index.php?'.($current_job_category ? '&job_category='.$current_job_category->getId() : '').($search_keywords ? '&keywords='.$search_keywords : '').'" title="Remove this filter">[x]</a></sup> Jobs';
			$job_search_criteria[] = array('field' => 'type', 'value' => $current_job_type->getId());
		}
		else
		{
			$head_title_text = 'Searching for "'.$search_keywords.'" Jobs';
			$title = 'Searching for <em>"'.$search_keywords.'"</em><sup><a href="index.php?'.($current_job_category ? '&job_category='.$current_job_category->getId() : '').($current_job_type ? '&job_type='.$current_job_type->getId() : '').'" title="Remove this filter">[x]</a></sup>';
		}
		$job_search_criteria[] = array('literal' => '('.implode(' OR ', $search_criteria_list).')');
	}
	// Job type selected
	elseif($current_job_type)
	{
		$head_title_text = 'Latest '.$current_job_type->getTitle().' Jobs';
		$title = 'Latest <em>'.$current_job_type->getTitle().'</em><sup><a href="index.php?'.($search_keywords ? '&keywords='.$search_keywords : '').($current_job_category ? '&job_category='.$current_job_category->getId() : '').'" title="Remove this filter">[x]</a></sup> Jobs';
		$job_search_criteria[] = array('field' => 'type', 'value' => $current_job_type->getId());
	}
	else
	{
		$head_title_text = 'Latest Jobs';
		$title = 'Latest Jobs';
	}

	if($current_job_category)
	{
		$parent_job_categories = array();
		foreach($current_job_category->getParentRecords() as $parent_category)
		{
			$parent_job_categories[] = '<a href="index.php?job_category='.$parent_category->getId().($current_job_type ? '&job_type='.$current_job_type->getId() : '').($search_keywords ? '&keywords='.$search_keywords : '').'">'.$parent_category->getTitle().'</a>';
		}
		
		$parent_job_categories = array_reverse($parent_job_categories);
		
		$parent_job_categories[] = $current_job_category->getTitle().'<sup><a href="index.php?'.($current_job_type ? '&job_type='.$current_job_type->getId() : '').($search_keywords ? '&keywords='.$search_keywords : '').'" title="Remove this filter">[x]</a></sup>';
		
		$sub_job_categories = array($current_job_category->getId());
		foreach($current_job_category->getSubRecords() as $sub_category)
		{
			$sub_job_categories[] = $sub_category->getId();
		}

		$job_search_criteria[] = array('literal' => "`category` IN(".implode(',', $sub_job_categories).")");

		$head_title_text.= ' in '.$current_job_category->getTitle();
		$title.= ' in <em>'.implode(' / ', $parent_job_categories).'</em>';
	}

	$job_category_search_criteria[] = array(
		'field' => 'parent_category',
		'value' => $current_job_category ? $current_job_category->getId() : 0
	);


	$output .= '<h2>'.$title.'</h2>';
	$head_title[] = $head_title_text;
	
	$job_categories = $job_category_module->searchRecords($job_category_search_criteria);
	
	
	
	$job_types = $job_type_module->getRecords();
	
	if(count($job_types))
	{
		$output .= '<ul class="tags tags-types clear-fix">';
		$output .= '<li class="title">Job Types:</li>';
		foreach($job_categories as $_job_category)
{
    $title = MK_Utility::escapeText("View jobs in '".$_job_category->getTitle()."'");
    $output .= '<li class="tag"><a title="'.$title.'" href="index.php?'.($current_job_type ? 'job_type='.$current_job_type->getId().'&' : '').'job_category='.$_job_category->getId().($search_keywords ? '&keywords='.$search_keywords : '').'">'.$_job_category->getTitle().'</a></li>';
}
		$output .= '</ul>';
	}
	
	$paginator = new MK_Paginator();
	$paginator
		->setPerPage(20)
		->setPage( MK_Request::getQuery('page', 1) );

	$jobs = $job_module->searchRecords($job_search_criteria, $paginator);
	
	if($jobs)
	{
		$output.= '<table class="list-view job-listing-view" cellpadding="0" cellspacing="0" border="0">';
		$output.= '<thead><tr>';
		$output.= '<th style="width:70%;">Title / Employer / Location</th>';
		$output.= '<th style="width:30%; text-align:center;">Date Posted</th>';
		$output.= '</tr></thead>';
		$output.= '<tbody>';
		foreach($jobs as $job)
		{
			$output.= '<tr>';
			$output.= '<td>';
			try
			{
				$job_type = MK_RecordManager::getFromId( $job_type_module->getId(), $job->getType() );
				$output .= '<span>'.$job_type->getTitle().'</span> ';
			}catch(Exception $e){}

			$output.= '<strong><a href="index.php?job='.$job->getId().'">'.$job->getTitle().'</a></strong>';

			if($employer_name = $job->getEmployerName())
			{
				if($employer_website = $job->getEmployerWebsite())
				{
					$output .= ' at <span><a target="_blank" href="'.$employer_website.'">'.$employer_name.'</a></span>';
				}
				else
				{
					$output .= ' at <span>'.$employer_name.'</span>';
				}
			}
			if($location = $job->getLocation())
			{
					$output .= ' in <span>'.$location.'</span>';
			}
			$output.= ($job->getEmployerName() ? '' : '');
			$output.= '</td>';
			$output.= '<td style="text-align:center;">'.$job->renderDatePosted().'</td>';
			$output.= '</tr>';
		}
		$output.= '</tbody>';
		$output.= '</table>';
		
		// Show pagination
		//$output.= '<div class="clear-fix paginator">'.$paginator->render('index.php?page={page}'.($search_keywords ? '&keywords='.$search_keywords : '').(!empty($job_type) ? '&job_type='.$job_type->getId() : '').(!empty($job_category) ? '&job_category='.$job_category->getId() : '')).'</div>';
		$output.= '<div class="clear-fix paginator">'.$paginator->render('index.php?page={page}'.($search_keywords ? '&keywords='.$search_keywords : '').(!empty($job_category) ? '&job_category='.$job_category->getId() : '')).'</div>';
	}
	else
	{
		if($current_job_category || $current_job_type)
		{
			$output .= '<p class="alert information">Your search returned no jobs.</p>';
		}
		else
		{
			$output .= '<p class="alert information">There are no jobs to display.</p>';
		}
	}
}

require_once '_header.php';
print $output;
require_once '_footer.php';

?>