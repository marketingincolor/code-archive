<?php
require_once '_inc.php';
$head_title = array();
$head_title[] = 'Members';

// We get an instance of the users module
$user_module = MK_RecordModuleManager::getFromType('user');

if($user_id = MK_Request::getQuery('profile'))
{
	try
	{
		$user_profile = MK_RecordManager::getFromId($user_module->getId(), $user_id);
		$output = '';
		$output .= '<h2>'.$user_profile->getDisplayName().'\'s Profile</h2>';
		if($avatar = $user_profile->getAvatar())
		{
			$output.= '<img class="user-image" src="library/thumb.php?f='.$avatar.'&h=128&w=128&m=crop" />';
		}
		$output.= '<dl class="user-details">';
		if( $name = $user_profile->getName() )
		{
			$output.= '<dt>Real Name</dt>';
			$output.= '<dd>'.$name.'</dd>';
		}
		$output.= '<dt>Display Name</dt>';
		$output.= '<dd>'.$user_profile->getDisplayName().'</dd>';
		$output.= '<dt>Member Since</dt>';
		$output.= '<dd>'.$user_profile->renderDateRegistered().'</dd>';
		$output.= '<dt>Last Seen</dt>';
		$output.= '<dd>'.$user_profile->renderLastlogin().'</dd>';
		if( $website = $user_profile->getWebsite() )
		{
			$output.= '<dt>Website</dt>';
			$output.= '<dd><a href="'.$website.'">'.$website.'</a></dd>';
		}
		if( $date_of_birth = $user_profile->getDateOfBirth() )
		{
			$date_of_birth = date($config->site->date_format, strtotime($date_of_birth));
			$output.= '<dt>Date of Birth</dt>';
			$output.= '<dd>'.$date_of_birth.'</dd>';
		}
		$output.= '</dl>';
	}
	catch(Exception $e)
	{
		header('Location: index.php', true, 302);
	}
}
else
{
	// We don't want ALL of the users so we create a MK_Paginator
	$paginator = new MK_Paginator();
	
	// If no page is defined we default to the first page and 10 users per page
	$page = MK_Request::getQuery('page', 1);
	
	$paginator
		->setPage($page)
		->setPerPage(10);
	
	// Get users
	$users = $user_module->getRecords($paginator);
	
	$output = '<h2>Members</h2><table class="list-view titled" cellpadding="0" cellspacing="0" border="0">';
	$output.= '<thead><tr>';
	$output.= '<th style="width:50%;">Display Name</th>';
	$output.= '<th style="width:50%;">Last Login</th>';
	$output.= '</tr></thead>';
	$output.= '<tbody>';
	foreach($users as $current_user)
	{
		$output.= '<tr>';
		$output.= '<td class="title"><a href="members.php?profile='.$current_user->getId().'">'.$current_user->getDisplayName().'</a></td>';
		$output.= '<td>'.$current_user->renderLastlogin().'</td>';
		$output.= '</tr>';
	}
	$output.= '</tbody>';
	$output.= '</table>';
	
	// Show pagination
	$output.= '<div class="clear-fix paginator">'.$paginator->render('members.php?page={page}').'</div>';
}

require_once '_header.php';
print $output;
require_once '_footer.php';

?>