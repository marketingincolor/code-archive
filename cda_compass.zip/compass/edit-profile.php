<?php
require_once '_inc.php';
$head_title = array();
$head_title[] = 'Edit Profile';

$output = '<h2>Edit Profile</h2>';
if($user->isAuthorized())
{
	// We get an instance of the users module and the email field to make sure the given email is unique
	$user_module = MK_RecordModuleManager::getFromType('user');
	$field_module = MK_RecordModuleManager::getFromType('module_field');
	$criteria = array(
		array('field' => 'module_id', 'value' => $user_module->getId()),
		array('field' => 'name', 'value' => 'email')
	);
	
	$user_email_field = array_pop( $field_module->searchRecords($criteria) );

	$settings = array(
		'attributes' => array(
			'class' => 'clear-fix titled standard'
		)
	);

	$structure = array(
		'name' => array(
			'label' => 'Real name',
			'value' => $user->getName()
		),
		'display_name' => array(
			'label' => 'Display name',
			'validation' => array(
				'instance' => array()
			),
			'value' => $user->getDisplayName()
		),
		'email' => array(
			'label' => 'Email',
			'validation' => array(
				'email' => array(),
				'instance' => array(),
				'unique' => array($user, $user_email_field, $user_module)
			),
			'value' => $user->getEmail()
		),
		'website' => array(
			'label' => 'Website',
			'validation' => array(
				'url' => array()
			),
			'value' => $user->getWebsite()
		),
		'gender' => array(
			'label' => 'Gender',
			'type' => 'select',
			'options' => array(
				'' => 'Prefer not to disclose',
				'Male' => 'Male',
				'Female' => 'Female'
			),
			'value' => $user->getGender()
		),
		'date_of_birth' => array(
			'label' => 'Date of Birth',
			'type' => 'date',
			'value' => $user->getDateOfBirth()
		),
		'avatar' => array(
			'label' => 'Profile image',
			'type' => 'file_image',
			'upload_path' => $config->site->upload_path,
			'value' => $user->getAvatar()
		),
		'submit' => array(
			'type' => 'submit',
			'attributes' => array(
				'value' => 'Save changes'
			)
		)
	);

	$form = new MK_Form($structure, $settings);
	
	if($form->isSuccessful()){
		$output .= '<p class="alert success">Your changes have been saved.</p>';
		$user
			->setAvatar( $form->getField('avatar')->getValue() )
			->setEmail( $form->getField('email')->getValue() )
			->setName( $form->getField('name')->getValue() )
			->setWebsite( $form->getField('website')->getValue() )
			->setDateOfBirth( $form->getField('date_of_birth')->getValue() )
			->setGender( $form->getField('gender')->getValue() )
			->setDisplayName( $form->getField('display_name')->getValue() )
			->save();
	}
		
	$output .= $form->render();

}else{
	$output .= '<p class="alert warning">Please <a href="login.php">log in</a> or <a href="register.php">register</a> to view this page!</p>';
}

require_once '_header.php';
print $output;
require_once '_footer.php';

?>